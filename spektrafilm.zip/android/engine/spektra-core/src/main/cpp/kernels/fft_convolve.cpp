/*
 * Spektrafilm for Android — native engine: FFT convolution for the diffusion PSF.
 * Copyright (C) 2026 Spektrafilm Android contributors. GPLv3 (see fft_convolve.h).
 * Port of spektrafilm (GPLv3) by Andrea Volpato — film modeling powered by spektrafilm.
 *
 * ---------------------------------------------------------------------------
 * THE DERIVATION, because "use an FFT" hides exactly the index bookkeeping that
 * makes this the SAME operator rather than a similar one.
 *
 * The direct loop computes, for y in [0,h) and x in [0,w):
 *
 *     out[y][x] = sum_{i,j in [0,ks)} padded[y+i][x+j] * kern[ks-1-i][ks-1-j]
 *
 * Substituting p = ks-1-i (so i = ks-1-p) in one dimension:
 *
 *     out[y] = sum_p padded[y + ks-1 - p] * kern[p]   =   (padded * kern)[y + ks-1]
 *
 * i.e. the LINEAR convolution of padded with kern, read at offset ks-1. That is
 * the standard "valid" region, and it is why the kernel is placed at the ORIGIN
 * of the transform below rather than centred: centring would shift the answer by
 * radius and silently translate the image.
 *
 * A CIRCULAR convolution of size N equals the linear one at index n whenever the
 * taps it reads, n-ks+1 .. n, stay inside [0, N). For n = ks-1+i with i in [0,B)
 * those are i .. i+ks-1, so B = N - ks + 1 outputs per transform are exact and
 * the rest are wrapped garbage. Discarding the wrapped ones and stepping by B is
 * overlap-save.
 *
 * Note padded already has ph = h + 2*radius = h + ks - 1 rows, so a single
 * transform of size N >= ph needs NO further zero padding -- the reflect padding
 * the caller built is exactly the overlap the convolution wants. Small images
 * therefore take one transform and no tiling at all.
 *
 * ---------------------------------------------------------------------------
 * REAL-TO-COMPLEX. Both the image tile and the kernel are real, so their spectra
 * are Hermitian and only n/2 + 1 of the n columns are independent. Storing and
 * transforming just those halves BOTH the scratch and the work versus a complex
 * transform. That matters more than a plain 2x: scratch is what caps the
 * transform size, and transform size is what makes a large kernel cheap. At
 * n = 2048 the two spectra cost ~67 MB instead of ~134 MB.
 *
 * The row pass is kernels/fft.h's RfftPlan (real n -> n/2+1 complex bins, one
 * half-length complex FFT plus an O(n) fixup); the column pass is an ordinary
 * complex FFT of length n over each of the n/2 + 1 kept columns.
 *
 * Still on the table: packing two of the three channels into one complex
 * transform, which would take three channel-passes down to two.
 */
#include "kernels/fft_convolve.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <new>
#include <type_traits>
#include <vector>

#if defined(__aarch64__)
#include <arm_neon.h>
#endif

#include "kernels/fft.h"
#include "kernels/parallel.h"

namespace spk {
namespace {

// Column pass over the kept n/2+1 columns of an r2c spectrum. Each column is an
// independent complex transform of length n, gathered into a contiguous scratch
// line and scattered back -- striding the transform through the spectrum directly
// is dramatically slower. Independent per column, so the parallel split cannot
// change any result and the determinism contract survives for any worker count.
template <typename T>
void columns(T* spec, int n, int bins, const FftPlanT<T>& plan, bool inverse) {
    parallel_for(0, bins, [&](int lo, int hi) {
        thread_local std::vector<T> col;
        const size_t need = static_cast<size_t>(n) * 2;
        if (col.size() < need) col.resize(need);
        for (int c = lo; c < hi; ++c) {
            for (int r = 0; r < n; ++r) {
                const size_t s = (static_cast<size_t>(r) * bins + c) * 2;
                col[static_cast<size_t>(r) * 2 + 0] = spec[s + 0];
                col[static_cast<size_t>(r) * 2 + 1] = spec[s + 1];
            }
            if (inverse) plan.inverse(col.data()); else plan.forward(col.data());
            for (int r = 0; r < n; ++r) {
                const size_t s = (static_cast<size_t>(r) * bins + c) * 2;
                spec[s + 0] = col[static_cast<size_t>(r) * 2 + 0];
                spec[s + 1] = col[static_cast<size_t>(r) * 2 + 1];
            }
        }
    });
}

// The real n x n plane is NEVER materialised. It used to be a third scratch
// buffer the same size as a spectrum (n*n doubles against n*(n/2+1)*2), and
// scratch is what the memory budget refuses -- a refusal that silently drops the
// transform to the next size down, which on a 12.5 MP frame is 4 tiles becoming
// 130 (#204). Rows are produced and consumed one at a time instead, from a
// per-worker temporary, so the buffer disappears without changing a single
// arithmetic operation: identical transforms, on identical values, in identical
// order, so the output is BIT-IDENTICAL to the plane version.
//
// n doubles per worker (256 KB total at n=4096 over 8 workers) replaces 134 MB.

// Rows -> r2c spectrum. `fill_row(r, dst)` must write exactly n doubles.
template <typename T, typename FillRow>
void forward2_rows(FillRow fill_row, T* spec, int n, int bins,
                   const RfftPlanT<T>& rp, const FftPlanT<T>& cp) {
    parallel_for(0, n, [&](int lo, int hi) {
        thread_local std::vector<T> row;
        if (row.size() < static_cast<size_t>(n)) row.resize(static_cast<size_t>(n));
        for (int r = lo; r < hi; ++r) {
            fill_row(r, row.data());
            rp.forward(row.data(), spec + static_cast<size_t>(r) * bins * 2);
        }
    });
    columns(spec, n, bins, cp, /*inverse=*/false);
}

// r2c spectrum -> rows. Unscaled; the consumer applies 1/(n*n).
template <typename T, typename TakeRow>
void inverse2_rows(T* spec, TakeRow take_row, int n, int bins,
                   const RfftPlanT<T>& rp, const FftPlanT<T>& cp) {
    columns(spec, n, bins, cp, /*inverse=*/true);
    parallel_for(0, n, [&](int lo, int hi) {
        thread_local std::vector<T> row;
        if (row.size() < static_cast<size_t>(n)) row.resize(static_cast<size_t>(n));
        for (int r = lo; r < hi; ++r) {
            rp.inverse(spec + static_cast<size_t>(r) * bins * 2, row.data());
            take_row(r, row.data());
        }
    });
}

}  // namespace

int fft_convolve_transform_size(int w, int h, int ks, int max_transform) {
    if (ks < 1 || w < 1 || h < 1) return 0;
    const int ph = h + ks - 1;
    const int pw = w + ks - 1;
    // Never transform larger than the padded plane -- that is the single-tile case
    // and any more would be wasted work.
    const int ideal = fft_next_pow2(std::max(ph, pw));
    // ...but never so small that B = N - ks + 1 <= 0.
    const int floor_n = fft_next_pow2(ks + 1);
    int cap = fft_next_pow2(std::max(max_transform, 1));
    if (cap < floor_n) cap = floor_n;
    const int top = std::min(ideal, cap);

    // Pick the CHEAPEST admissible transform, not the largest one. Taking the
    // largest was wrong in both directions, measured on this operator (8 workers,
    // -O2, times are the best of two):
    //
    //   1536 px, ks=651   N=1024  25 tiles   375 ms   <- cheapest
    //                     N=2048   4 tiles   386 ms
    //                     N=4096   1 tile    767 ms   <- what "largest" picked
    //   12 MP,   ks=1725  N=2048 130 tiles  9298 ms   <- what the old cap picked
    //                     N=4096   4 tiles  1861 ms   <- cheapest, 5.0x faster
    //                     N=8192   1 tile   3094 ms
    //
    // A bigger transform buys a bigger usable block B = N - ks + 1 and so fewer
    // tiles, but each transform costs more than N^2 log N in practice because the
    // column pass is memory-bound: measured per-element cost roughly doubles per
    // doubling of N, far faster than log2 N grows. kCostExponent captures that
    // empirically -- it ranks all six measurements above correctly, where a pure
    // N^2 log N model ranks two of them backwards.
    //
    // It is a heuristic over a discrete, tiny candidate set, so being a little off
    // costs some speed and never a wrong answer: every candidate computes the same
    // operator, and the choice stays a pure function of (w, h, ks, cap), which is
    // what keeps output byte-identical across worker counts.
    constexpr double kCostExponent = 2.8;
    double best_cost = -1.0;
    int best_n = top;
    for (int n = floor_n; n <= top; n *= 2) {
        const int block = n - ks + 1;
        if (block <= 0) continue;
        const double tiles = std::ceil(static_cast<double>(h) / block) *
                             std::ceil(static_cast<double>(w) / block);
        const double cost = tiles * std::pow(static_cast<double>(n), kCostExponent);
        if (best_cost < 0.0 || cost < best_cost) {
            best_cost = cost;
            best_n = n;
        }
    }
    return best_n;
}

template <typename T>
static bool fft_convolve_same_impl(const T* padded, int pw, int ph,
                                   const T* kern, int ks,
                                   int w, int h,
                                   T* out, int out_stride, int out_offset,
                                   int max_transform,
                                   bool deny_scratch_for_test,
                                   int forced_n) {
    if (!padded || !kern || !out) return false;
    if (ks < 1 || (ks % 2) == 0) return false;          // odd kernels only
    if (w < 1 || h < 1) return false;
    if (pw != w + ks - 1 || ph != h + ks - 1) return false;
    if (out_stride < 1 || out_offset < 0 || out_offset >= out_stride) return false;

    // forced_n is the measurement seam: it runs a transform the cost model would
    // have REJECTED, which is the only way to check the model's ranking against a
    // stopwatch rather than against itself. Zero everywhere else.
    const int n = forced_n > 0 ? forced_n
                              : fft_convolve_transform_size(w, h, ks, max_transform);
    if (n < ks + 1 || (n & (n - 1)) != 0) return false;
    const int block = n - ks + 1;                        // exact outputs per tile
    const int bins  = n / 2 + 1;                         // kept Hermitian columns
    const size_t spec_sz  = static_cast<size_t>(n) * bins * 2;
    const size_t plane_sz = static_cast<size_t>(n) * n;

    // Fail closed on scratch denial. The diffusion caller selected this path
    // because the direct convolution is prohibitively expensive; returning
    // false here used to turn memory pressure into an hours-long fallback.
    if (deny_scratch_for_test) throw std::bad_alloc{};
    std::vector<T> kspec(spec_sz, T(0));
    std::vector<T> tspec(spec_sz, T(0));
    (void)plane_sz;  // the real plane is produced row by row, never stored

    const RfftPlanT<T> rp(n);
    const FftPlanT<T>  cp(n);

    // Kernel spectrum: kern at the ORIGIN (see the derivation above), zero elsewhere.
    forward2_rows(
        [&](int r, T* dst) {
            std::fill(dst, dst + n, 0.0);
            if (r < ks)
                for (int j = 0; j < ks; ++j)
                    dst[j] = kern[static_cast<size_t>(r) * ks + j];
        },
        kspec.data(), n, bins, rp, cp);

    // Two unscaled inverse transforms are applied per tile (columns, then rows),
    // each wanting 1/n.
    const T scale = static_cast<T>(1.0 / (static_cast<double>(n) * static_cast<double>(n)));

    for (int y0 = 0; y0 < h; y0 += block) {
        for (int x0 = 0; x0 < w; x0 += block) {
            // Load the n x n input window at (y0, x0). Rows/cols past the padded
            // plane are zero; they only ever feed outputs beyond (h, w), which are
            // discarded below.
            const int rows = std::min(n, ph - y0);
            const int cols = std::min(n, pw - x0);
            forward2_rows(
                [&](int r, T* dst) {
                    std::fill(dst, dst + n, 0.0);
                    if (r < rows) {
                        const T* src =
                            padded + static_cast<size_t>(y0 + r) * pw + x0;
                        for (int j = 0; j < cols; ++j) dst[j] = src[j];
                    }
                },
                tspec.data(), n, bins, rp, cp);

            // Pointwise complex multiply by the kernel spectrum.
            parallel_for(0, n, [&](int lo, int hi) {
                for (int i = lo; i < hi; ++i) {
                    T* t = tspec.data() + static_cast<size_t>(i) * bins * 2;
                    const T* k = kspec.data() + static_cast<size_t>(i) * bins * 2;
                    int j = 0;
#if defined(__aarch64__)
                    if constexpr (std::is_same<T, double>::value) {
                        for (; j + 1 < bins; j += 2) {
                            float64x2x2_t z = vld2q_f64(t + j * 2);
                            float64x2x2_t w = vld2q_f64(k + j * 2);
                            float64x2_t tr = vsubq_f64(vmulq_f64(z.val[0], w.val[0]),
                                                       vmulq_f64(z.val[1], w.val[1]));
                            float64x2_t ti = vaddq_f64(vmulq_f64(z.val[0], w.val[1]),
                                                       vmulq_f64(z.val[1], w.val[0]));
                            float64x2x2_t o{tr, ti};
                            vst2q_f64(t + j * 2, o);
                        }
                    }
#endif
#if defined(_OPENMP)
#pragma omp simd
#endif
                    for (; j < bins; ++j) {
                        const T ar = t[j * 2], ai = t[j * 2 + 1];
                        const T br = k[j * 2], bi = k[j * 2 + 1];
                        t[j * 2]     = ar * br - ai * bi;
                        t[j * 2 + 1] = ar * bi + ai * br;
                    }
                }
            });

            // Exact outputs live at [ks-1 + i][ks-1 + j] for i,j in [0, block).
            const int ny = std::min(block, h - y0);
            const int nx = std::min(block, w - x0);
            inverse2_rows(
                tspec.data(),
                [&](int r, const T* row) {
                    const int i = r - (ks - 1);
                    if (i < 0 || i >= ny) return;   // a row nobody reads
                    const T* src = row + (ks - 1);
                    T* dst = out + (static_cast<size_t>(y0 + i) * w + x0) *
                                            out_stride + out_offset;
                    for (int j = 0; j < nx; ++j)
                        dst[static_cast<size_t>(j) * out_stride] = src[j] * scale;
                },
                n, bins, rp, cp);
        }
    }
    return true;
}

template <typename T>
bool fft_convolve_same(const T* padded, int pw, int ph,
                       const T* kern, int ks,
                       int w, int h,
                       T* out, int out_stride, int out_offset,
                       int max_transform) {
    return fft_convolve_same_impl(
        padded, pw, ph, kern, ks, w, h, out, out_stride, out_offset,
        max_transform, /*deny_scratch_for_test=*/false, /*forced_n=*/0);
}

#if defined(SPK_FFT_CONVOLVE_TEST_HOOKS)
bool fft_convolve_same_denied_scratch_for_test(
        const double* padded, int pw, int ph, const double* kern, int ks,
        int w, int h, double* out, int out_stride, int out_offset,
        int max_transform) {
    return fft_convolve_same_impl(
        padded, pw, ph, kern, ks, w, h, out, out_stride, out_offset,
        max_transform, /*deny_scratch_for_test=*/true, /*forced_n=*/0);
}

bool fft_convolve_same_forced_n_for_test(
        const double* padded, int pw, int ph, const double* kern, int ks,
        int w, int h, double* out, int out_stride, int out_offset,
        int forced_n) {
    return fft_convolve_same_impl(
        padded, pw, ph, kern, ks, w, h, out, out_stride, out_offset,
        forced_n, /*deny_scratch_for_test=*/false, forced_n);
}
#endif

// Explicit instantiations: double for the engine and the parity suite, float to
// be measured against it (owner request, 2026-09-10).
template bool fft_convolve_same<double>(const double*, int, int, const double*, int,
                                        int, int, double*, int, int, int);
template bool fft_convolve_same<float>(const float*, int, int, const float*, int,
                                       int, int, float*, int, int, int);

}  // namespace spk
