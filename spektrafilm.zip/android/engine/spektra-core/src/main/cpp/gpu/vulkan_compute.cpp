/*
 * Spektrafilm for Android — GPU (Vulkan compute) fast-path implementation. GPLv3.
 * Film modeling powered by spektrafilm.
 *
 * Compiled only when SPK_ENABLE_VULKAN is defined (see gpu/vulkan_compute.h and
 * CMakeLists.txt). Headless compute: instance -> physical device + compute queue ->
 * host-visible storage buffers -> compute pipeline (embedded SPIR-V) -> dispatch ->
 * read back. Every failure path returns false so the caller falls back to the CPU.
 *
 * PERSISTENT HOST (GPU M1, #146): the scan kernel's pipeline, descriptor set,
 * command buffer and buffers are created once and reused across calls (buffers
 * grow-only), instead of being rebuilt per dispatch. The PR #145 device probe
 * measured the old per-call host at ~25-48 ms of fixed overhead per dispatch —
 * killing that cost is the preview-tier win. The vendored SPIR-V is UNCHANGED, so
 * the probe's published Tier 1 error numbers still describe the shipped binary.
 * Calls are serialized by a mutex (one queue, one command buffer); on any Vulkan
 * failure the kernel state is torn down and the call returns false (CPU fallback),
 * so a later call can retry from scratch.
 *
 * NaN GUARD (#145 caveat, mandated by #146): GLSL clamp(NaN) is implementation-
 * defined, so the engine's NaN-density -> black semantics must not rest on driver
 * behaviour. The input upload maps every non-finite density component to 1e4f
 * (10^-1e4 underflows to exactly 0 in fp32 -> zero transmittance -> black), which
 * is deterministic on every conformant driver. Finite inputs are copied verbatim,
 * so the probe's error measurements are unaffected.
 */
#include "gpu/vulkan_compute.h"
#include "runtime/memory_budget.h"
#include "runtime/stage_timer.h"

namespace spk::gpu {

PointwiseDispatchGrid plan_pointwise_dispatch(uint32_t pixel_count,
                                              uint32_t max_groups_x,
                                              uint32_t max_groups_y) noexcept {
    PointwiseDispatchGrid grid{};
    if (pixel_count == 0 || max_groups_x == 0 || max_groups_y == 0) return grid;
    constexpr uint64_t kWorkgroupSize = 64;
    constexpr uint64_t kMaxSafeGroupsX = UINT32_MAX / kWorkgroupSize;
    const uint64_t groups = (static_cast<uint64_t>(pixel_count) + kWorkgroupSize - 1) /
                            kWorkgroupSize;
    uint64_t groups_x = groups < max_groups_x ? groups : max_groups_x;
    if (groups_x > kMaxSafeGroupsX) groups_x = kMaxSafeGroupsX;
    const uint64_t groups_y = (groups + groups_x - 1) / groups_x;
    if (groups_y > max_groups_y || groups_x * groups_y > UINT32_MAX) return grid;
    grid.groups_x = static_cast<uint32_t>(groups_x);
    grid.groups_y = static_cast<uint32_t>(groups_y);
    grid.total_groups = static_cast<uint32_t>(groups);
    grid.group_row_stride_pixels = groups_x * kWorkgroupSize;
    grid.valid = true;
    return grid;
}

const char* pointwise_fallback_reason_name(PointwiseFallbackReason reason) noexcept {
    switch (reason) {
        case PointwiseFallbackReason::none: return "none";
        case PointwiseFallbackReason::vulkan_disabled: return "vulkan-disabled";
        case PointwiseFallbackReason::unavailable: return "vulkan-unavailable";
        case PointwiseFallbackReason::invalid_request: return "invalid-request";
        case PointwiseFallbackReason::request_too_large: return "request-too-large";
        case PointwiseFallbackReason::allocation_failed: return "allocation-failed";
        case PointwiseFallbackReason::pipeline_failed: return "pipeline-failed";
        case PointwiseFallbackReason::upload_failed: return "upload-failed";
        case PointwiseFallbackReason::dispatch_failed: return "dispatch-failed";
        case PointwiseFallbackReason::readback_failed: return "readback-failed";
    }
    return "unknown";
}

}  // namespace spk::gpu

#ifndef SPK_ENABLE_VULKAN

namespace spk::gpu {
bool render_pointwise_chain(const PointwiseChainRequest&, PointwiseChainOutput*,
                            PointwiseChainDiagnostics* diagnostics) noexcept {
    if (diagnostics) {
        *diagnostics = {};
        diagnostics->fallback_reason = PointwiseFallbackReason::vulkan_disabled;
    }
    return false;
}
bool available() { return false; }
uint64_t max_storage_buffer_range() { return 0; }
bool cctf_encode_srgb(float*, size_t) { return false; }
bool scan_spectral(const float*, float*, uint32_t, const float*, const float*, const float*) { return false; }
bool scan_spectral_linear(const float*, float*, uint32_t, const float*, const float*, const float*) { return false; }
bool gaussian_blur_rgb(double*, int, int, const double*) { return false; }
bool gaussian_blur_rgb_f32(float*, int, int, const double*) { return false; }
bool glare_field(float*, int, int, const GlareRequest&, GlareDiagnostics* d) {
    if (d) { *d = GlareDiagnostics{}; d->reason = "vulkan-disabled"; }
    return false;
}
bool frame_open(const double*, int, int, FrameDiagnostics* d) {
    if (d) { *d = FrameDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool frame_close(double*, FrameDiagnostics* d) {
    if (d) { *d = FrameDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
void frame_discard() {}
bool frame_active(int, int) { return false; }
bool filming_expose(const double*, const float*, double, uint32_t, int, int,
                    const double*, uint32_t, double, double*, float*,
                    FilmingStageDiagnostics* d) {
    if (d) { *d = FilmingStageDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool subtract_per_channel(const float*, float*, int, int, const double*,
                          FilmingStageDiagnostics* d) {
    if (d) { *d = FilmingStageDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool grain_layers(const float*, uint32_t, int, int, const float*, const float*,
                  uint32_t, bool, float*, FilmingStageDiagnostics* d) {
    if (d) { *d = FilmingStageDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool exposure_log10(const double*, float*, int, int, FilmingStageDiagnostics* d) {
    if (d) { *d = FilmingStageDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool blend_mix(const double*, const double*, double*, int, int, double, bool,
               FilmingStageDiagnostics* d) {
    if (d) { *d = FilmingStageDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool highlight_boost(double*, int, int, double, double, double,
                     FilmingStageDiagnostics* d) {
    if (d) { *d = FilmingStageDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool filming_develop(const float*, uint32_t, int, int, const float*, const float*,
                     uint32_t, float*, FilmingStageDiagnostics* d) {
    if (d) { *d = FilmingStageDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool fft_convolve(const FftConvolveRequest&, double*, FftConvolveDiagnostics* d) {
    if (d) { *d = FftConvolveDiagnostics{}; d->attempted = true; d->reason = "vulkan-disabled"; }
    return false;
}
bool grain_sample(const GrainSampleRequest&, float*, GrainSampleDiagnostics* d) {
    if (d) { *d = GrainSampleDiagnostics{}; d->reason = "vulkan-disabled"; }
    return false;
}
bool halation_scatter(const HalationScatterRequest&, double*,
                      HalationScatterDiagnostics* diagnostics) noexcept {
    if (diagnostics) {
        *diagnostics = {};
        diagnostics->reason = "vulkan-disabled";
    }
    return false;
}
}  // namespace spk::gpu

#else

#include <vulkan/vulkan.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <mutex>
#include <new>
#include <vector>

#include "gpu/cctf_encode_spv.h"
#include "gpu/fft_convolve_spv.h"
#include "gpu/filming_stage_spv.h"
#include "gpu/filming_spv.h"
#include "kernels/fft_convolve.h"
#include "gpu/glare_spv.h"
#include "gpu/grain_spv.h"
#include "gpu/halation_scatter_spv.h"
#include "kernels/parallel.h"
#include "gpu/printing_spv.h"
#include "gpu/scan_spectral_chain_spv.h"
#include "gpu/scan_spectral_lin_spv.h"
#include "gpu/scan_spectral_spv.h"

namespace spk::gpu {
namespace {

// Adreno 610 hangs on an oversized/invalid compute dispatch; waiting forever
// is the 26 MP "infinite export". Bound every fence so the caller fails closed
// to CPU instead of never returning.
constexpr uint64_t kFenceTimeoutNs = 8ull * 1000ull * 1000ull * 1000ull;

// One host-visible storage buffer + its memory + its persistent mapping.

struct Buf {
    VkBuffer buf = VK_NULL_HANDLE;
    VkDeviceMemory mem = VK_NULL_HANDLE;
    void* mapped = nullptr;
    VkDeviceSize cap = 0;
    // Admission against the process coordinator, released when the buffer is.
    // Device memory was invisible to it until now: a 12.5 MP Fast GPU export
    // holds ~571 MiB of device-local buffers, which is more than the whole
    // COMPACT tier, and it reported as zero.
    spk::memory::MemoryReservation reservation;
};

// SPDX-FileCopyrightText: 2026 Spektrafilm Android contributors
// SPDX-License-Identifier: GPL-3.0-only
// Resource lifetime, private scratch, keyed static uploads and single-command
// DAG/barrier concepts adapted from chaert-s/spektrafilm-ofx
// src/SpektraVulkanRenderer.cpp at
// 86476afc5b077de77e2278e3658d1ba9309892a1. This Android implementation is a
// new bounded three-stage API: one mapped bidirectional staging buffer, two
// device-local ping-pong buffers, and no OpenFX/desktop host integration.
struct ResidentBuf {
    VkBuffer buf = VK_NULL_HANDLE;
    VkDeviceMemory mem = VK_NULL_HANDLE;
    void* mapped = nullptr;
    VkDeviceSize cap = 0;
    VkDeviceSize allocationSize = 0;
    VkMemoryPropertyFlags memoryFlags = 0;
    spk::memory::MemoryReservation reservation;
};

enum PointwiseTable : size_t {
    kFilmTc = 0,
    kFilmDevelopAxis,
    kFilmDevelopCurve,
    kFilmDirAxis,
    kFilmDirCurve,
    kPrintDye,
    kPrintIlluminantSensitivity,
    kPrintPaperAxis,
    kPrintPaperCurve,
    kScanDye,
    kScanIlluminantCmf,
    kPointwiseTableCount,
};

struct Ctx {
    VkInstance instance = VK_NULL_HANDLE;
    VkPhysicalDevice phys = VK_NULL_HANDLE;
    VkDevice device = VK_NULL_HANDLE;
    VkQueue queue = VK_NULL_HANDLE;
    uint32_t queueFamily = 0;
    VkPhysicalDeviceProperties properties{};
    VkPhysicalDeviceMemoryProperties memoryProperties{};
    bool ok = false;
    // Set when a fence wait hits kFenceTimeoutNs. Further GPU work is refused
    // and teardown skips vkDeviceWaitIdle (that wait is also unbounded).
    bool hung = false;
    // The fence is idle and the result must not be published. Distinct from
    // hung: the device and the queue are still usable, so teardown must not run.
    bool last_wait_cancelled = false;

    // Slice the wait so a cancel is noticed within 50 ms. A cancel never
    // returns while the submission is still running: the fence is drained
    // (bounded by the same 8 s cap) and reset before we report failure.
    // Destroying a command buffer that the queue still owns is a use-after-free
    // on Mali and Adreno. Timing out still marks the context hung, same as before.
    bool waitFence(VkFence fence) {
        last_wait_cancelled = false;
        if (!device || fence == VK_NULL_HANDLE) return false;
        uint64_t waited = 0;
        constexpr uint64_t kSliceNs = 50ull * 1000ull * 1000ull;
        auto drain_cancelled = [&](uint64_t already) -> bool {
            const uint64_t left = already < kFenceTimeoutNs ? kFenceTimeoutNs - already : 0;
            const VkResult drained =
                vkWaitForFences(device, 1, &fence, VK_TRUE, left);
            if (drained == VK_SUCCESS) {
                // Idle. Safe to reuse the fence and to keep the pipelines.
                // A timeout leaves last_wait_cancelled false so the caller
                // tears the context down instead of resetting a live queue.
                last_wait_cancelled = true;
                vkResetFences(device, 1, &fence);
                return false;
            }
            if (drained == VK_TIMEOUT) {
                hung = true;
                ok = false;
            }
            return false;
        };
        while (waited < kFenceTimeoutNs) {
            if (spk::parallel_cancellation_requested()) return drain_cancelled(waited);
            const uint64_t remain = kFenceTimeoutNs - waited;
            const uint64_t slice = remain < kSliceNs ? remain : kSliceNs;
            const VkResult r = vkWaitForFences(device, 1, &fence, VK_TRUE, slice);
            if (r == VK_SUCCESS) {
                if (spk::parallel_cancellation_requested()) return drain_cancelled(waited);
                return true;
            }
            if (r != VK_TIMEOUT) return false;
            waited += slice;
        }
        hung = true;
        ok = false;
        return false;
    }

    // Persistent per-kernel state (built lazily on the kernel's first call).
    // The full-chain (scan_spectral.comp) and linear (scan_spectral_lin.comp)
    // kernels share this shape — identical bindings + push-constant layout —
    // but keep separate pipelines and buffers.
    struct Kernel {
        VkShaderModule shader = VK_NULL_HANDLE;
        VkDescriptorSetLayout dsl = VK_NULL_HANDLE;
        VkPipelineLayout pl = VK_NULL_HANDLE;
        VkPipeline pipe = VK_NULL_HANDLE;
        VkDescriptorPool dpool = VK_NULL_HANDLE;
        VkDescriptorSet dset = VK_NULL_HANDLE;  // freed with dpool
        VkCommandPool cpool = VK_NULL_HANDLE;
        VkCommandBuffer cmd = VK_NULL_HANDLE;   // freed with cpool
        VkFence fence = VK_NULL_HANDLE;
        Buf in, out, dyeB, cmfB;                // in/out grow-only; tables fixed
        bool pipelineReady = false;
        // Whether the descriptor set currently names the RESIDENT frame
        // planes rather than the mapped in/out pair (#220). Switching
        // between them changes which buffers the set points at, so it has
        // to force a rewrite the same way growing a buffer does.
        bool boundResident = false;
    };
    Kernel scanFused;  // scan_spectral.comp (density -> encoded sRGB)
    Kernel scanLin;    // scan_spectral_lin.comp (density -> unclipped linear RGB)
    // grain.comp (#214) reuses this shape exactly: four storage bindings
    // (density cells, accumulated output, per-cell constants, one atomic
    // counter) and a push constant that fits inside the range the scan layout
    // already declares. So it needs no pipeline code of its own -- the buffer
    // ROLES differ, not the layout.
    Kernel grainK;
    // glare.comp (#215): same four-binding shape again (xyz in, xyz out, blur
    // taps, one unused slot the layout requires).
    Kernel glareK;
    // fft_convolve.comp (#216): the same four-binding shape once more. Its push
    // block is larger than the scan one, which is the only reason
    // build_scan_pipeline takes a push size.
    //
    // ITS SCRATCH IS DEVICE-LOCAL AND UNMAPPED, unlike every other kernel here,
    // and that is the difference between this pass working and not. A, B and the
    // twiddle/kernel-spectrum table are touched ONLY by the GPU -- 26 whole-plane
    // passes per tile, ~7 GB of traffic at n = 4096 -- while Ctx::ensureBuf hands
    // out HOST_VISIBLE|HOST_COHERENT memory, which a mobile driver may serve
    // uncached or write-combined. Measured effective bandwidth on that memory was
    // 10-19 GB/s against a part that should manage several times more. Only the
    // real plane (host writes the source, host reads the output) stays mapped.
    Kernel fftK;                          // pipeline objects + the mapped buffers
    std::array<ResidentBuf, 3> fftWork{};  // A, B, twiddles+kernel spectrum

    // The resident frame (#220): a device-local ping-pong pair carrying the
    // f32 interleaved plane between passes, plus the one host-visible staging
    // buffer the single upload and single readback go through. `front` names
    // the half holding the current image; a pass that writes flips it.
    struct FrameResidency {
        std::array<ResidentBuf, 2> plane{};
        Buf staging;
        VkCommandPool cpool = VK_NULL_HANDLE;
        VkCommandBuffer cmd = VK_NULL_HANDLE;
        VkFence fence = VK_NULL_HANDLE;
        int width = 0;
        int height = 0;
        uint32_t front = 0;
        bool open = false;
    } frame;
    // filming_stage.comp (#218): four bindings again -- source, destination,
    // the tc_lut and the concatenated axis|curve table.
    Kernel filmK;
    // halation_scatter.comp (#206): one pipeline, eleven descriptor sets (one
    // per buffer-role permutation of the op sequence), four device-local
    // whole-frame work buffers, one mapped staging band, one frame-floats
    // buffer. Grow-only like the scan kernels; torn down on failure only.
    struct HalationKernel {
        VkShaderModule shader = VK_NULL_HANDLE;
        VkDescriptorSetLayout dsl = VK_NULL_HANDLE;
        VkPipelineLayout pl = VK_NULL_HANDLE;
        VkPipeline pipe = VK_NULL_HANDLE;
        VkDescriptorPool dpool = VK_NULL_HANDLE;
        std::array<VkDescriptorSet, 11> dsets{};
        VkCommandPool cpool = VK_NULL_HANDLE;
        VkCommandBuffer cmd = VK_NULL_HANDLE;
        VkFence fence = VK_NULL_HANDLE;
        Buf staging;                       // host-visible, mapped: upload + readback band
        Buf frame;                         // FrameFloats (binding 27)
        std::array<ResidentBuf, 4> work{}; // src, sum, x, xT (device-local preferred)
        bool pipelineReady = false;
    } halation;

    struct PointwiseChain {
        std::array<VkShaderModule, 3> shaders{};
        std::array<VkDescriptorSetLayout, 3> descriptorLayouts{};
        std::array<VkPipelineLayout, 3> pipelineLayouts{};
        std::array<VkPipeline, 3> pipelines{};
        VkDescriptorPool descriptorPool = VK_NULL_HANDLE;
        std::array<VkDescriptorSet, 3> descriptorSets{};
        VkCommandPool commandPool = VK_NULL_HANDLE;
        VkCommandBuffer commandBuffer = VK_NULL_HANDLE;
        VkFence fence = VK_NULL_HANDLE;
        ResidentBuf frameStaging;
        std::array<ResidentBuf, 2> ping{};
        ResidentBuf staticStaging;
        std::array<ResidentBuf, kPointwiseTableCount> tables{};
        std::array<VkDeviceSize, kPointwiseTableCount> cachedTableBytes{};
        uint64_t cachedTableKey = 0;
        bool pipelinesReady = false;
    } pointwise;

    bool init() {
        VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
        app.pApplicationName = "spektra";
        app.apiVersion = VK_API_VERSION_1_1;
        VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
        ici.pApplicationInfo = &app;
        if (vkCreateInstance(&ici, nullptr, &instance) != VK_SUCCESS) return false;

        uint32_t nphys = 0;
        vkEnumeratePhysicalDevices(instance, &nphys, nullptr);
        if (nphys == 0) return false;
        std::vector<VkPhysicalDevice> devs(nphys);
        vkEnumeratePhysicalDevices(instance, &nphys, devs.data());
        phys = devs[0];
        vkGetPhysicalDeviceProperties(phys, &properties);
        vkGetPhysicalDeviceMemoryProperties(phys, &memoryProperties);

        uint32_t nq = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(phys, &nq, nullptr);
        std::vector<VkQueueFamilyProperties> qprops(nq);
        vkGetPhysicalDeviceQueueFamilyProperties(phys, &nq, qprops.data());
        bool found = false;
        for (uint32_t i = 0; i < nq; ++i) {
            if (qprops[i].queueFlags & VK_QUEUE_COMPUTE_BIT) { queueFamily = i; found = true; break; }
        }
        if (!found) return false;

        float pri = 1.0f;
        VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
        qci.queueFamilyIndex = queueFamily;
        qci.queueCount = 1;
        qci.pQueuePriorities = &pri;
        VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
        dci.queueCreateInfoCount = 1;
        dci.pQueueCreateInfos = &qci;
        if (vkCreateDevice(phys, &dci, nullptr, &device) != VK_SUCCESS) return false;
        vkGetDeviceQueue(device, queueFamily, 0, &queue);
        ok = true;
        return true;
    }

    void destroyBuf(Buf& b) {
        if (b.mapped) { vkUnmapMemory(device, b.mem); b.mapped = nullptr; }
        if (b.mem) { vkFreeMemory(device, b.mem, nullptr); b.mem = VK_NULL_HANDLE; }
        if (b.buf) { vkDestroyBuffer(device, b.buf, nullptr); b.buf = VK_NULL_HANDLE; }
        b.cap = 0;
        b.reservation.reset();
    }

    void destroyResidentBuf(ResidentBuf& b) {
        if (b.mapped) {
            vkUnmapMemory(device, b.mem);
            b.mapped = nullptr;
        }
        if (b.buf) {
            vkDestroyBuffer(device, b.buf, nullptr);
            b.buf = VK_NULL_HANDLE;
        }
        if (b.mem) {
            vkFreeMemory(device, b.mem, nullptr);
            b.mem = VK_NULL_HANDLE;
        }
        b.cap = 0;
        b.allocationSize = 0;
        b.memoryFlags = 0;
        b.reservation.reset();
    }

    void destroyPointwise() {
        if (!device) return;
        if (!hung) vkDeviceWaitIdle(device);
        PointwiseChain& s = pointwise;
        if (s.fence) {
            vkDestroyFence(device, s.fence, nullptr);
            s.fence = VK_NULL_HANDLE;
        }
        if (s.commandPool) {
            vkDestroyCommandPool(device, s.commandPool, nullptr);
            s.commandPool = VK_NULL_HANDLE;
            s.commandBuffer = VK_NULL_HANDLE;
        }
        if (s.descriptorPool) {
            vkDestroyDescriptorPool(device, s.descriptorPool, nullptr);
            s.descriptorPool = VK_NULL_HANDLE;
            s.descriptorSets = {};
        }
        for (VkPipeline& pipeline : s.pipelines) {
            if (pipeline) vkDestroyPipeline(device, pipeline, nullptr);
            pipeline = VK_NULL_HANDLE;
        }
        for (VkPipelineLayout& layout : s.pipelineLayouts) {
            if (layout) vkDestroyPipelineLayout(device, layout, nullptr);
            layout = VK_NULL_HANDLE;
        }
        for (VkDescriptorSetLayout& layout : s.descriptorLayouts) {
            if (layout) vkDestroyDescriptorSetLayout(device, layout, nullptr);
            layout = VK_NULL_HANDLE;
        }
        for (VkShaderModule& shader : s.shaders) {
            if (shader) vkDestroyShaderModule(device, shader, nullptr);
            shader = VK_NULL_HANDLE;
        }
        destroyResidentBuf(s.frameStaging);
        for (ResidentBuf& b : s.ping) destroyResidentBuf(b);
        destroyResidentBuf(s.staticStaging);
        for (ResidentBuf& b : s.tables) destroyResidentBuf(b);
        s.cachedTableBytes = {};
        s.cachedTableKey = 0;
        s.pipelinesReady = false;
    }

    // `avoid` exists because DEVICE_LOCAL alone does not mean what it sounds
    // like on a unified-memory phone: every memory type there is DEVICE_LOCAL,
    // and the FIRST one is typically also HOST_VISIBLE|HOST_COHERENT. Asking
    // for DEVICE_LOCAL and taking the first match therefore hands back exactly
    // the host-coherent memory a GPU-only scratch buffer wants to escape --
    // which a driver may serve uncached or write-combined. Naming the bits to
    // shun is the only way to express "GPU-private if such a type exists".
    //
    // Three passes, widening: shun+prefer, prefer, required. A device with no
    // GPU-private type still gets an allocation rather than a refusal.
    int findPreferredMemType(uint32_t bits, VkMemoryPropertyFlags required,
                             VkMemoryPropertyFlags preferred,
                             VkMemoryPropertyFlags avoid = 0) const {
        for (uint32_t pass = 0; pass < 3; ++pass) {
            const VkMemoryPropertyFlags wanted =
                pass == 2 ? required : (required | preferred);
            const VkMemoryPropertyFlags shun = pass == 0 ? avoid : 0;
            for (uint32_t i = 0; i < memoryProperties.memoryTypeCount; ++i) {
                const VkMemoryPropertyFlags flags =
                    memoryProperties.memoryTypes[i].propertyFlags;
                if ((bits & (1u << i)) && (flags & wanted) == wanted &&
                    (flags & shun) == 0) {
                    return static_cast<int>(i);
                }
            }
        }
        return -1;
    }

    VkDeviceSize largestHeapFor(VkMemoryPropertyFlags required) const {
        VkDeviceSize largest = 0;
        for (uint32_t i = 0; i < memoryProperties.memoryTypeCount; ++i) {
            if ((memoryProperties.memoryTypes[i].propertyFlags & required) != required) continue;
            const uint32_t heap = memoryProperties.memoryTypes[i].heapIndex;
            if (heap < memoryProperties.memoryHeapCount &&
                memoryProperties.memoryHeaps[heap].size > largest) {
                largest = memoryProperties.memoryHeaps[heap].size;
            }
        }
        return largest;
    }

    bool ensureResidentBuf(ResidentBuf& b, VkDeviceSize bytes,
                           VkBufferUsageFlags usage,
                           VkMemoryPropertyFlags required,
                           VkMemoryPropertyFlags preferred,
                           bool persistentMap,
                           PointwiseChainDiagnostics& diagnostics,
                           VkMemoryPropertyFlags avoid = 0) {
        if (bytes == 0) return false;
        if (b.buf && b.mem && b.cap >= bytes &&
            (b.memoryFlags & required) == required && (!persistentMap || b.mapped)) {
            return true;
        }

        destroyResidentBuf(b);
        VkBuffer buffer = VK_NULL_HANDLE;
        VkDeviceMemory memory = VK_NULL_HANDLE;
        VkBufferCreateInfo bci{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bci.size = bytes;
        bci.usage = usage;
        bci.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        if (vkCreateBuffer(device, &bci, nullptr, &buffer) != VK_SUCCESS) return false;

        VkMemoryRequirements req{};
        vkGetBufferMemoryRequirements(device, buffer, &req);
        const int memoryType =
            findPreferredMemType(req.memoryTypeBits, required, preferred, avoid);
        if (memoryType < 0) {
            vkDestroyBuffer(device, buffer, nullptr);
            return false;
        }
        const uint32_t heapIndex = memoryProperties.memoryTypes[memoryType].heapIndex;
        if (heapIndex >= memoryProperties.memoryHeapCount ||
            req.size > memoryProperties.memoryHeaps[heapIndex].size) {
            vkDestroyBuffer(device, buffer, nullptr);
            return false;
        }
        // Admission BEFORE the driver allocation, so a device over its budget
        // is refused here and the caller falls back to the CPU, rather than
        // discovering it as a driver OOM or an Android low-memory kill. The
        // default coordinator limit is unbounded, so this changes nothing until
        // a limit is actually set.
        const bool deviceLocal =
            (memoryProperties.memoryTypes[memoryType].propertyFlags &
             VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) != 0;
        spk::memory::MemoryReservation reservation =
            spk::memory::process_memory_budget().try_reserve(
                static_cast<std::uint64_t>(req.size),
                deviceLocal ? spk::memory::MemoryDomain::GpuDevice
                            : spk::memory::MemoryDomain::GpuHost,
                spk::memory::MemoryStage::Gpu);
        if (!reservation) {
            vkDestroyBuffer(device, buffer, nullptr);
            return false;
        }
        VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        mai.allocationSize = req.size;
        mai.memoryTypeIndex = static_cast<uint32_t>(memoryType);
        if (vkAllocateMemory(device, &mai, nullptr, &memory) != VK_SUCCESS) {
            vkDestroyBuffer(device, buffer, nullptr);
            return false;
        }
        if (vkBindBufferMemory(device, buffer, memory, 0) != VK_SUCCESS) {
            vkDestroyBuffer(device, buffer, nullptr);
            vkFreeMemory(device, memory, nullptr);
            return false;
        }

        void* mapped = nullptr;
        if (persistentMap &&
            vkMapMemory(device, memory, 0, VK_WHOLE_SIZE, 0, &mapped) != VK_SUCCESS) {
            vkDestroyBuffer(device, buffer, nullptr);
            vkFreeMemory(device, memory, nullptr);
            return false;
        }
        b.buf = buffer;
        b.mem = memory;
        b.mapped = mapped;
        b.cap = bytes;
        b.reservation = std::move(reservation);
        b.allocationSize = req.size;
        b.memoryFlags = memoryProperties.memoryTypes[memoryType].propertyFlags;
        ++diagnostics.buffer_allocations;
        return true;
    }

    bool flushResident(const ResidentBuf& b) const {
        if ((b.memoryFlags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT) != 0) return true;
        VkMappedMemoryRange range{VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE};
        range.memory = b.mem;
        range.offset = 0;
        range.size = VK_WHOLE_SIZE;
        return vkFlushMappedMemoryRanges(device, 1, &range) == VK_SUCCESS;
    }

    bool invalidateResident(const ResidentBuf& b) const {
        if ((b.memoryFlags & VK_MEMORY_PROPERTY_HOST_COHERENT_BIT) != 0) return true;
        VkMappedMemoryRange range{VK_STRUCTURE_TYPE_MAPPED_MEMORY_RANGE};
        range.memory = b.mem;
        range.offset = 0;
        range.size = VK_WHOLE_SIZE;
        return vkInvalidateMappedMemoryRanges(device, 1, &range) == VK_SUCCESS;
    }

    // Tear down all persistent kernel state (failure recovery only — never runs
    // at process exit, see the deliberate leak below).
    void destroyKernel(Kernel& s) {
        if (s.fence) { vkDestroyFence(device, s.fence, nullptr); s.fence = VK_NULL_HANDLE; }
        if (s.cpool) { vkDestroyCommandPool(device, s.cpool, nullptr); s.cpool = VK_NULL_HANDLE; s.cmd = VK_NULL_HANDLE; }
        if (s.dpool) { vkDestroyDescriptorPool(device, s.dpool, nullptr); s.dpool = VK_NULL_HANDLE; s.dset = VK_NULL_HANDLE; }
        if (s.pipe) { vkDestroyPipeline(device, s.pipe, nullptr); s.pipe = VK_NULL_HANDLE; }
        if (s.pl) { vkDestroyPipelineLayout(device, s.pl, nullptr); s.pl = VK_NULL_HANDLE; }
        if (s.dsl) { vkDestroyDescriptorSetLayout(device, s.dsl, nullptr); s.dsl = VK_NULL_HANDLE; }
        if (s.shader) { vkDestroyShaderModule(device, s.shader, nullptr); s.shader = VK_NULL_HANDLE; }
        destroyBuf(s.in);
        destroyBuf(s.out);
        destroyBuf(s.dyeB);
        destroyBuf(s.cmfB);
        s.pipelineReady = false;
    }

    void destroyFrame() {
        if (!device) return;
        if (frame.fence) { vkDestroyFence(device, frame.fence, nullptr); frame.fence = VK_NULL_HANDLE; }
        if (frame.cpool) {
            vkDestroyCommandPool(device, frame.cpool, nullptr);
            frame.cpool = VK_NULL_HANDLE;
            frame.cmd = VK_NULL_HANDLE;
        }
        for (ResidentBuf& b : frame.plane) destroyResidentBuf(b);
        destroyBuf(frame.staging);
        frame.width = frame.height = 0;
        frame.front = 0;
        frame.open = false;
    }

    // One staging <-> plane copy, submitted and waited on. Both directions go
    // through the same path because both are a single vkCmdCopyBuffer with the
    // barrier that makes the write visible to whoever reads next.
    bool frameCopy(bool toDevice, VkDeviceSize bytes) {
        if (vkResetCommandBuffer(frame.cmd, 0) != VK_SUCCESS) return false;
        VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        if (vkBeginCommandBuffer(frame.cmd, &bi) != VK_SUCCESS) return false;
        VkMemoryBarrier pre{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
        pre.srcAccessMask = toDevice ? VK_ACCESS_HOST_WRITE_BIT : VK_ACCESS_SHADER_WRITE_BIT;
        pre.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
        vkCmdPipelineBarrier(frame.cmd,
                             toDevice ? VK_PIPELINE_STAGE_HOST_BIT
                                      : VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                             VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 1, &pre, 0, nullptr, 0, nullptr);
        VkBufferCopy region{0, 0, bytes};
        if (toDevice)
            vkCmdCopyBuffer(frame.cmd, frame.staging.buf, frame.plane[frame.front].buf, 1, &region);
        else
            vkCmdCopyBuffer(frame.cmd, frame.plane[frame.front].buf, frame.staging.buf, 1, &region);
        VkMemoryBarrier post{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
        post.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
        post.dstAccessMask = toDevice ? VK_ACCESS_SHADER_READ_BIT : VK_ACCESS_HOST_READ_BIT;
        vkCmdPipelineBarrier(frame.cmd, VK_PIPELINE_STAGE_TRANSFER_BIT,
                             toDevice ? VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT
                                      : VK_PIPELINE_STAGE_HOST_BIT,
                             0, 1, &post, 0, nullptr, 0, nullptr);
        if (vkEndCommandBuffer(frame.cmd) != VK_SUCCESS) return false;
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.commandBufferCount = 1;
        si.pCommandBuffers = &frame.cmd;
        if (vkQueueSubmit(queue, 1, &si, frame.fence) != VK_SUCCESS) return false;
        if (!waitFence(frame.fence)) return false;
        return vkResetFences(device, 1, &frame.fence) == VK_SUCCESS;
    }

    void destroyScan() {
        if (!device) return;
        if (!hung) vkDeviceWaitIdle(device);
        destroyKernel(scanFused);
        destroyKernel(scanLin);
        destroyKernel(grainK);
        destroyKernel(glareK);
        destroyKernel(fftK);
        for (ResidentBuf& b : fftWork) destroyResidentBuf(b);
        destroyFrame();
        destroyKernel(filmK);
    }
    void destroyHalation() {
        if (!device) return;
        if (!hung) vkDeviceWaitIdle(device);
        HalationKernel& k = halation;
        if (k.fence) { vkDestroyFence(device, k.fence, nullptr); k.fence = VK_NULL_HANDLE; }
        if (k.cpool) { vkDestroyCommandPool(device, k.cpool, nullptr); k.cpool = VK_NULL_HANDLE; k.cmd = VK_NULL_HANDLE; }
        if (k.dpool) { vkDestroyDescriptorPool(device, k.dpool, nullptr); k.dpool = VK_NULL_HANDLE; k.dsets.fill(VK_NULL_HANDLE); }
        if (k.pipe) { vkDestroyPipeline(device, k.pipe, nullptr); k.pipe = VK_NULL_HANDLE; }
        if (k.pl) { vkDestroyPipelineLayout(device, k.pl, nullptr); k.pl = VK_NULL_HANDLE; }
        if (k.dsl) { vkDestroyDescriptorSetLayout(device, k.dsl, nullptr); k.dsl = VK_NULL_HANDLE; }
        if (k.shader) { vkDestroyShaderModule(device, k.shader, nullptr); k.shader = VK_NULL_HANDLE; }
        destroyBuf(k.staging);
        destroyBuf(k.frame);
        for (ResidentBuf& b : k.work) destroyResidentBuf(b);
        k.pipelineReady = false;
    }

    int findMemType(uint32_t bits, VkMemoryPropertyFlags want) {
        VkPhysicalDeviceMemoryProperties mp;
        vkGetPhysicalDeviceMemoryProperties(phys, &mp);
        for (uint32_t i = 0; i < mp.memoryTypeCount; ++i)
            if ((bits & (1u << i)) && (mp.memoryTypes[i].propertyFlags & want) == want) return (int)i;
        return -1;
    }

    // Create (or grow) a HOST_VISIBLE|COHERENT storage buffer and keep it mapped.
    // Same memory type as the per-call host the probe validated; only the
    // lifetime changed. Returns false on any Vulkan failure.
    //
    // HOST_CACHED is PREFERRED, not required (#148). These buffers are read
    // back by the host -- the scan readback alone is ~143 MiB a slice -- and an
    // uncached (write-combined) mapping is fast to write and slow to read,
    // which is the wrong trade for a buffer that is both. COHERENT stays
    // REQUIRED, so adding CACHED changes no synchronisation: there is still no
    // explicit flush or invalidate to get wrong. A device without a
    // cached+coherent type falls back to the original coherent-only type.
    bool ensureBuf(Buf& b, VkDeviceSize bytes) {
        if (b.cap >= bytes && b.buf) return true;
        destroyBuf(b);
        VkBufferCreateInfo bci{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bci.size = bytes;
        // TRANSFER_SRC/DST because the halation pass stages through this buffer
        // with vkCmdCopyBuffer in both directions; a copy to or from a buffer
        // created without them is invalid use, which validation layers reject
        // and a driver may honour or not.
        bci.usage = VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT |
                    VK_BUFFER_USAGE_TRANSFER_DST_BIT;
        bci.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        if (vkCreateBuffer(device, &bci, nullptr, &b.buf) != VK_SUCCESS) return false;
        VkMemoryRequirements req;
        vkGetBufferMemoryRequirements(device, b.buf, &req);
        constexpr VkMemoryPropertyFlags kHostRequired =
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT;
        int mt = findMemType(req.memoryTypeBits, kHostRequired | VK_MEMORY_PROPERTY_HOST_CACHED_BIT);
        if (mt < 0) mt = findMemType(req.memoryTypeBits, kHostRequired);
        if (mt < 0) return false;
        b.reservation = spk::memory::process_memory_budget().try_reserve(
            static_cast<std::uint64_t>(req.size), spk::memory::MemoryDomain::GpuHost,
            spk::memory::MemoryStage::Gpu);
        if (!b.reservation) return false;
        VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        mai.allocationSize = req.size;
        mai.memoryTypeIndex = (uint32_t)mt;
        if (vkAllocateMemory(device, &mai, nullptr, &b.mem) != VK_SUCCESS) return false;
        if (vkBindBufferMemory(device, b.buf, b.mem, 0) != VK_SUCCESS) return false;
        if (vkMapMemory(device, b.mem, 0, VK_WHOLE_SIZE, 0, &b.mapped) != VK_SUCCESS) return false;
        b.cap = bytes;
        return true;
    }
};

// One lazily-initialised context for the process, plus the lock serializing all
// GPU entry points (one queue + one reusable command buffer).
//
// The context is DELIBERATELY LEAKED (new, never deleted): running Vulkan
// teardown from a static destructor at process exit crashes on ICDs whose own
// statics unload first (observed as a SIGSEGV under SwiftShader), and Android
// kills app processes without running static destructors anyway. destroyScan()
// exists for mid-process FAILURE recovery, where the device is alive and the
// calls are safe.
std::mutex& gpu_mutex() { static std::mutex m; return m; }
Ctx& ctx() {
    static Ctx* c = nullptr;
    if (!c) { c = new Ctx(); c->init(); }
    return *c;
}

struct ScanPush { uint32_t npix; float m[12]; };  // std430 push constant (matches both shaders)

// Adreno 610 reports ~134-140 MiB. Whole-frame RGB f32 at 12 MP is 144 MiB and
// at 26 MP is 312 MiB — both exceed the binding range, and a "successful"
// dispatch into an oversize buffer reads back zeros (black negative / white
// slide). Every storage buffer is therefore capped here, and the callers slice.
constexpr VkDeviceSize kSafeStorageBytes = 112ull << 20;

static VkDeviceSize clamp_storage(VkDeviceSize reported) {
    return reported < kSafeStorageBytes ? reported : kSafeStorageBytes;
}

// Build one kernel's persistent pipeline objects (everything except the
// grow-only image buffers) from its SPIR-V blob. Called once per kernel; on
// failure the caller tears down via destroyScan().
// `pushBytes` exists because gpu/fft_convolve.comp's push block (72 bytes) is
// wider than ScanPush (52). Declaring a range shorter than the shader reads is
// invalid use that a driver may honour or not, so the size is the caller's.
bool build_scan_pipeline(Ctx& c, Ctx::Kernel& s, const uint32_t* spv, size_t spvBytes,
                         uint32_t pushBytes = sizeof(ScanPush)) {
    VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    smci.codeSize = spvBytes;
    smci.pCode = spv;
    if (vkCreateShaderModule(c.device, &smci, nullptr, &s.shader) != VK_SUCCESS) return false;

    VkDescriptorSetLayoutBinding b[4]{};
    for (uint32_t i = 0; i < 4; ++i) {
        b[i].binding = i;
        b[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
        b[i].descriptorCount = 1;
        b[i].stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
    }
    VkDescriptorSetLayoutCreateInfo dlci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    dlci.bindingCount = 4;
    dlci.pBindings = b;
    if (vkCreateDescriptorSetLayout(c.device, &dlci, nullptr, &s.dsl) != VK_SUCCESS) return false;

    VkPushConstantRange pcr{VK_SHADER_STAGE_COMPUTE_BIT, 0, pushBytes};
    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    plci.setLayoutCount = 1;
    plci.pSetLayouts = &s.dsl;
    plci.pushConstantRangeCount = 1;
    plci.pPushConstantRanges = &pcr;
    if (vkCreatePipelineLayout(c.device, &plci, nullptr, &s.pl) != VK_SUCCESS) return false;

    VkComputePipelineCreateInfo cpci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
    cpci.stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    cpci.stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
    cpci.stage.module = s.shader;
    cpci.stage.pName = "main";
    cpci.layout = s.pl;
    if (vkCreateComputePipelines(c.device, VK_NULL_HANDLE, 1, &cpci, nullptr, &s.pipe) != VK_SUCCESS) return false;

    VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 4};
    VkDescriptorPoolCreateInfo dpci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dpci.maxSets = 1;
    dpci.poolSizeCount = 1;
    dpci.pPoolSizes = &ps;
    if (vkCreateDescriptorPool(c.device, &dpci, nullptr, &s.dpool) != VK_SUCCESS) return false;
    VkDescriptorSetAllocateInfo dsai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dsai.descriptorPool = s.dpool;
    dsai.descriptorSetCount = 1;
    dsai.pSetLayouts = &s.dsl;
    if (vkAllocateDescriptorSets(c.device, &dsai, &s.dset) != VK_SUCCESS) return false;

    VkCommandPoolCreateInfo cpci2{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    cpci2.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    cpci2.queueFamilyIndex = c.queueFamily;
    if (vkCreateCommandPool(c.device, &cpci2, nullptr, &s.cpool) != VK_SUCCESS) return false;
    VkCommandBufferAllocateInfo cbai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cbai.commandPool = s.cpool;
    cbai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cbai.commandBufferCount = 1;
    if (vkAllocateCommandBuffers(c.device, &cbai, &s.cmd) != VK_SUCCESS) return false;

    VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    if (vkCreateFence(c.device, &fci, nullptr, &s.fence) != VK_SUCCESS) return false;

    s.pipelineReady = true;
    return true;
}

struct PointwiseFilmPush {
    uint32_t npix;
    uint32_t groupsX;
    uint32_t totalGroups;
    int32_t edge;
    int32_t curvePoints;
    float exposureMultiplier;
    float couplerShift;
    float couplerMatrix[9];
};

struct PointwisePrintPush {
    uint32_t npix;
    uint32_t groupsX;
    uint32_t totalGroups;
    int32_t curvePoints;
    float midgray;
    float exposureMultiplier;
    float preflash[3];
};

struct PointwiseScanPush {
    uint32_t npix;
    uint32_t groupsX;
    uint32_t totalGroups;
    float matrix[12];
};

static_assert(sizeof(PointwiseFilmPush) == 64, "filming push layout drift");
static_assert(sizeof(PointwisePrintPush) == 36, "printing push layout drift");
static_assert(sizeof(PointwiseScanPush) == 60, "scan push layout drift");

struct PreparedPointwiseRequest {
    size_t componentCount = 0;
    VkDeviceSize frameBytes = 0;
    VkDeviceSize staticBytes = 0;
    std::array<PointwiseTableSpan, kPointwiseTableCount> tables{};
    std::array<VkDeviceSize, kPointwiseTableCount> tableBytes{};
};

bool finite_span(const PointwiseTableSpan& span) {
    if (!span.data || span.count == 0) return false;
    for (size_t i = 0; i < span.count; ++i) {
        if (!std::isfinite(span.data[i])) return false;
    }
    return true;
}

bool finite_values(const float* values, size_t count) {
    if (!values) return false;
    for (size_t i = 0; i < count; ++i) {
        if (!std::isfinite(values[i])) return false;
    }
    return true;
}

bool strictly_increasing_planar3(const PointwiseTableSpan& axis, uint32_t points) {
    if (!axis.data || points < 2 || axis.count != static_cast<size_t>(points) * 3u) {
        return false;
    }
    for (uint32_t row = 1; row < points; ++row) {
        for (uint32_t channel = 0; channel < 3; ++channel) {
            if (!(axis.data[static_cast<size_t>(row - 1) * 3u + channel] <
                  axis.data[static_cast<size_t>(row) * 3u + channel])) {
                return false;
            }
        }
    }
    return true;
}

bool prepare_pointwise_request(const PointwiseChainRequest& request,
                               const PointwiseChainOutput* output,
                               PreparedPointwiseRequest& prepared,
                               PointwiseFallbackReason& reason) {
    constexpr uint32_t kMaxTcEdge = 1024;
    constexpr uint32_t kMaxCurvePoints = 65536;
    constexpr uint64_t kMaxStaticBytes = UINT64_C(64) * 1024u * 1024u;

    if (!output || !output->rgb || !request.input_rgb || request.pixel_count == 0 ||
        request.static_table_key == 0) {
        reason = PointwiseFallbackReason::invalid_request;
        return false;
    }
    const uint64_t components64 = static_cast<uint64_t>(request.pixel_count) * 3u;
    const uint64_t frameBytes64 = components64 * sizeof(float);
    if (components64 > std::numeric_limits<size_t>::max() ||
        frameBytes64 > std::numeric_limits<VkDeviceSize>::max()) {
        reason = PointwiseFallbackReason::request_too_large;
        return false;
    }
    prepared.componentCount = static_cast<size_t>(components64);
    prepared.frameBytes = static_cast<VkDeviceSize>(frameBytes64);
    if (request.input_component_count < prepared.componentCount ||
        output->component_capacity < prepared.componentCount) {
        reason = PointwiseFallbackReason::invalid_request;
        return false;
    }

    const uint32_t edge = request.film.tc_edge;
    const uint32_t filmPoints = request.film.curve_points;
    const uint32_t printPoints = request.print.curve_points;
    if (edge < 2 || edge > kMaxTcEdge || filmPoints < 2 ||
        filmPoints > kMaxCurvePoints || printPoints < 2 ||
        printPoints > kMaxCurvePoints) {
        reason = PointwiseFallbackReason::invalid_request;
        return false;
    }
    const uint64_t tcCount = static_cast<uint64_t>(edge) * edge * 3u;
    const uint64_t filmCurveCount = static_cast<uint64_t>(filmPoints) * 3u;
    const uint64_t printCurveCount = static_cast<uint64_t>(printPoints) * 3u;

    prepared.tables[kFilmTc] = request.film.tc_lut;
    prepared.tables[kFilmDevelopAxis] = request.film.develop_axis;
    prepared.tables[kFilmDevelopCurve] = request.film.develop_curve;
    prepared.tables[kFilmDirAxis] = request.film.dir_axis;
    prepared.tables[kFilmDirCurve] = request.film.dir_curve;
    prepared.tables[kPrintDye] = request.print.dye;
    prepared.tables[kPrintIlluminantSensitivity] = request.print.illuminant_sensitivity;
    prepared.tables[kPrintPaperAxis] = request.print.paper_axis;
    prepared.tables[kPrintPaperCurve] = request.print.paper_curve;
    prepared.tables[kScanDye] = request.scan.dye;
    prepared.tables[kScanIlluminantCmf] = request.scan.illuminant_cmf;
    const uint64_t expected[kPointwiseTableCount] = {
        tcCount,
        filmCurveCount, filmCurveCount, filmCurveCount, filmCurveCount,
        81u * 3u, 81u * 3u,
        printCurveCount, printCurveCount,
        81u * 3u, 81u * 3u,
    };

    uint64_t staticBytes = 0;
    for (size_t i = 0; i < kPointwiseTableCount; ++i) {
        if (expected[i] > std::numeric_limits<size_t>::max() ||
            prepared.tables[i].count != static_cast<size_t>(expected[i]) ||
            !finite_span(prepared.tables[i])) {
            reason = PointwiseFallbackReason::invalid_request;
            return false;
        }
        const uint64_t bytes = expected[i] * sizeof(float);
        if (bytes > std::numeric_limits<VkDeviceSize>::max() ||
            bytes > kMaxStaticBytes ||
            staticBytes > kMaxStaticBytes - bytes) {
            reason = PointwiseFallbackReason::request_too_large;
            return false;
        }
        prepared.tableBytes[i] = static_cast<VkDeviceSize>(bytes);
        staticBytes += bytes;
    }
    prepared.staticBytes = static_cast<VkDeviceSize>(staticBytes);

    if (!strictly_increasing_planar3(request.film.develop_axis, filmPoints) ||
        !strictly_increasing_planar3(request.film.dir_axis, filmPoints) ||
        !strictly_increasing_planar3(request.print.paper_axis, printPoints) ||
        !std::isfinite(request.film.exposure_multiplier) ||
        !std::isfinite(request.film.coupler_shift) ||
        !finite_values(request.film.coupler_matrix, 9) ||
        !std::isfinite(request.print.midgray) ||
        !std::isfinite(request.print.exposure_multiplier) ||
        !finite_values(request.print.preflash, 3) ||
        !finite_values(request.scan.xyz_to_rgb, 9)) {
        reason = PointwiseFallbackReason::invalid_request;
        return false;
    }
    reason = PointwiseFallbackReason::none;
    return true;
}

bool build_pointwise_pipelines(Ctx& c, PointwiseChainDiagnostics& diagnostics) {
    Ctx::PointwiseChain& s = c.pointwise;
    if (s.pipelinesReady) return true;
    const uint32_t* spirv[3] = {
        kPointwiseFilmingSpv, kPointwisePrintingSpv, kPointwiseScanSpectralSpv,
    };
    const size_t spirvBytes[3] = {
        sizeof(kPointwiseFilmingSpv), sizeof(kPointwisePrintingSpv),
        sizeof(kPointwiseScanSpectralSpv),
    };
    const uint32_t bindingCounts[3] = {7, 6, 4};
    const uint32_t pushBytes[3] = {
        sizeof(PointwiseFilmPush), sizeof(PointwisePrintPush), sizeof(PointwiseScanPush),
    };

    for (size_t stage = 0; stage < 3; ++stage) {
        if (pushBytes[stage] > c.properties.limits.maxPushConstantsSize) return false;
        VkShaderModuleCreateInfo shaderInfo{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
        shaderInfo.codeSize = spirvBytes[stage];
        shaderInfo.pCode = spirv[stage];
        if (vkCreateShaderModule(c.device, &shaderInfo, nullptr, &s.shaders[stage]) != VK_SUCCESS) {
            return false;
        }

        std::array<VkDescriptorSetLayoutBinding, 7> bindings{};
        for (uint32_t binding = 0; binding < bindingCounts[stage]; ++binding) {
            bindings[binding].binding = binding;
            bindings[binding].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
            bindings[binding].descriptorCount = 1;
            bindings[binding].stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
        }
        VkDescriptorSetLayoutCreateInfo descriptorInfo{
            VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
        descriptorInfo.bindingCount = bindingCounts[stage];
        descriptorInfo.pBindings = bindings.data();
        if (vkCreateDescriptorSetLayout(c.device, &descriptorInfo, nullptr,
                                        &s.descriptorLayouts[stage]) != VK_SUCCESS) {
            return false;
        }

        VkPushConstantRange pushRange{VK_SHADER_STAGE_COMPUTE_BIT, 0, pushBytes[stage]};
        VkPipelineLayoutCreateInfo layoutInfo{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
        layoutInfo.setLayoutCount = 1;
        layoutInfo.pSetLayouts = &s.descriptorLayouts[stage];
        layoutInfo.pushConstantRangeCount = 1;
        layoutInfo.pPushConstantRanges = &pushRange;
        if (vkCreatePipelineLayout(c.device, &layoutInfo, nullptr,
                                   &s.pipelineLayouts[stage]) != VK_SUCCESS) {
            return false;
        }

        VkComputePipelineCreateInfo pipelineInfo{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
        pipelineInfo.stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
        pipelineInfo.stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
        pipelineInfo.stage.module = s.shaders[stage];
        pipelineInfo.stage.pName = "main";
        pipelineInfo.layout = s.pipelineLayouts[stage];
        if (vkCreateComputePipelines(c.device, VK_NULL_HANDLE, 1, &pipelineInfo, nullptr,
                                     &s.pipelines[stage]) != VK_SUCCESS) {
            return false;
        }
        ++diagnostics.pipeline_creates;
    }

    VkDescriptorPoolSize poolSize{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 17};
    VkDescriptorPoolCreateInfo poolInfo{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    poolInfo.maxSets = 3;
    poolInfo.poolSizeCount = 1;
    poolInfo.pPoolSizes = &poolSize;
    if (vkCreateDescriptorPool(c.device, &poolInfo, nullptr, &s.descriptorPool) != VK_SUCCESS) {
        return false;
    }
    VkDescriptorSetAllocateInfo allocateSets{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    allocateSets.descriptorPool = s.descriptorPool;
    allocateSets.descriptorSetCount = 3;
    allocateSets.pSetLayouts = s.descriptorLayouts.data();
    if (vkAllocateDescriptorSets(c.device, &allocateSets, s.descriptorSets.data()) != VK_SUCCESS) {
        return false;
    }

    VkCommandPoolCreateInfo commandPoolInfo{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    commandPoolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    commandPoolInfo.queueFamilyIndex = c.queueFamily;
    if (vkCreateCommandPool(c.device, &commandPoolInfo, nullptr, &s.commandPool) != VK_SUCCESS) {
        return false;
    }
    VkCommandBufferAllocateInfo allocateCommand{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    allocateCommand.commandPool = s.commandPool;
    allocateCommand.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    allocateCommand.commandBufferCount = 1;
    if (vkAllocateCommandBuffers(c.device, &allocateCommand, &s.commandBuffer) != VK_SUCCESS) {
        return false;
    }
    VkFenceCreateInfo fenceInfo{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    if (vkCreateFence(c.device, &fenceInfo, nullptr, &s.fence) != VK_SUCCESS) return false;
    s.pipelinesReady = true;
    return true;
}

void update_pointwise_descriptors(Ctx& c, const PreparedPointwiseRequest& prepared) {
    Ctx::PointwiseChain& s = c.pointwise;
    std::array<VkDescriptorBufferInfo, 17> infos{};
    std::array<VkWriteDescriptorSet, 17> writes{};
    size_t count = 0;
    auto add = [&](size_t stage, uint32_t binding, const ResidentBuf& buffer,
                   VkDeviceSize range) {
        infos[count] = VkDescriptorBufferInfo{buffer.buf, 0, range};
        writes[count] = VkWriteDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
        writes[count].dstSet = s.descriptorSets[stage];
        writes[count].dstBinding = binding;
        writes[count].descriptorCount = 1;
        writes[count].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
        writes[count].pBufferInfo = &infos[count];
        ++count;
    };

    add(0, 0, s.ping[0], prepared.frameBytes);
    add(0, 1, s.ping[1], prepared.frameBytes);
    for (size_t i = kFilmTc; i <= kFilmDirCurve; ++i) {
        add(0, static_cast<uint32_t>(i - kFilmTc + 2), s.tables[i], prepared.tableBytes[i]);
    }
    add(1, 0, s.ping[1], prepared.frameBytes);
    add(1, 1, s.ping[0], prepared.frameBytes);
    for (size_t i = kPrintDye; i <= kPrintPaperCurve; ++i) {
        add(1, static_cast<uint32_t>(i - kPrintDye + 2), s.tables[i], prepared.tableBytes[i]);
    }
    add(2, 0, s.ping[0], prepared.frameBytes);
    add(2, 1, s.ping[1], prepared.frameBytes);
    add(2, 2, s.tables[kScanDye], prepared.tableBytes[kScanDye]);
    add(2, 3, s.tables[kScanIlluminantCmf], prepared.tableBytes[kScanIlluminantCmf]);
    vkUpdateDescriptorSets(c.device, static_cast<uint32_t>(count), writes.data(), 0, nullptr);
}

}  // namespace

bool render_pointwise_chain(const PointwiseChainRequest& request,
                            PointwiseChainOutput* output,
                            PointwiseChainDiagnostics* diagnostics) noexcept {
    PointwiseChainDiagnostics localDiagnostics{};
    PointwiseChainDiagnostics& d = diagnostics ? *diagnostics : localDiagnostics;
    d = {};

    // This public seam is noexcept and fail-closed. First-use context creation
    // performs C++ allocations (including temporary Vulkan enumeration vectors),
    // so bad_alloc or another runtime exception must become an ordinary fallback
    // rather than std::terminate. Caller output is not touched until every GPU
    // operation and the finite readback validation below have completed.
    try {

    PreparedPointwiseRequest prepared{};
    PointwiseFallbackReason validationReason = PointwiseFallbackReason::none;
    if (!prepare_pointwise_request(request, output, prepared, validationReason)) {
        d.fallback_reason = validationReason;
        return false;
    }

    std::lock_guard<std::mutex> lock(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok) {
        d.fallback_reason = PointwiseFallbackReason::unavailable;
        return false;
    }
    const VkPhysicalDeviceLimits& limits = c.properties.limits;
    if (limits.maxComputeWorkGroupInvocations < 64 || limits.maxComputeWorkGroupSize[0] < 64) {
        d.fallback_reason = PointwiseFallbackReason::unavailable;
        return false;
    }
    if (limits.maxMemoryAllocationCount < 15) {
        d.fallback_reason = PointwiseFallbackReason::unavailable;
        return false;
    }
    const PointwiseDispatchGrid grid = plan_pointwise_dispatch(
        request.pixel_count, limits.maxComputeWorkGroupCount[0],
        limits.maxComputeWorkGroupCount[1]);
    if (!grid.valid || prepared.frameBytes > limits.maxStorageBufferRange) {
        d.fallback_reason = PointwiseFallbackReason::request_too_large;
        return false;
    }
    for (VkDeviceSize bytes : prepared.tableBytes) {
        if (bytes > limits.maxStorageBufferRange) {
            d.fallback_reason = PointwiseFallbackReason::request_too_large;
            return false;
        }
    }

    Ctx::PointwiseChain& s = c.pointwise;
    bool staticCacheHit = s.cachedTableKey == request.static_table_key &&
                          s.cachedTableBytes == prepared.tableBytes;
    for (size_t i = 0; i < kPointwiseTableCount && staticCacheHit; ++i) {
        staticCacheHit = s.tables[i].buf && s.tables[i].cap >= prepared.tableBytes[i];
    }

    // Conservative heap preflight when VK_EXT_memory_budget is not enabled.
    // Driver allocation results remain authoritative, but impossible whole-frame
    // requests fail before tearing down a useful warm cache.
    const uint64_t deviceBytes = static_cast<uint64_t>(prepared.frameBytes) * 2u +
                                 static_cast<uint64_t>(prepared.staticBytes);
    const uint64_t hostBytes = static_cast<uint64_t>(prepared.frameBytes) +
                               static_cast<uint64_t>(prepared.staticBytes);
    if (deviceBytes > c.largestHeapFor(VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) ||
        hostBytes > c.largestHeapFor(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) {
        d.fallback_reason = PointwiseFallbackReason::allocation_failed;
        return false;
    }

    auto fail = [&](PointwiseFallbackReason reason) {
        d.engaged = false;
        d.fallback_reason = reason;
        c.destroyPointwise();
        return false;
    };

    if (!build_pointwise_pipelines(c, d)) {
        return fail(PointwiseFallbackReason::pipeline_failed);
    }

    constexpr VkBufferUsageFlags kFrameStagingUsage =
        VK_BUFFER_USAGE_TRANSFER_SRC_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    constexpr VkBufferUsageFlags kPingUsage =
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT |
        VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    if (!c.ensureResidentBuf(s.frameStaging, prepared.frameBytes, kFrameStagingUsage,
                             VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,
                             VK_MEMORY_PROPERTY_HOST_COHERENT_BIT |
                                 VK_MEMORY_PROPERTY_HOST_CACHED_BIT,
                             true, d) ||
        // Interstage only -- the chain uploads through frameStaging and reads
        // back through it, so the ping buffers are never host-mapped and should
        // be GPU-private where the device offers it.
        !c.ensureResidentBuf(s.ping[0], prepared.frameBytes, kPingUsage,
                             VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, 0, false, d,
                             VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT) ||
        !c.ensureResidentBuf(s.ping[1], prepared.frameBytes, kPingUsage,
                             VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, 0, false, d,
                             VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) {
        return fail(PointwiseFallbackReason::allocation_failed);
    }

    std::array<VkDeviceSize, kPointwiseTableCount> staticOffsets{};
    if (!staticCacheHit) {
        constexpr VkBufferUsageFlags kStaticUsage =
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT;
        if (!c.ensureResidentBuf(s.staticStaging, prepared.staticBytes,
                                 VK_BUFFER_USAGE_TRANSFER_SRC_BIT,
                                 VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,
                                 VK_MEMORY_PROPERTY_HOST_COHERENT_BIT,
                                 true, d)) {
            return fail(PointwiseFallbackReason::allocation_failed);
        }
        VkDeviceSize offset = 0;
        for (size_t i = 0; i < kPointwiseTableCount; ++i) {
            if (!c.ensureResidentBuf(s.tables[i], prepared.tableBytes[i], kStaticUsage,
                                     VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, 0, false, d)) {
                return fail(PointwiseFallbackReason::allocation_failed);
            }
            staticOffsets[i] = offset;
            std::memcpy(static_cast<unsigned char*>(s.staticStaging.mapped) + offset,
                        prepared.tables[i].data,
                        static_cast<size_t>(prepared.tableBytes[i]));
            offset += prepared.tableBytes[i];
        }
        if (!c.flushResident(s.staticStaging)) {
            return fail(PointwiseFallbackReason::upload_failed);
        }
        d.static_upload_bytes = prepared.staticBytes;
    }

    std::memcpy(s.frameStaging.mapped, request.input_rgb,
                static_cast<size_t>(prepared.frameBytes));
    if (!c.flushResident(s.frameStaging)) {
        return fail(PointwiseFallbackReason::upload_failed);
    }
    update_pointwise_descriptors(c, prepared);

    PointwiseFilmPush filmPush{};
    filmPush.npix = request.pixel_count;
    filmPush.groupsX = grid.groups_x;
    filmPush.totalGroups = grid.total_groups;
    filmPush.edge = static_cast<int32_t>(request.film.tc_edge);
    filmPush.curvePoints = static_cast<int32_t>(request.film.curve_points);
    filmPush.exposureMultiplier = request.film.exposure_multiplier;
    filmPush.couplerShift = request.film.coupler_shift;
    std::memcpy(filmPush.couplerMatrix, request.film.coupler_matrix,
                sizeof(filmPush.couplerMatrix));

    PointwisePrintPush printPush{};
    printPush.npix = request.pixel_count;
    printPush.groupsX = grid.groups_x;
    printPush.totalGroups = grid.total_groups;
    printPush.curvePoints = static_cast<int32_t>(request.print.curve_points);
    printPush.midgray = request.print.midgray;
    printPush.exposureMultiplier = request.print.exposure_multiplier;
    std::memcpy(printPush.preflash, request.print.preflash, sizeof(printPush.preflash));

    PointwiseScanPush scanPush{};
    scanPush.npix = request.pixel_count;
    scanPush.groupsX = grid.groups_x;
    scanPush.totalGroups = grid.total_groups;
    scanPush.matrix[0] = request.scan.xyz_to_rgb[0];
    scanPush.matrix[1] = request.scan.xyz_to_rgb[1];
    scanPush.matrix[2] = request.scan.xyz_to_rgb[2];
    scanPush.matrix[4] = request.scan.xyz_to_rgb[3];
    scanPush.matrix[5] = request.scan.xyz_to_rgb[4];
    scanPush.matrix[6] = request.scan.xyz_to_rgb[5];
    scanPush.matrix[8] = request.scan.xyz_to_rgb[6];
    scanPush.matrix[9] = request.scan.xyz_to_rgb[7];
    scanPush.matrix[10] = request.scan.xyz_to_rgb[8];

    if (vkResetCommandBuffer(s.commandBuffer, 0) != VK_SUCCESS) {
        return fail(PointwiseFallbackReason::dispatch_failed);
    }
    VkCommandBufferBeginInfo beginInfo{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
    beginInfo.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
    if (vkBeginCommandBuffer(s.commandBuffer, &beginInfo) != VK_SUCCESS) {
        return fail(PointwiseFallbackReason::dispatch_failed);
    }

    VkMemoryBarrier hostWriteBarrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
    hostWriteBarrier.srcAccessMask = VK_ACCESS_HOST_WRITE_BIT;
    hostWriteBarrier.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    vkCmdPipelineBarrier(s.commandBuffer, VK_PIPELINE_STAGE_HOST_BIT,
                         VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 1, &hostWriteBarrier,
                         0, nullptr, 0, nullptr);

    VkBufferCopy frameUpload{0, 0, prepared.frameBytes};
    vkCmdCopyBuffer(s.commandBuffer, s.frameStaging.buf, s.ping[0].buf, 1, &frameUpload);
    if (!staticCacheHit) {
        for (size_t i = 0; i < kPointwiseTableCount; ++i) {
            VkBufferCopy tableUpload{staticOffsets[i], 0, prepared.tableBytes[i]};
            vkCmdCopyBuffer(s.commandBuffer, s.staticStaging.buf, s.tables[i].buf, 1,
                            &tableUpload);
        }
    }

    VkMemoryBarrier uploadBarrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
    uploadBarrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    uploadBarrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT;
    vkCmdPipelineBarrier(s.commandBuffer, VK_PIPELINE_STAGE_TRANSFER_BIT,
                         VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1, &uploadBarrier,
                         0, nullptr, 0, nullptr);

    auto dispatch = [&](size_t stage, const void* push, uint32_t pushBytes) {
        vkCmdBindPipeline(s.commandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE,
                          s.pipelines[stage]);
        vkCmdBindDescriptorSets(s.commandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE,
                                s.pipelineLayouts[stage], 0, 1,
                                &s.descriptorSets[stage], 0, nullptr);
        vkCmdPushConstants(s.commandBuffer, s.pipelineLayouts[stage],
                           VK_SHADER_STAGE_COMPUTE_BIT, 0, pushBytes, push);
        vkCmdDispatch(s.commandBuffer, grid.groups_x, grid.groups_y, 1);
    };
    auto computeBarrier = [&]() {
        VkMemoryBarrier barrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
        barrier.srcAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT;
        barrier.dstAccessMask = VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT;
        vkCmdPipelineBarrier(s.commandBuffer, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                             VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, 0, 1, &barrier,
                             0, nullptr, 0, nullptr);
    };

    dispatch(0, &filmPush, sizeof(filmPush));
    computeBarrier();
    dispatch(1, &printPush, sizeof(printPush));
    computeBarrier();
    dispatch(2, &scanPush, sizeof(scanPush));

    VkMemoryBarrier readbackBarrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
    readbackBarrier.srcAccessMask = VK_ACCESS_SHADER_WRITE_BIT;
    readbackBarrier.dstAccessMask = VK_ACCESS_TRANSFER_READ_BIT;
    vkCmdPipelineBarrier(s.commandBuffer, VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                         VK_PIPELINE_STAGE_TRANSFER_BIT, 0, 1, &readbackBarrier,
                         0, nullptr, 0, nullptr);
    VkBufferCopy frameReadback{0, 0, prepared.frameBytes};
    vkCmdCopyBuffer(s.commandBuffer, s.ping[1].buf, s.frameStaging.buf, 1,
                    &frameReadback);
    VkMemoryBarrier hostReadBarrier{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
    hostReadBarrier.srcAccessMask = VK_ACCESS_TRANSFER_WRITE_BIT;
    hostReadBarrier.dstAccessMask = VK_ACCESS_HOST_READ_BIT;
    vkCmdPipelineBarrier(s.commandBuffer, VK_PIPELINE_STAGE_TRANSFER_BIT,
                         VK_PIPELINE_STAGE_HOST_BIT, 0, 1, &hostReadBarrier,
                         0, nullptr, 0, nullptr);
    if (vkEndCommandBuffer(s.commandBuffer) != VK_SUCCESS) {
        return fail(PointwiseFallbackReason::dispatch_failed);
    }

    VkSubmitInfo submit{VK_STRUCTURE_TYPE_SUBMIT_INFO};
    submit.commandBufferCount = 1;
    submit.pCommandBuffers = &s.commandBuffer;
    if (vkQueueSubmit(c.queue, 1, &submit, s.fence) != VK_SUCCESS) {
        return fail(PointwiseFallbackReason::dispatch_failed);
    }
    if (!c.waitFence(s.fence)) {
        // Cancel already drained and reset the fence. Keep the pipelines so
        // the next frame can submit again. If this call uploaded new static
        // tables, the key still names the previous ones: drop it so the next
        // call reuploads instead of dispatching the new bytes under the old key.
        if (c.last_wait_cancelled) {
            if (!staticCacheHit) {
                s.cachedTableKey = 0;
                s.cachedTableBytes = {};
            }
            d.engaged = false;
            d.fallback_reason = PointwiseFallbackReason::dispatch_failed;
            return false;
        }
        return fail(PointwiseFallbackReason::dispatch_failed);
    }
    if (vkResetFences(c.device, 1, &s.fence) != VK_SUCCESS) {
        return fail(PointwiseFallbackReason::dispatch_failed);
    }
    if (!c.invalidateResident(s.frameStaging)) {
        return fail(PointwiseFallbackReason::readback_failed);
    }

    const float* mappedOutput = static_cast<const float*>(s.frameStaging.mapped);
    for (size_t i = 0; i < prepared.componentCount; ++i) {
        if (!std::isfinite(mappedOutput[i])) {
            return fail(PointwiseFallbackReason::readback_failed);
        }
    }

    std::memcpy(output->rgb, mappedOutput,
                static_cast<size_t>(prepared.frameBytes));
    // These counters describe completed frame work, not merely recorded or
    // submitted commands. Every false return therefore reports zero here.
    d.dispatches = 3;
    d.input_uploads = 1;
    d.final_readbacks = 1;
    d.interstage_host_bytes = 0;
    d.engaged = true;
    d.fallback_reason = PointwiseFallbackReason::none;
    if (!staticCacheHit) {
        s.cachedTableKey = request.static_table_key;
        s.cachedTableBytes = prepared.tableBytes;
    }
    return true;
    } catch (const std::bad_alloc&) {
        d = {};
        d.fallback_reason = PointwiseFallbackReason::allocation_failed;
        return false;
    } catch (...) {
        d = {};
        d.fallback_reason = PointwiseFallbackReason::unavailable;
        return false;
    }
}

bool available() {
    std::lock_guard<std::mutex> lk(gpu_mutex());
    return ctx().ok;
}

uint64_t max_storage_buffer_range() {
    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok) return 0;
    return static_cast<uint64_t>(c.properties.limits.maxStorageBufferRange);
}

bool cctf_encode_srgb(float* data, size_t n) {
    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok || data == nullptr || n == 0) return false;
    const VkDeviceSize bytes = static_cast<VkDeviceSize>(n) * sizeof(float);
    bool ok = false;

    VkBuffer buf = VK_NULL_HANDLE;
    VkDeviceMemory mem = VK_NULL_HANDLE;
    VkShaderModule shader = VK_NULL_HANDLE;
    VkDescriptorSetLayout dsl = VK_NULL_HANDLE;
    VkPipelineLayout pl = VK_NULL_HANDLE;
    VkPipeline pipe = VK_NULL_HANDLE;
    VkDescriptorPool dpool = VK_NULL_HANDLE;
    VkCommandPool cpool = VK_NULL_HANDLE;

    do {
        VkBufferCreateInfo bci{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};
        bci.size = bytes;
        bci.usage = VK_BUFFER_USAGE_STORAGE_BUFFER_BIT;
        bci.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
        if (vkCreateBuffer(c.device, &bci, nullptr, &buf) != VK_SUCCESS) break;

        VkMemoryRequirements req;
        vkGetBufferMemoryRequirements(c.device, buf, &req);
        int mt = c.findMemType(req.memoryTypeBits,
                               VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        if (mt < 0) break;
        VkMemoryAllocateInfo mai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};
        mai.allocationSize = req.size;
        mai.memoryTypeIndex = (uint32_t)mt;
        if (vkAllocateMemory(c.device, &mai, nullptr, &mem) != VK_SUCCESS) break;
        vkBindBufferMemory(c.device, buf, mem, 0);

        // Upload.
        void* mapped = nullptr;
        if (vkMapMemory(c.device, mem, 0, bytes, 0, &mapped) != VK_SUCCESS) break;
        std::memcpy(mapped, data, bytes);
        vkUnmapMemory(c.device, mem);

        VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
        smci.codeSize = sizeof(kCctfEncodeSpv);
        smci.pCode = kCctfEncodeSpv;
        if (vkCreateShaderModule(c.device, &smci, nullptr, &shader) != VK_SUCCESS) break;

        VkDescriptorSetLayoutBinding b{};
        b.binding = 0;
        b.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
        b.descriptorCount = 1;
        b.stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
        VkDescriptorSetLayoutCreateInfo dlci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
        dlci.bindingCount = 1;
        dlci.pBindings = &b;
        if (vkCreateDescriptorSetLayout(c.device, &dlci, nullptr, &dsl) != VK_SUCCESS) break;

        VkPushConstantRange pcr{VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(uint32_t)};
        VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
        plci.setLayoutCount = 1;
        plci.pSetLayouts = &dsl;
        plci.pushConstantRangeCount = 1;
        plci.pPushConstantRanges = &pcr;
        if (vkCreatePipelineLayout(c.device, &plci, nullptr, &pl) != VK_SUCCESS) break;

        VkComputePipelineCreateInfo cpci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
        cpci.stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
        cpci.stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
        cpci.stage.module = shader;
        cpci.stage.pName = "main";
        cpci.layout = pl;
        if (vkCreateComputePipelines(c.device, VK_NULL_HANDLE, 1, &cpci, nullptr, &pipe) != VK_SUCCESS) break;

        VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 1};
        VkDescriptorPoolCreateInfo dpci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
        dpci.maxSets = 1;
        dpci.poolSizeCount = 1;
        dpci.pPoolSizes = &ps;
        if (vkCreateDescriptorPool(c.device, &dpci, nullptr, &dpool) != VK_SUCCESS) break;
        VkDescriptorSetAllocateInfo dsai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
        dsai.descriptorPool = dpool;
        dsai.descriptorSetCount = 1;
        dsai.pSetLayouts = &dsl;
        VkDescriptorSet dset = VK_NULL_HANDLE;
        if (vkAllocateDescriptorSets(c.device, &dsai, &dset) != VK_SUCCESS) break;
        VkDescriptorBufferInfo dbi{buf, 0, bytes};
        VkWriteDescriptorSet wds{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
        wds.dstSet = dset;
        wds.descriptorCount = 1;
        wds.descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
        wds.pBufferInfo = &dbi;
        vkUpdateDescriptorSets(c.device, 1, &wds, 0, nullptr);

        VkCommandPoolCreateInfo cpci2{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        cpci2.queueFamilyIndex = c.queueFamily;
        if (vkCreateCommandPool(c.device, &cpci2, nullptr, &cpool) != VK_SUCCESS) break;
        VkCommandBufferAllocateInfo cbai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        cbai.commandPool = cpool;
        cbai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        cbai.commandBufferCount = 1;
        VkCommandBuffer cmd = VK_NULL_HANDLE;
        if (vkAllocateCommandBuffers(c.device, &cbai, &cmd) != VK_SUCCESS) break;

        VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        vkBeginCommandBuffer(cmd, &bi);
        vkCmdBindPipeline(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pipe);
        vkCmdBindDescriptorSets(cmd, VK_PIPELINE_BIND_POINT_COMPUTE, pl, 0, 1, &dset, 0, nullptr);
        uint32_t count = static_cast<uint32_t>(n);
        vkCmdPushConstants(cmd, pl, VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(uint32_t), &count);
        vkCmdDispatch(cmd, (count + 63) / 64, 1, 1);
        vkEndCommandBuffer(cmd);

        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.commandBufferCount = 1;
        si.pCommandBuffers = &cmd;
        if (vkQueueSubmit(c.queue, 1, &si, VK_NULL_HANDLE) != VK_SUCCESS) break;
        vkQueueWaitIdle(c.queue);

        // Read back.
        if (vkMapMemory(c.device, mem, 0, bytes, 0, &mapped) != VK_SUCCESS) break;
        std::memcpy(data, mapped, bytes);
        vkUnmapMemory(c.device, mem);
        ok = true;
    } while (false);

    if (cpool) vkDestroyCommandPool(c.device, cpool, nullptr);
    if (dpool) vkDestroyDescriptorPool(c.device, dpool, nullptr);
    if (pipe) vkDestroyPipeline(c.device, pipe, nullptr);
    if (pl) vkDestroyPipelineLayout(c.device, pl, nullptr);
    if (dsl) vkDestroyDescriptorSetLayout(c.device, dsl, nullptr);
    if (shader) vkDestroyShaderModule(c.device, shader, nullptr);
    if (mem) vkFreeMemory(c.device, mem, nullptr);
    if (buf) vkDestroyBuffer(c.device, buf, nullptr);
    return ok;
}

// Shared dispatch body for the two scan kernels (mutex held by the callers).
static bool dispatch_scan(Ctx& c, Ctx::Kernel& s, const uint32_t* spv, size_t spvBytes,
                          const float* cmy, float* rgb, uint32_t npix,
                          const float* dye, const float* icmf, const float* xyz2rgb) {
    if (!c.ok || !cmy || !rgb || npix == 0 || !dye || !icmf || !xyz2rgb) return false;
    const int NB = 81;
    const VkDeviceSize tblBytes = static_cast<VkDeviceSize>(NB) * 3u * sizeof(float);
    // SLICING (GPU export, #154): a single dispatch is capped at the
    // spec-guaranteed maxComputeWorkGroupCount floor (65535 groups × 64 =
    // 4,193,280 px) AND at the device storage-buffer range. Full-res exports
    // (a 12.5 MP frame, 144 MiB RGB f32) exceed Adreno 610's ~134 MiB binding
    // range, so the image is processed in slices sized to the SLICE, not the
    // whole image.
    const VkDeviceSize storCap = clamp_storage(c.properties.limits.maxStorageBufferRange);
    uint32_t maxByBytes = static_cast<uint32_t>(storCap / (3u * sizeof(float)));
    if (maxByBytes < 64u) maxByBytes = 64u;
    const uint32_t MAX_WG = 65535u * 64u;  // 4,193,280
    const uint32_t MAX_SLICE = maxByBytes < MAX_WG ? maxByBytes : MAX_WG;
    const uint32_t sliceCap = npix < MAX_SLICE ? npix : MAX_SLICE;
    const VkDeviceSize sliceBytes = static_cast<VkDeviceSize>(sliceCap) * 3u * sizeof(float);
    bool ok = false;

    do {
        if (!s.pipelineReady && !build_scan_pipeline(c, s, spv, spvBytes)) break;

        // Grow-only slice buffers; fixed-size tables. Any (re)creation requires a
        // descriptor rewrite; buffers only change while the queue is idle (each
        // slice's fence is waited before the next), so rewriting descriptors
        // here is race-free under the mutex.
        const bool hadIn = s.in.cap >= sliceBytes && s.in.buf;
        const bool hadOut = s.out.cap >= sliceBytes && s.out.buf;
        if (!c.ensureBuf(s.in, sliceBytes)) break;
        if (!c.ensureBuf(s.out, sliceBytes)) break;
        if (!c.ensureBuf(s.dyeB, tblBytes)) break;
        if (!c.ensureBuf(s.cmfB, tblBytes)) break;
        if (!hadIn || !hadOut) {
            VkBuffer bufs[4] = {s.in.buf, s.out.buf, s.dyeB.buf, s.cmfB.buf};
            VkDeviceSize caps[4] = {s.in.cap, s.out.cap, s.dyeB.cap, s.cmfB.cap};
            VkDescriptorBufferInfo dbi[4];
            VkWriteDescriptorSet wds[4];
            for (uint32_t i = 0; i < 4; ++i) {
                dbi[i] = VkDescriptorBufferInfo{bufs[i], 0, caps[i]};
                wds[i] = VkWriteDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
                wds[i].dstSet = s.dset;
                wds[i].dstBinding = i;
                wds[i].descriptorCount = 1;
                wds[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
                wds[i].pBufferInfo = &dbi[i];
            }
            vkUpdateDescriptorSets(c.device, 4, wds, 0, nullptr);
        }

        // Tables are tiny (~1 KB) and constant across slices; upload once.
        std::memcpy(s.dyeB.mapped, dye, tblBytes);
        std::memcpy(s.cmfB.mapped, icmf, tblBytes);

        ScanPush push{};
        // Pack the row-major 3x3 XYZ->RGB into the shader's 3x4 layout (m[0..2],[4..6],[8..10]).
        push.m[0] = xyz2rgb[0]; push.m[1] = xyz2rgb[1]; push.m[2]  = xyz2rgb[2]; push.m[3]  = 0.0f;
        push.m[4] = xyz2rgb[3]; push.m[5] = xyz2rgb[4]; push.m[6]  = xyz2rgb[5]; push.m[7]  = 0.0f;
        push.m[8] = xyz2rgb[6]; push.m[9] = xyz2rgb[7]; push.m[10] = xyz2rgb[8]; push.m[11] = 0.0f;

        // Where this pass's time actually goes (#148 slice 1). The upload loop
        // below is also the non-finite guard and the readback is a copy out;
        // both are per-slice single-threaded host work over ~143 MiB a slice at
        // export size, so they are timed apart from the device itself.
        double guard_ms = 0.0, gpu_ms = 0.0, back_ms = 0.0;
        uint64_t bytes_up = 0, bytes_down = 0;
        uint32_t slices = 0;
        bool slice_ok = true;
        for (uint32_t base = 0; base < npix && slice_ok; base += MAX_SLICE) {
            const uint32_t n = (npix - base) < MAX_SLICE ? (npix - base) : MAX_SLICE;
            const size_t ncomp = static_cast<size_t>(n) * 3u;

            // Upload this slice. The input copy is the NaN guard: non-finite
            // densities map to 1e4f (zero transmittance -> black) so the shader
            // never sees a NaN/Inf (clamp(NaN) is implementation-defined in
            // GLSL). Finite inputs are copied verbatim (bit-exact).
            const auto t_guard = std::chrono::steady_clock::now();
            float* dst = static_cast<float*>(s.in.mapped);
            const float* src = cmy + static_cast<size_t>(base) * 3u;
            // Per-element map with disjoint writes, so the engine's deterministic
            // chunks give the same bytes for any worker count -- the same
            // argument every other stage here relies on. It was single-threaded
            // over ~143 MiB a slice, several slices an export, which is why the
            // measurement in the previous commit was worth taking first.
            parallel_for(0, static_cast<int>(ncomp), [&](int lo, int hi) {
                for (int i = lo; i < hi; ++i) {
                    const float v = src[i];
                    dst[i] = std::isfinite(v) ? v : 1e4f;
                }
            });
            guard_ms += std::chrono::duration<double, std::milli>(
                            std::chrono::steady_clock::now() - t_guard).count();
            bytes_up += static_cast<uint64_t>(ncomp) * sizeof(float);

            // Record + submit. The command buffer is reused; each slice's fence
            // is waited before the buffer is reset again.
            const auto t_gpu = std::chrono::steady_clock::now();
            if (vkResetCommandBuffer(s.cmd, 0) != VK_SUCCESS) { slice_ok = false; break; }
            VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            if (vkBeginCommandBuffer(s.cmd, &bi) != VK_SUCCESS) { slice_ok = false; break; }
            vkCmdBindPipeline(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pipe);
            vkCmdBindDescriptorSets(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pl, 0, 1, &s.dset, 0, nullptr);
            push.npix = n;
            vkCmdPushConstants(s.cmd, s.pl, VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(ScanPush), &push);
            vkCmdDispatch(s.cmd, (n + 63u) / 64u, 1, 1);
            if (vkEndCommandBuffer(s.cmd) != VK_SUCCESS) { slice_ok = false; break; }

            VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
            si.commandBufferCount = 1;
            si.pCommandBuffers = &s.cmd;
            if (vkQueueSubmit(c.queue, 1, &si, s.fence) != VK_SUCCESS) { slice_ok = false; break; }
            if (!c.waitFence(s.fence)) { slice_ok = false; break; }
            if (vkResetFences(c.device, 1, &s.fence) != VK_SUCCESS) { slice_ok = false; break; }
            gpu_ms += std::chrono::duration<double, std::milli>(
                          std::chrono::steady_clock::now() - t_gpu).count();

            // Read this slice back (persistently mapped, HOST_COHERENT).
            const auto t_back = std::chrono::steady_clock::now();
            {
                const float* outp = static_cast<const float*>(s.out.mapped);
                float* rgbp = rgb + static_cast<size_t>(base) * 3u;
                parallel_for(0, static_cast<int>(ncomp), [&](int lo, int hi) {
                    std::memcpy(rgbp + lo, outp + lo,
                                static_cast<size_t>(hi - lo) * sizeof(float));
                });
            }
            back_ms += std::chrono::duration<double, std::milli>(
                           std::chrono::steady_clock::now() - t_back).count();
            bytes_down += static_cast<uint64_t>(ncomp) * sizeof(float);
            ++slices;
        }
        stage_timing_note_gpu_scan_add(slices, guard_ms, gpu_ms, back_ms, bytes_up, bytes_down);
        stage_timing_note_gpu_submissions(slices);
        ok = slice_ok;
    } while (false);

    // Failure recovery: tear the persistent state down so the next call rebuilds
    // from scratch (and the caller falls back to the CPU for this frame).
    if (!ok && !c.last_wait_cancelled) c.destroyScan();
    return ok;
}

bool scan_spectral(const float* cmy, float* rgb, uint32_t npix,
                   const float* dye, const float* icmf, const float* xyz2rgb) {
    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    return dispatch_scan(c, c.scanFused, kScanSpectralSpv, sizeof(kScanSpectralSpv),
                         cmy, rgb, npix, dye, icmf, xyz2rgb);
}

bool scan_spectral_linear(const float* cmy, float* rgb, uint32_t npix,
                          const float* dye, const float* icmf, const float* xyz2rgb) {
    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    return dispatch_scan(c, c.scanLin, kScanSpectralLinSpv, sizeof(kScanSpectralLinSpv),
                         cmy, rgb, npix, dye, icmf, xyz2rgb);
}

// --- AgX particle grain sampler (#214) --------------------------------------
// One dispatch over the whole frame. NOT sliced, unlike dispatch_scan above:
// the per-particle dye-cloud blur reads neighbours, and a sliced upload would
// need a halo at every seam. The 2D grid comes from the same planner the
// pointwise chain uses, so a frame larger than 65535 workgroups still goes in
// one submission.
namespace {

// std430 push constant; must match grain.comp's Push block exactly.
struct GrainPush {
    uint32_t npix;
    uint32_t ncells;
    uint32_t seed_offset;
    uint32_t groups_x;
    uint32_t width;
    uint32_t height;
};

constexpr uint32_t kGrainCellStride = 16u;   // floats per cell, matches CELL_STRIDE
constexpr uint32_t kGrainKernelBase = 8u;    // first tap slot within a cell
constexpr uint64_t kGrainFitBytes = 112ull << 20;

// Verbatim reproduction of kernels/gaussian.cpp::gaussian_kernel_1d, including
// its mixed precision: the taps are rounded to float, but the normalising total
// is accumulated in double from the UNROUNDED values. Reproducing that exactly
// is the point -- this pass is meant to apply the same filter the CPU does, and
// a kernel normalised the other way is a different filter.
int grain_blur_kernel(double sigma_px, float* taps_out) {
    const float sigma = static_cast<float>(sigma_px);
    if (!(sigma > 0.0f)) return 0;
    int radius = static_cast<int>(3.0f * sigma + 0.5f);   // kGaussianTruncate
    if (radius < 0) radius = 0;
    if (radius == 0) return 0;
    if (radius > kGrainMaxBlurRadius) return -1;          // caller refuses
    const int size = 2 * radius + 1;
    double total = 0.0;
    for (int i = 0; i < size; ++i) {
        const double x = static_cast<double>(i - radius);
        const double val = std::exp(-0.5 * (x / sigma) * (x / sigma));
        taps_out[i] = static_cast<float>(val);
        total += val;
    }
    if (total != 0.0)
        for (int i = 0; i < size; ++i)
            taps_out[i] = static_cast<float>(taps_out[i] / total);
    return radius;
}

bool grain_cells_valid(const GrainSampleRequest& r) {
    for (int k = 0; k < r.cell_count; ++k) {
        const GrainCell& g = r.cells[k];
        if (!std::isfinite(g.density_min) || !std::isfinite(g.density_max) ||
            !std::isfinite(g.n_particles_per_pixel) || !std::isfinite(g.uniformity) ||
            !std::isfinite(g.blur_sigma_px))
            return false;
        if (!(g.density_max > 0.0) || !(g.n_particles_per_pixel > 0.0)) return false;
        if (g.uniformity < 0.0 || g.uniformity > 1.0) return false;
        if (g.channel < 0 || g.channel > 2) return false;
        if (g.blur_sigma_px < 0.0) return false;
    }
    return true;
}

}  // namespace

bool grain_sample(const GrainSampleRequest& request, float* out_rgb,
                  GrainSampleDiagnostics* diagnostics) {
    GrainSampleDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };

    // Fail closed on every shape question BEFORE touching Vulkan, so a bad
    // request can never half-write the caller's buffer.
    if (out_rgb == nullptr || request.density_cells == nullptr ||
        request.cells == nullptr)
        return give_up("null-span");
    if (request.npix == 0 || request.width == 0 || request.height == 0)
        return give_up("empty-frame");
    if (static_cast<uint64_t>(request.width) * request.height != request.npix)
        return give_up("geometry-mismatch");
    if (request.cell_count <= 0 || request.cell_count > kGrainMaxCells)
        return give_up("cell-count");
    if (!grain_cells_valid(request)) return give_up("bad-cell");
    d.samples = static_cast<uint64_t>(request.npix) *
                static_cast<uint64_t>(request.cell_count);

    // 12 MP RGB f32 is 144 MiB, 26 MP is 312 MiB — both over Adreno 610's
    // ~134 MiB binding range. Cell-split + spatial strips still reported
    // success while writing Dmin (black negative / white slide) or hung
    // the queue. Refuse the GPU sampler; CPU Fast RNG is correct.
    {
        const uint64_t outNeed =
            static_cast<uint64_t>(request.npix) * 3u * sizeof(float);
        if (outNeed > kSafeStorageBytes) return give_up("frame-over-storage");
    }

    // Adreno 610's maxStorageBufferRange is the Vulkan 128 MiB floor. Nine
    // cells at 26 MP is 936 MB, so the whole-frame upload always refused and
    // the CPU sampler ran (the 2-minute export). One cell is ~100 MB and fits.
    // The shader's RNG is keyed on (seed_base, pixel, seed_offset^k); each cell
    // already has a unique seed_base, so one-cell dispatches are equivalent.
    const uint64_t packedBytes =
        static_cast<uint64_t>(request.npix) * request.cell_count * sizeof(float);
    if (request.cell_count > 1 && packedBytes > kGrainFitBytes) {
        std::vector<float> plane(request.npix);
        std::vector<float> part(static_cast<size_t>(request.npix) * 3u);
        const uint32_t ncells = static_cast<uint32_t>(request.cell_count);
        parallel_for(0, static_cast<int>(request.npix) * 3, [&](int lo, int hi) {
            for (int i = lo; i < hi; ++i) out_rgb[i] = 0.0f;
        });
        GrainSampleDiagnostics last{};
        for (uint32_t k = 0; k < ncells; ++k) {
            const float* src = request.density_cells;
            parallel_for(0, static_cast<int>(request.npix), [&](int lo, int hi) {
                for (int i = lo; i < hi; ++i)
                    plane[static_cast<size_t>(i)] =
                        src[static_cast<size_t>(i) * ncells + k];
            });
            GrainCell one = request.cells[k];
            GrainSampleRequest sub = request;
            sub.density_cells = plane.data();
            sub.cells = &one;
            sub.cell_count = 1;
            if (!grain_sample(sub, part.data(), &last)) {
                if (diagnostics) *diagnostics = last;
                return false;
            }
            const int ch = one.channel;
            if (ch >= 0 && ch < 3) {
                parallel_for(0, static_cast<int>(request.npix), [&](int lo, int hi) {
                    for (int i = lo; i < hi; ++i)
                        out_rgb[i * 3 + ch] +=
                            part[static_cast<size_t>(i) * 3 + ch];
                });
            }
        }
        last.slices = ncells;
        last.samples = d.samples;
        if (diagnostics) *diagnostics = last;
        return last.engaged;
    }

    // Reduce every cell's blur on the host, in f64, before anything is uploaded.
    // A radius the shader will not carry is a refusal, never a truncation.
    const uint32_t ncells = static_cast<uint32_t>(request.cell_count);
    std::array<float, kGrainMaxCells * kGrainCellStride> cellData{};
    cellData.fill(0.0f);
    uint32_t maxRadius = 0;
    for (uint32_t k = 0; k < ncells; ++k) {
        const GrainCell& g = request.cells[k];
        float taps[2 * kGrainMaxBlurRadius + 1] = {0.0f};
        const int radius = grain_blur_kernel(g.blur_sigma_px, taps);
        if (radius < 0) return give_up("blur-too-wide");
        if (radius > static_cast<int>(maxRadius)) maxRadius = static_cast<uint32_t>(radius);
        float* e = cellData.data() + static_cast<size_t>(k) * kGrainCellStride;
        e[0] = static_cast<float>(g.density_min);
        e[1] = static_cast<float>(g.density_max);
        e[2] = static_cast<float>(g.n_particles_per_pixel);
        e[3] = static_cast<float>(g.uniformity);
        e[4] = static_cast<float>(g.density_max / g.n_particles_per_pixel);
        e[5] = static_cast<float>(g.channel);
        const uint32_t seed = g.seed_base;
        std::memcpy(&e[6], &seed, sizeof(uint32_t));
        e[7] = static_cast<float>(radius);
        for (int t = 0; t < 2 * radius + 1; ++t)
            e[kGrainKernelBase + static_cast<size_t>(t)] = taps[t];
    }
    d.max_blur_radius = maxRadius;
    // reflect() is only well defined for an offset within one frame span, and a
    // frame narrower than the kernel would also be a filter the CPU never runs.
    if (request.width < 2u * maxRadius + 1u || request.height < 2u * maxRadius + 1u)
        return give_up("frame-smaller-than-kernel");

    // 12 MP RGB f32 is 144 MiB > Adreno 610's ~134 MiB binding range. Cell-split
    // above only shrinks the INPUT. Slice HEIGHT with a blur halo so each
    // dispatch's in/out buffers fit, and the dye-cloud recompute still sees
    // neighbours at the seam.
    {
        const uint64_t inNeed =
            static_cast<uint64_t>(request.npix) * ncells * sizeof(float);
        const uint64_t outNeed =
            static_cast<uint64_t>(request.npix) * 3u * sizeof(float);
        if (inNeed > kGrainFitBytes || outNeed > kGrainFitBytes) {
            const uint32_t halo = maxRadius;
            const uint64_t maxPix = kGrainFitBytes / (3u * sizeof(float));
            uint32_t innerH = static_cast<uint32_t>(maxPix / request.width);
            if (innerH > request.height) innerH = request.height;
            auto stripFits = [&](uint32_t inner) {
                if (inner < 1u) return false;
                const uint32_t sh = inner + 2u * halo;
                const uint64_t sn = static_cast<uint64_t>(request.width) * sh;
                return sn * ncells * sizeof(float) <= kGrainFitBytes &&
                       sn * 3u * sizeof(float) <= kGrainFitBytes;
            };
            while (innerH > 1u && !stripFits(innerH)) --innerH;
            if (!stripFits(innerH)) return give_up("buffer-too-large");

            std::vector<float> stripIn;
            std::vector<float> stripOut;
            GrainSampleDiagnostics last{};
            uint32_t slices = 0;
            for (uint32_t y0 = 0; y0 < request.height; y0 += innerH) {
                const uint32_t y1 = (request.height - y0) < innerH
                                        ? request.height
                                        : y0 + innerH;
                const uint32_t ys = y0 > halo ? y0 - halo : 0u;
                const uint32_t ye = (y1 + halo) > request.height
                                        ? request.height
                                        : y1 + halo;
                const uint32_t sh = ye - ys;
                const uint32_t sn = request.width * sh;
                stripIn.resize(static_cast<size_t>(sn) * ncells);
                stripOut.resize(static_cast<size_t>(sn) * 3u);
                const uint32_t W = request.width;
                parallel_for(0, static_cast<int>(sh), [&](int lo, int hi) {
                    for (int row = lo; row < hi; ++row) {
                        const size_t src = (static_cast<size_t>(ys) +
                                            static_cast<size_t>(row)) *
                                           W * ncells;
                        const size_t dst =
                            static_cast<size_t>(row) * W * ncells;
                        std::memcpy(stripIn.data() + dst,
                                    request.density_cells + src,
                                    static_cast<size_t>(W) * ncells *
                                        sizeof(float));
                    }
                });
                GrainSampleRequest sub = request;
                sub.density_cells = stripIn.data();
                sub.height = sh;
                sub.npix = sn;
                if (!grain_sample(sub, stripOut.data(), &last)) {
                    if (diagnostics) *diagnostics = last;
                    return false;
                }
                const uint32_t srcY0 = y0 - ys;
                parallel_for(0, static_cast<int>(y1 - y0), [&](int lo, int hi) {
                    for (int row = lo; row < hi; ++row) {
                        const size_t src =
                            (static_cast<size_t>(srcY0) +
                             static_cast<size_t>(row)) *
                            W * 3u;
                        const size_t dst =
                            (static_cast<size_t>(y0) +
                             static_cast<size_t>(row)) *
                            W * 3u;
                        std::memcpy(out_rgb + dst, stripOut.data() + src,
                                    static_cast<size_t>(W) * 3u * sizeof(float));
                    }
                });
                ++slices;
            }
            last.slices = slices;
            last.samples = d.samples;
            last.max_blur_radius = maxRadius;
            if (diagnostics) *diagnostics = last;
            return last.engaged;
        }
    }

    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok) return give_up("gpu-unavailable");
    const VkPhysicalDeviceLimits& limits = c.properties.limits;
    Ctx::Kernel& s = c.grainK;

    const PointwiseDispatchGrid grid =
        plan_pointwise_dispatch(request.npix, limits.maxComputeWorkGroupCount[0],
                                limits.maxComputeWorkGroupCount[1]);
    if (!grid.valid) return give_up("dispatch-too-large");

    const VkDeviceSize inBytes =
        static_cast<VkDeviceSize>(request.npix) * ncells * sizeof(float);
    const VkDeviceSize outBytes =
        static_cast<VkDeviceSize>(request.npix) * 3u * sizeof(float);
    const VkDeviceSize cellBytes =
        static_cast<VkDeviceSize>(kGrainMaxCells) * kGrainCellStride * sizeof(float);
    const VkDeviceSize counterBytes = 16;      // one uint, padded
    if (inBytes > clamp_storage(limits.maxStorageBufferRange) ||
        outBytes > clamp_storage(limits.maxStorageBufferRange))
        return give_up("buffer-too-large");

    // Every early exit here used to land on the single reason "dispatch-failed",
    // which is exactly what a real 12.5 MP export reported -- with gpu_ms = 0.0,
    // i.e. it never reached a dispatch at all. A reason that cannot separate "the
    // driver rejected my command buffer" from "I could not allocate 449 MB" sends
    // the reader to the wrong half of the file. They are separate now.
    bool ok = false;
    const char* why = "dispatch-failed";
    do {
        if (!s.pipelineReady &&
            !build_scan_pipeline(c, s, kGrainSpv, sizeof(kGrainSpv))) {
            why = "pipeline-failed";
            break;
        }

        const bool hadIn = s.in.cap >= inBytes && s.in.buf;
        const bool hadOut = s.out.cap >= outBytes && s.out.buf;
        // The input alone is npix * ncells * 4 -- 449 MB at 12.5 MP with nine
        // cells, asked for next to the diffusion transform's own scratch.
        why = "allocation-failed";
        if (!c.ensureBuf(s.in, inBytes)) break;
        if (!c.ensureBuf(s.out, outBytes)) break;
        if (!c.ensureBuf(s.dyeB, cellBytes)) break;      // per-cell constants
        if (!c.ensureBuf(s.cmfB, counterBytes)) break;   // out-of-branch counter
        why = "dispatch-failed";
        if (!hadIn || !hadOut) {
            VkBuffer bufs[4] = {s.in.buf, s.out.buf, s.dyeB.buf, s.cmfB.buf};
            VkDeviceSize caps[4] = {s.in.cap, s.out.cap, s.dyeB.cap, s.cmfB.cap};
            VkDescriptorBufferInfo dbi[4];
            VkWriteDescriptorSet wds[4];
            for (uint32_t i = 0; i < 4; ++i) {
                dbi[i] = VkDescriptorBufferInfo{bufs[i], 0, caps[i]};
                wds[i] = VkWriteDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
                wds[i].dstSet = s.dset;
                wds[i].dstBinding = i;
                wds[i].descriptorCount = 1;
                wds[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
                wds[i].pBufferInfo = &dbi[i];
            }
            vkUpdateDescriptorSets(c.device, 4, wds, 0, nullptr);
        }
        std::memcpy(s.dyeB.mapped, cellData.data(), static_cast<size_t>(cellBytes));

        const size_t nin = static_cast<size_t>(request.npix) * ncells;
        const size_t nout = static_cast<size_t>(request.npix) * 3u;

        // Upload, and guard non-finite densities here rather than in the shader:
        // clamp(NaN) is implementation-defined in GLSL, so shader NaN behaviour
        // must never decide a pixel. The CPU sampler yields zero grain for a
        // non-finite density (fast_poisson_one rejects a NaN rate), and density
        // 0 is the closest finite stand-in.
        const auto t_up = std::chrono::steady_clock::now();
        {
            float* dst = static_cast<float*>(s.in.mapped);
            const float* src = request.density_cells;
            parallel_for(0, static_cast<int>(nin), [&](int lo, int hi) {
                for (int i = lo; i < hi; ++i) {
                    const float v = src[i];
                    dst[i] = std::isfinite(v) ? v : 0.0f;
                }
            });
        }
        const uint32_t zero = 0;
        std::memcpy(s.cmfB.mapped, &zero, sizeof(uint32_t));
        d.upload_ms = std::chrono::duration<double, std::milli>(
                          std::chrono::steady_clock::now() - t_up).count();

        GrainPush push{};
        push.npix = request.npix;
        push.ncells = ncells;
        push.seed_offset = request.seed_offset;
        push.groups_x = grid.groups_x;
        push.width = request.width;
        push.height = request.height;

        const auto t_gpu = std::chrono::steady_clock::now();
        bool dispatch_ok = true;
        do {
            if (vkResetCommandBuffer(s.cmd, 0) != VK_SUCCESS) { dispatch_ok = false; break; }
            VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            if (vkBeginCommandBuffer(s.cmd, &bi) != VK_SUCCESS) { dispatch_ok = false; break; }
            vkCmdBindPipeline(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pipe);
            vkCmdBindDescriptorSets(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pl, 0, 1,
                                    &s.dset, 0, nullptr);
            vkCmdPushConstants(s.cmd, s.pl, VK_SHADER_STAGE_COMPUTE_BIT, 0,
                               sizeof(GrainPush), &push);
            vkCmdDispatch(s.cmd, grid.groups_x, grid.groups_y, 1);
            if (vkEndCommandBuffer(s.cmd) != VK_SUCCESS) { dispatch_ok = false; break; }

            VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
            si.commandBufferCount = 1;
            si.pCommandBuffers = &s.cmd;
            if (vkQueueSubmit(c.queue, 1, &si, s.fence) != VK_SUCCESS) { dispatch_ok = false; break; }
            if (!c.waitFence(s.fence)) { dispatch_ok = false; break; }
            if (vkResetFences(c.device, 1, &s.fence) != VK_SUCCESS) { dispatch_ok = false; break; }
        } while (false);
        d.gpu_ms = std::chrono::duration<double, std::milli>(
                       std::chrono::steady_clock::now() - t_gpu).count();
        if (!dispatch_ok) break;
        d.slices = 1;

        const auto t_back = std::chrono::steady_clock::now();
        {
            const float* outp = static_cast<const float*>(s.out.mapped);
            parallel_for(0, static_cast<int>(nout), [&](int lo, int hi) {
                std::memcpy(out_rgb + lo, outp + lo,
                            static_cast<size_t>(hi - lo) * sizeof(float));
            });
            uint32_t got = 0;
            std::memcpy(&got, s.cmfB.mapped, sizeof(uint32_t));
            d.out_of_branch = got;
            // Fail closed if the driver "succeeded" but wrote zeros into an
            // oversize binding (Adreno 610 whole-frame RGB at 12 MP).
            float mx = 0.0f;
            const uint32_t np = request.npix;
            const int step = static_cast<int>(np / 8000u);
            const int st = step > 1 ? step : 1;
            for (uint32_t p = 0; p < np; p += static_cast<uint32_t>(st)) {
                const size_t o = static_cast<size_t>(p) * 3u;
                const float a = std::fabs(out_rgb[o]) + std::fabs(out_rgb[o + 1]) +
                                std::fabs(out_rgb[o + 2]);
                if (a > mx) mx = a;
            }
            if (!(mx > 1.0e-12f)) {
                why = "zero-readback";
                ok = false;
                break;
            }
        }
        d.readback_ms = std::chrono::duration<double, std::milli>(
                            std::chrono::steady_clock::now() - t_back).count();
        ok = true;
    } while (false);

    if (!ok) {
        if (!c.last_wait_cancelled) c.destroyScan();
        return give_up(why);
    }
    d.engaged = true;
    d.reason = "";
    if (diagnostics) *diagnostics = d;
    return true;
}

// --- frame residency (#220) -------------------------------------------------
namespace {

// Allocate (or reuse) the ping-pong pair, the staging buffer and the one-off
// command objects. Device-local and HOST_VISIBLE-shunning for the planes, for
// the reason findPreferredMemType documents: on a unified-memory phone every
// type is DEVICE_LOCAL and the first match is the host-coherent one.
bool ensure_frame(Ctx& c, int width, int height) {
    const uint64_t comps = static_cast<uint64_t>(width) * height * 3;
    const VkDeviceSize bytes = comps * sizeof(float);
    constexpr VkBufferUsageFlags kUsage =
        VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT |
        VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    PointwiseChainDiagnostics unused{};
    for (ResidentBuf& b : c.frame.plane) {
        if (!c.ensureResidentBuf(b, bytes, kUsage,
                                 VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                                 VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                                 /*persistentMap=*/false, unused,
                                 VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT))
            return false;
    }
    if (!c.ensureBuf(c.frame.staging, bytes)) return false;
    if (c.frame.cpool == VK_NULL_HANDLE) {
        VkCommandPoolCreateInfo cpci{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
        cpci.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
        cpci.queueFamilyIndex = c.queueFamily;
        if (vkCreateCommandPool(c.device, &cpci, nullptr, &c.frame.cpool) != VK_SUCCESS)
            return false;
        VkCommandBufferAllocateInfo cbai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
        cbai.commandPool = c.frame.cpool;
        cbai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
        cbai.commandBufferCount = 1;
        if (vkAllocateCommandBuffers(c.device, &cbai, &c.frame.cmd) != VK_SUCCESS) return false;
        VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
        if (vkCreateFence(c.device, &fci, nullptr, &c.frame.fence) != VK_SUCCESS) return false;
    }
    return true;
}

}  // namespace

bool frame_open(const double* rgb, int width, int height,
                FrameDiagnostics* diagnostics) {
    FrameDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };
    if (rgb == nullptr || width <= 0 || height <= 0) return give_up("invalid-request");
    const uint64_t comps = static_cast<uint64_t>(width) * height * 3;
    if (comps > UINT32_MAX) return give_up("frame-too-large");

    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok) return give_up("gpu-unavailable");
    if (c.frame.open) return give_up("already-open");
    if (comps * sizeof(float) > c.properties.limits.maxStorageBufferRange)
        return give_up("buffer-too-large");

    const auto t0 = std::chrono::steady_clock::now();
    if (!ensure_frame(c, width, height)) { c.destroyFrame(); return give_up("allocation-failed"); }
    c.frame.front = 0;
    {
        float* dst = static_cast<float*>(c.frame.staging.mapped);
        parallel_for(0, static_cast<int>(comps), [&](int lo, int hi) {
            for (int i = lo; i < hi; ++i) {
                const double v = rgb[i];
                dst[i] = std::isfinite(v) ? static_cast<float>(v) : 0.0f;
            }
        });
    }
    if (!c.frameCopy(/*toDevice=*/true, comps * sizeof(float))) {
        c.destroyFrame();
        return give_up("upload-failed");
    }
    c.frame.width = width;
    c.frame.height = height;
    c.frame.open = true;
    d.ms = std::chrono::duration<double, std::milli>(
               std::chrono::steady_clock::now() - t0).count();
    d.engaged = true;
    d.reason = "";
    if (diagnostics) *diagnostics = d;
    return true;
}

bool frame_close(double* rgb, FrameDiagnostics* diagnostics) {
    FrameDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };
    if (rgb == nullptr) return give_up("invalid-request");

    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok || !c.frame.open) return give_up("not-open");
    const uint64_t comps =
        static_cast<uint64_t>(c.frame.width) * c.frame.height * 3;
    const auto t0 = std::chrono::steady_clock::now();
    if (!c.frameCopy(/*toDevice=*/false, comps * sizeof(float))) {
        c.frame.open = false;
        return give_up("readback-failed");
    }
    {
        const float* src = static_cast<const float*>(c.frame.staging.mapped);
        parallel_for(0, static_cast<int>(comps), [&](int lo, int hi) {
            for (int i = lo; i < hi; ++i) rgb[i] = static_cast<double>(src[i]);
        });
    }
    c.frame.open = false;
    d.ms = std::chrono::duration<double, std::milli>(
               std::chrono::steady_clock::now() - t0).count();
    d.engaged = true;
    d.reason = "";
    if (diagnostics) *diagnostics = d;
    return true;
}

void frame_discard() {
    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok) return;
    // The plane stays allocated -- it is grow-only scratch like every other
    // buffer here -- but it must stop being ADVERTISED, or the next frame reads
    // a stale image as if it were its own input.
    c.frame.open = false;
}

bool frame_active(int width, int height) {
    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    return c.ok && c.frame.open && c.frame.width == width && c.frame.height == height;
}

// --- filming pointwise stages (#218) ----------------------------------------
namespace {

// std430 push constant; must match filming_stage.comp's Push block exactly.
struct FilmingStagePush {
    uint32_t npix;
    uint32_t groups_x;
    uint32_t total_groups;
    uint32_t mode;
    uint32_t flags;
    int32_t L;
    int32_t n;
    float exp_mult;
    float raw_x0;
    float inv_max_raw;
    float boost_scale;
    float boost_a;
    float mix_amount;
    float sub_c0;
    float sub_c1;
    float sub_c2;
    float src_gain;
};
static_assert(sizeof(FilmingStagePush) == 68, "push block must match filming_stage.comp");

constexpr uint32_t kFilmModeExpose = 0u;
constexpr uint32_t kFilmModeDevelop = 1u;
constexpr uint32_t kFilmModeMax = 2u;
constexpr uint32_t kFilmModeBoost = 3u;
constexpr uint32_t kFilmModeMix = 4u;
constexpr uint32_t kFilmModeUnsharp = 5u;
constexpr uint32_t kFilmModeLog10 = 6u;
constexpr uint32_t kFilmModeLayers = 7u;
constexpr uint32_t kFilmModeSubC = 8u;
constexpr uint32_t kFilmFlagPositive = 2u;
constexpr uint32_t kFilmFlagLog10 = 1u;

// One dispatch, four buffers, one upload and one readback. Both entry points
// funnel through here because they differ only in which table they carry and
// what the source/destination element types are.
struct FilmingStageRun {
    uint32_t mode = 0;
    uint32_t flags = 0;
    uint32_t npix = 0;
    // THE UNIT OF `npix` DIFFERS BY MODE, and getting it wrong overran the
    // caller's buffer by 3x. MODE_EXPOSE and MODE_DEVELOP are per PIXEL and
    // touch three components each; the two boost modes are per COMPONENT,
    // because the CPU takes its maximum and applies its map over the whole
    // (h, w, 3) array rather than per pixel. The dispatch grid is planned on
    // `npix` either way, so it has to be the element count the shader bounds
    // itself with.
    bool npix_is_components = false;
    // When the frame is resident this pass reads the resident half and writes
    // the other, and does no transfer at all. `width`/`height` are only needed
    // to confirm the resident geometry is this frame's.
    int width = 0;
    int height = 0;
    const double* src_f64 = nullptr;   // exactly one of these two
    const float* src_f32 = nullptr;
    // Binding 2 is the tc_lut and binding 3 the concatenated axis|curve, and
    // each mode leaves the other empty. The shader's interp_curve reads BOTH
    // halves of the curve table from binding 3, so the axis and the curve must
    // land in ONE buffer, not one binding each.
    const double* tc_table = nullptr;   // f64: the profile's NdArray, converted on upload
    size_t tc_count = 0;
    const float* curve_axis = nullptr;
    const float* curve_values = nullptr;
    size_t curve_count = 0;            // per half, i.e. points*3
    int32_t L = 0;
    int32_t n = 0;
    float exp_mult = 1.0f;
    float src_gain = 1.0f;
    float raw_x0 = 0.0f;
    float inv_max_raw = 0.0f;
    float boost_scale = 0.0f;
    float boost_a = 0.0f;
    float mix_amount = 0.0f;
    float sub_c[3] = {0.0f, 0.0f, 0.0f};
    // MODE_MIX / MODE_UNSHARP carry their second plane on binding 2, where
    // MODE_EXPOSE carries the tc_lut. Given as f64 because that is what the
    // engine's planes are; converted on upload like everything else.
    const double* second_f64 = nullptr;
    // MODE_MAX needs one float of table space per workgroup, which is far more
    // than a curve; the run sizes binding 3 for whichever use is larger.
    size_t table_b_floats_min = 0;
    // MODE_LAYERS writes NINE floats per pixel, not three, so the destination
    // cannot be sized from the source. 0 means "same as the source".
    size_t dst_elems = 0;
    // MODE_LAYERS hands over ONE contiguous table (the axis followed by the
    // layer curves) rather than two halves of equal length.
    bool curve_single_block = false;
    double* dst_f64 = nullptr;         // exactly one of these two
    float* dst_f32 = nullptr;
};

bool run_filming_stage(const FilmingStageRun& r, FilmingStageDiagnostics* diagnostics) {
    FilmingStageDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };

    if (r.npix == 0) return give_up("empty-frame");
    // MODE_EXPOSE needs the tc_lut and MODE_DEVELOP needs the curves; the two
    // boost modes need NEITHER -- MODE_MAX only writes partial maxima into the
    // table buffer and MODE_BOOST carries its scalars in the push block. An
    // unconditional "a table must be present" check refused them both.
    const bool needs_table = r.mode == kFilmModeExpose || r.mode == kFilmModeDevelop ||
                             r.mode == kFilmModeMix || r.mode == kFilmModeUnsharp ||
                             r.mode == kFilmModeLayers;
    if (needs_table && r.tc_count == 0 && r.curve_count == 0)
        return give_up("null-table");

    // 12/26 MP RGB f32 exceeds Adreno 610's binding range. Slicing still
    // produced Dmin frames; refuse so the CPU filming path runs instead.
    {
        const size_t srcStride = r.npix_is_components ? 1u : 3u;
        const size_t dstStride =
            r.dst_elems ? (r.dst_elems / r.npix) : srcStride;
        const uint64_t planeU =
            static_cast<uint64_t>(r.npix) * srcStride * sizeof(float);
        const uint64_t dstU =
            static_cast<uint64_t>(r.npix) *
            (dstStride ? dstStride : srcStride) * sizeof(float);
        if (planeU > kSafeStorageBytes || dstU > kSafeStorageBytes)
            return give_up("frame-over-storage");
    }

    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok) return give_up("gpu-unavailable");

    // RESIDENT when the frame is open and this is its geometry. The host
    // pointers are then ignored, which is the whole point: no upload, no
    // readback, no f64 <-> f32 conversion.
    const uint64_t geom_elems = r.npix_is_components
                                   ? static_cast<uint64_t>(r.width) * r.height * 3
                                   : static_cast<uint64_t>(r.width) * r.height;
    // MODE_LAYERS writes npix*9, which is not the frame's shape, so it can never
    // BE the resident plane -- it is the grain sampler's input buffer instead.
    const bool frame_shaped = r.mode != kFilmModeLayers;
    const bool resident = frame_shaped && c.frame.open && r.width > 0 && r.height > 0 &&
                          c.frame.width == r.width && c.frame.height == r.height &&
                          geom_elems == r.npix;
    // MODE_MAX produces its answer in the table buffer, not in the plane, so it
    // is the one mode with no destination at all.
    const bool writes_plane = r.mode != kFilmModeMax;
    // The blend modes read their destination as well as write it, so the
    // resident pair cannot ping-pong: `a` and `out` are the same half.
    const bool in_place = r.mode == kFilmModeUnsharp;
    if (!resident) {
        if ((r.src_f64 == nullptr) == (r.src_f32 == nullptr)) return give_up("bad-source");
        if (writes_plane && (r.dst_f64 == nullptr) == (r.dst_f32 == nullptr))
            return give_up("bad-destination");
    }
    d.resident = resident;
    const VkPhysicalDeviceLimits& limits = c.properties.limits;
    Ctx::Kernel& s = c.filmK;

    const PointwiseDispatchGrid grid =
        plan_pointwise_dispatch(r.npix, limits.maxComputeWorkGroupCount[0],
                                limits.maxComputeWorkGroupCount[1]);
    if (!grid.valid) return give_up("dispatch-too-large");

    const size_t comps = r.npix_is_components ? static_cast<size_t>(r.npix)
                                              : static_cast<size_t>(r.npix) * 3;
    const size_t dstComps = r.dst_elems ? r.dst_elems : comps;
    const VkDeviceSize planeBytes = static_cast<VkDeviceSize>(comps) * sizeof(float);
    const VkDeviceSize dstBytes = static_cast<VkDeviceSize>(dstComps) * sizeof(float);
    // The layout has four bindings and every one must be backed, so the table
    // the active mode does not use still gets a minimal buffer rather than a
    // null descriptor.
    const VkDeviceSize tblABytes =
        r.tc_count ? static_cast<VkDeviceSize>(r.tc_count) * sizeof(float) : 16;
    VkDeviceSize tblBBytes = 16;
    if (r.curve_count) {
        const size_t halves = r.curve_single_block ? 1u : 2u;
        tblBBytes = static_cast<VkDeviceSize>(r.curve_count) * halves * sizeof(float);
    }
    if (r.table_b_floats_min) {
        const VkDeviceSize want =
            static_cast<VkDeviceSize>(r.table_b_floats_min) * sizeof(float);
        if (want > tblBBytes) tblBBytes = want;
    }
    if (planeBytes > clamp_storage(limits.maxStorageBufferRange) ||
        dstBytes > clamp_storage(limits.maxStorageBufferRange) ||
        tblABytes > clamp_storage(limits.maxStorageBufferRange))
        return give_up("buffer-too-large");

    bool ok = false;
    do {
        if (!s.pipelineReady &&
            !build_scan_pipeline(c, s, kFilmingStageSpv, sizeof(kFilmingStageSpv),
                                 sizeof(FilmingStagePush)))
            break;
        const bool hadA = s.dyeB.cap >= tblABytes && s.dyeB.buf;
        const bool hadB = s.cmfB.cap >= tblBBytes && s.cmfB.buf;
        bool hadIn = true, hadOut = true;
        if (!resident) {
            hadIn = s.in.cap >= planeBytes && s.in.buf;
            hadOut = s.out.cap >= dstBytes && s.out.buf;
            if (!c.ensureBuf(s.in, planeBytes)) break;
            if (!c.ensureBuf(s.out, dstBytes)) break;
        }
        if (!c.ensureBuf(s.dyeB, tblABytes)) break;
        if (!c.ensureBuf(s.cmfB, tblBBytes)) break;
        // The descriptor set is rewritten whenever the buffers it names change,
        // and switching between the resident planes and the mapped pair changes
        // them, so residency is part of the condition.
        if (!hadIn || !hadOut || !hadA || !hadB || resident != s.boundResident) {
            VkBuffer inBuf = resident ? c.frame.plane[c.frame.front].buf : s.in.buf;
            VkBuffer outBuf = resident ? c.frame.plane[c.frame.front ^ 1u].buf : s.out.buf;
            VkDeviceSize inCap = resident ? c.frame.plane[c.frame.front].cap : s.in.cap;
            VkDeviceSize outCap = resident ? c.frame.plane[c.frame.front ^ 1u].cap : s.out.cap;
            VkBuffer bufs[4] = {inBuf, outBuf, s.dyeB.buf, s.cmfB.buf};
            VkDeviceSize caps[4] = {inCap, outCap, s.dyeB.cap, s.cmfB.cap};
            VkDescriptorBufferInfo dbi[4];
            VkWriteDescriptorSet wds[4];
            for (uint32_t i = 0; i < 4; ++i) {
                dbi[i] = VkDescriptorBufferInfo{bufs[i], 0, caps[i]};
                wds[i] = VkWriteDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
                wds[i].dstSet = s.dset;
                wds[i].dstBinding = i;
                wds[i].descriptorCount = 1;
                wds[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
                wds[i].pBufferInfo = &dbi[i];
            }
            vkUpdateDescriptorSets(c.device, 4, wds, 0, nullptr);
            s.boundResident = resident;
        }

        const auto t_up = std::chrono::steady_clock::now();
        if (!resident) {
            float* dst = static_cast<float*>(s.in.mapped);
            if (r.src_f64) {
                const double* src = r.src_f64;
                parallel_for(0, static_cast<int>(comps), [&](int lo, int hi) {
                    for (int i = lo; i < hi; ++i)
                        dst[i] = static_cast<float>(src[i]);
                });
            } else {
                std::memcpy(dst, r.src_f32, static_cast<size_t>(planeBytes));
            }
        }
        {
            if (r.tc_count) {
                float* tc = static_cast<float*>(s.dyeB.mapped);
                const double* srcTable = r.second_f64 ? r.second_f64 : r.tc_table;
                parallel_for(0, static_cast<int>(r.tc_count), [&](int lo, int hi) {
                    for (int i = lo; i < hi; ++i)
                        tc[i] = static_cast<float>(srcTable[i]);
                });
            }
            if (r.curve_count) {
                float* cv = static_cast<float*>(s.cmfB.mapped);
                std::memcpy(cv, r.curve_axis, r.curve_count * sizeof(float));
                if (!r.curve_single_block)
                    std::memcpy(cv + r.curve_count, r.curve_values,
                                r.curve_count * sizeof(float));
            }
        }
        d.upload_ms = std::chrono::duration<double, std::milli>(
                          std::chrono::steady_clock::now() - t_up).count();

        FilmingStagePush push{};
        push.npix = r.npix;
        push.groups_x = grid.groups_x;
        push.total_groups = grid.total_groups;
        push.mode = r.mode;
        push.flags = r.flags;
        push.L = r.L;
        push.n = r.n;
        push.exp_mult = r.exp_mult;
        push.src_gain = r.src_gain;
        push.raw_x0 = r.raw_x0;
        push.inv_max_raw = r.inv_max_raw;
        push.boost_scale = r.boost_scale;
        push.boost_a = r.boost_a;
        push.mix_amount = r.mix_amount;
        push.sub_c0 = r.sub_c[0];
        push.sub_c1 = r.sub_c[1];
        push.sub_c2 = r.sub_c[2];

        const auto t_gpu = std::chrono::steady_clock::now();
        bool dispatch_ok = true;
        do {
            if (vkResetCommandBuffer(s.cmd, 0) != VK_SUCCESS) { dispatch_ok = false; break; }
            VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            if (vkBeginCommandBuffer(s.cmd, &bi) != VK_SUCCESS) { dispatch_ok = false; break; }
            vkCmdBindPipeline(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pipe);
            vkCmdBindDescriptorSets(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pl, 0, 1,
                                    &s.dset, 0, nullptr);
            vkCmdPushConstants(s.cmd, s.pl, VK_SHADER_STAGE_COMPUTE_BIT, 0,
                               sizeof(FilmingStagePush), &push);
            vkCmdDispatch(s.cmd, grid.groups_x, grid.groups_y, 1);
            if (vkEndCommandBuffer(s.cmd) != VK_SUCCESS) { dispatch_ok = false; break; }
            VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
            si.commandBufferCount = 1;
            si.pCommandBuffers = &s.cmd;
            if (vkQueueSubmit(c.queue, 1, &si, s.fence) != VK_SUCCESS) { dispatch_ok = false; break; }
            if (!c.waitFence(s.fence)) { dispatch_ok = false; break; }
            if (vkResetFences(c.device, 1, &s.fence) != VK_SUCCESS) { dispatch_ok = false; break; }
        } while (false);
        d.gpu_ms = std::chrono::duration<double, std::milli>(
                       std::chrono::steady_clock::now() - t_gpu).count();
        if (!dispatch_ok) break;

        const auto t_back = std::chrono::steady_clock::now();
        if (resident) {
            // The result is the new front. Nothing crosses the bus. MODE_MAX
            // wrote no plane, so it must leave the front alone or the next pass
            // would read the stale half.
            if (writes_plane && !in_place) c.frame.front ^= 1u;
        } else if (writes_plane) {
            const float* src = static_cast<const float*>(s.out.mapped);
            if (r.dst_f64) {
                double* dst = r.dst_f64;
                parallel_for(0, static_cast<int>(comps), [&](int lo, int hi) {
                    for (int i = lo; i < hi; ++i) dst[i] = static_cast<double>(src[i]);
                });
            } else {
                std::memcpy(r.dst_f32, src, static_cast<size_t>(dstBytes));
            }
        }
        d.readback_ms = std::chrono::duration<double, std::milli>(
                            std::chrono::steady_clock::now() - t_back).count();
        ok = true;
    } while (false);

    if (!ok) {
        if (!c.last_wait_cancelled) c.destroyScan();
        return give_up("dispatch-failed");
    }
    d.engaged = true;
    d.reason = "";
    if (diagnostics) *diagnostics = d;
    return true;
}

}  // namespace

bool filming_expose(const double* rgb_f64, const float* rgb_f32, double gain,
                    uint32_t npix, int width, int height, const double* tc_lut,
                    uint32_t tc_edge, double exposure_multiplier, double* out_raw,
                    float* out_log_raw, FilmingStageDiagnostics* diagnostics) {
    if (tc_lut == nullptr || tc_edge < 2 || !std::isfinite(gain) ||
        !std::isfinite(exposure_multiplier)) {
        if (diagnostics) {
            *diagnostics = FilmingStageDiagnostics{};
            diagnostics->attempted = true;
            diagnostics->reason = "invalid-request";
        }
        return false;
    }
    FilmingStageRun r;
    r.mode = kFilmModeExpose;
    r.flags = out_log_raw ? kFilmFlagLog10 : 0u;
    r.npix = npix;
    r.width = width;
    r.height = height;
    r.src_f64 = rgb_f64;
    r.src_f32 = rgb_f32;
    r.src_gain = static_cast<float>(gain);
    r.tc_table = tc_lut;
    r.tc_count = static_cast<size_t>(tc_edge) * tc_edge * 3;
    r.L = static_cast<int32_t>(tc_edge);
    r.n = 2;   // unused by MODE_EXPOSE, but must stay a valid curve length
    r.exp_mult = static_cast<float>(exposure_multiplier);
    r.dst_f64 = out_raw;
    r.dst_f32 = out_log_raw;
    return run_filming_stage(r, diagnostics);
}

bool filming_develop(const float* log_raw, uint32_t npix, int width, int height,
                     const float* axis, const float* curve, uint32_t points,
                     float* out_density, FilmingStageDiagnostics* diagnostics) {
    // The host pointers are only required when there is no resident frame to
    // read instead. Checking residency HERE rather than inside the run keeps the
    // refusal reasons honest: a caller that forgot the plane still gets
    // "invalid-request" instead of a confusing dispatch failure.
    const bool resident = frame_active(width, height);
    if (axis == nullptr || curve == nullptr || points < 2 ||
        (!resident && (log_raw == nullptr || out_density == nullptr))) {
        if (diagnostics) {
            *diagnostics = FilmingStageDiagnostics{};
            diagnostics->attempted = true;
            diagnostics->reason = "invalid-request";
        }
        return false;
    }
    FilmingStageRun r;
    r.mode = kFilmModeDevelop;
    r.flags = 0u;              // the caller already holds log-exposure
    r.npix = npix;
    r.width = width;
    r.height = height;
    r.src_f32 = log_raw;
    r.curve_axis = axis;
    r.curve_values = curve;
    r.curve_count = static_cast<size_t>(points) * 3;
    r.L = 2;
    r.n = static_cast<int32_t>(points);
    r.dst_f32 = out_density;
    return run_filming_stage(r, diagnostics);
}

bool subtract_per_channel(const float* src, float* dst, int width, int height,
                          const double k[3], FilmingStageDiagnostics* diagnostics) {
    FilmingStageDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };
    if (width <= 0 || height <= 0 || k == nullptr) return give_up("invalid-request");
    const uint64_t npix64 = static_cast<uint64_t>(width) * height;
    if (npix64 == 0 || npix64 * 3 > UINT32_MAX) return give_up("invalid-request");
    for (int i = 0; i < 3; ++i)
        if (!std::isfinite(k[i])) return give_up("invalid-request");
    const bool resident = frame_active(width, height);
    if (!resident && (src == nullptr || dst == nullptr))
        return give_up("invalid-request");

    FilmingStageRun r;
    r.mode = kFilmModeSubC;
    r.npix = static_cast<uint32_t>(npix64);
    r.width = width;
    r.height = height;
    r.src_f32 = resident ? nullptr : src;
    r.dst_f32 = resident ? nullptr : dst;
    r.curve_count = 0;
    r.n = 2;
    r.L = 2;
    for (int i = 0; i < 3; ++i) r.sub_c[i] = static_cast<float>(k[i]);
    if (!run_filming_stage(r, &d)) return give_up(d.reason);
    if (diagnostics) *diagnostics = d;
    return true;
}

bool grain_layers(const float* density_cmy, uint32_t npix, int width, int height,
                  const float* density_curves, const float* density_curves_layers,
                  uint32_t points, bool positive_film, float* out,
                  FilmingStageDiagnostics* diagnostics) {
    FilmingStageDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };
    if (density_cmy == nullptr || density_curves == nullptr ||
        density_curves_layers == nullptr || out == nullptr || points < 2 ||
        npix == 0 || width <= 0 || height <= 0)
        return give_up("invalid-request");
    if (static_cast<uint64_t>(npix) * 9 > UINT32_MAX) return give_up("frame-too-large");

    // The axis and the layer curves go over as ONE table, because the shader
    // reads both from one binding. The axis is NEGATED here for positive film --
    // on the host, in the same place the CPU does it -- so the shader's
    // ascending search holds without needing to know why.
    std::vector<float> table(static_cast<size_t>(points) * 12);
    for (uint32_t k = 0; k < points; ++k)
        for (int ch = 0; ch < 3; ++ch) {
            const float a = density_curves[k * 3 + ch];
            table[static_cast<size_t>(k) * 3 + ch] = positive_film ? -a : a;
        }
    const size_t layersOff = static_cast<size_t>(points) * 3;
    std::memcpy(table.data() + layersOff, density_curves_layers,
                static_cast<size_t>(points) * 9 * sizeof(float));

    FilmingStageRun r;
    r.mode = kFilmModeLayers;
    r.flags = positive_film ? kFilmFlagPositive : 0u;
    r.npix = npix;
    r.width = width;
    r.height = height;
    r.src_f32 = density_cmy;
    r.dst_f32 = out;
    r.dst_elems = static_cast<size_t>(npix) * 9;
    r.curve_axis = table.data();
    r.curve_count = static_cast<size_t>(points) * 12;
    r.curve_single_block = true;
    r.n = static_cast<int32_t>(points);
    r.L = 2;
    if (!run_filming_stage(r, &d)) return give_up(d.reason);
    if (diagnostics) *diagnostics = d;
    return true;
}

bool exposure_log10(const double* raw, float* log_raw, int width, int height,
                    FilmingStageDiagnostics* diagnostics) {
    FilmingStageDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };
    if (width <= 0 || height <= 0) return give_up("invalid-request");
    const uint64_t comps64 = static_cast<uint64_t>(width) * height * 3;
    if (comps64 == 0 || comps64 > UINT32_MAX) return give_up("invalid-request");
    const bool resident = frame_active(width, height);
    if (!resident && (raw == nullptr || log_raw == nullptr))
        return give_up("invalid-request");

    FilmingStageRun r;
    r.mode = kFilmModeLog10;
    r.npix = static_cast<uint32_t>(comps64);
    r.npix_is_components = true;
    r.width = width;
    r.height = height;
    r.src_f64 = resident ? nullptr : raw;
    r.dst_f32 = resident ? nullptr : log_raw;
    r.curve_count = 0;
    r.n = 2;
    r.L = 2;
    if (!run_filming_stage(r, &d)) return give_up(d.reason);
    if (diagnostics) *diagnostics = d;
    return true;
}

bool blend_mix(const double* a, const double* b, double* out, int width, int height,
               double amount, bool unsharp, FilmingStageDiagnostics* diagnostics) {
    FilmingStageDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };
    if (width <= 0 || height <= 0 || !std::isfinite(amount))
        return give_up("invalid-request");
    const uint64_t comps64 = static_cast<uint64_t>(width) * height * 3;
    if (comps64 == 0 || comps64 > UINT32_MAX) return give_up("invalid-request");
    const uint32_t comps = static_cast<uint32_t>(comps64);
    const bool resident = frame_active(width, height);
    // `b` is always a host plane: it is the FILTERED copy, which no pass leaves
    // resident. Only `a`/`out` can come from the frame.
    if (b == nullptr) return give_up("invalid-request");
    if (!resident && (a == nullptr || out == nullptr)) return give_up("invalid-request");

    FilmingStageRun r;
    r.mode = unsharp ? kFilmModeUnsharp : kFilmModeMix;
    r.npix = comps;
    r.npix_is_components = true;
    r.width = width;
    r.height = height;
    r.src_f64 = resident ? nullptr : a;
    r.dst_f64 = resident ? nullptr : out;
    r.second_f64 = b;
    r.tc_count = comps;
    r.mix_amount = static_cast<float>(amount);
    r.n = 2;
    r.L = 2;
    if (!run_filming_stage(r, &d)) return give_up(d.reason);
    if (diagnostics) *diagnostics = d;
    return true;
}

bool highlight_boost(double* rgb, int width, int height, double boost_ev,
                     double boost_range, double protect_ev,
                     FilmingStageDiagnostics* diagnostics) {
    FilmingStageDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };
    if (width <= 0 || height <= 0) return give_up("invalid-request");
    if (!(boost_ev > 0.0)) return give_up("inactive");   // the CPU's identity
    const uint64_t comps64 = static_cast<uint64_t>(width) * height * 3;
    if (comps64 == 0 || comps64 > UINT32_MAX) return give_up("invalid-request");
    const uint32_t comps = static_cast<uint32_t>(comps64);
    const bool resident = frame_active(width, height);
    if (!resident && rgb == nullptr) return give_up("invalid-request");

    // PASS 1: per-workgroup maxima. The source is a COMPONENT plane here, so
    // npix carries the component count and the geometry is deliberately not the
    // frame's -- MODE_MAX and MODE_BOOST are 1-D over components, matching the
    // CPU's np.max over the whole (h, w, 3) array.
    const uint32_t groups = (comps + 63u) / 64u;
    FilmingStageRun mx;
    mx.mode = kFilmModeMax;
    mx.npix = comps;
    mx.npix_is_components = true;
    mx.width = width;
    mx.height = height;
    mx.src_f64 = resident ? nullptr : rgb;
    mx.src_f32 = nullptr;
    // MODE_MAX writes into binding 3 and reads nothing from binding 2, but every
    // binding must still be backed.
    mx.curve_count = 0;
    mx.table_b_floats_min = groups;
    mx.n = 2;
    mx.L = 2;
    // The destination is unused by MODE_MAX, but the run insists on exactly one
    // being named; in the resident case it flips the front, which this pass must
    // NOT do, so the flip is suppressed by the mode below.
    mx.dst_f32 = nullptr;
    mx.dst_f64 = nullptr;
    if (!run_filming_stage(mx, &d)) return give_up(d.reason);

    // The maximum of the partial maxima, in f64 and on the host, exactly as
    // apply_highlight_boost computes it. Order does not matter: max is
    // associative and commutative, so this is the same number the serial CPU
    // scan produces regardless of how the workgroups divided the plane.
    double max_raw = 0.0;
    {
        std::lock_guard<std::mutex> lk(gpu_mutex());
        Ctx& c = ctx();
        const float* partial = static_cast<const float*>(c.filmK.cmfB.mapped);
        if (partial == nullptr) return give_up("dispatch-failed");
        for (uint32_t g = 0; g < groups; ++g) {
            const double v = static_cast<double>(partial[g]);
            if (v > max_raw) max_raw = v;
        }
    }
    if (!(max_raw > 0.0)) return give_up("inactive");   // the CPU's zero branch

    // Every scalar the map needs, derived in f64 -- verbatim from
    // model/diffusion.cpp::apply_highlight_boost.
    constexpr double kMidgray = 0.184;
    double raw_x0 = kMidgray * std::pow(2.0, protect_ev);
    if (raw_x0 < 0.0) raw_x0 = 0.0;
    if (raw_x0 > max_raw) raw_x0 = max_raw;
    if (raw_x0 == max_raw) return give_up("inactive");
    const double a = std::pow(28.0, 1.0 - boost_range);
    const double x0 = raw_x0 / max_raw;
    const double denom = std::exp(a * (1.0 - x0)) - a * (1.0 - x0) - 1.0;
    if (!(denom > 0.0)) return give_up("degenerate-range");
    const double k = (std::pow(2.0, boost_ev) - 1.0) / denom;

    // PASS 2: the map.
    FilmingStageRun bp;
    bp.mode = kFilmModeBoost;
    bp.npix = comps;
    bp.npix_is_components = true;
    bp.width = width;
    bp.height = height;
    bp.src_f64 = resident ? nullptr : rgb;
    bp.dst_f64 = resident ? nullptr : rgb;
    bp.curve_count = 0;
    bp.n = 2;
    bp.L = 2;
    bp.raw_x0 = static_cast<float>(raw_x0);
    bp.inv_max_raw = static_cast<float>(1.0 / max_raw);
    bp.boost_scale = static_cast<float>(k * max_raw);
    bp.boost_a = static_cast<float>(a);
    if (!run_filming_stage(bp, &d)) return give_up(d.reason);
    if (diagnostics) *diagnostics = d;
    return true;
}

// --- f32 FFT convolution (#216) ---------------------------------------------
//
// The host owns every decision, as everywhere else here: the twiddle table is
// generated in f64 and uploaded as f32, and the transform shape and tile
// geometry are resolved before a command buffer exists. The shader owns no
// parameter.
//
// THE TWO PATHS NO LONGER TILE IDENTICALLY, and this comment used to say they
// did. The transform size came from the CPU path's own selector
// (kernels/fft_convolve.h's fft_convolve_transform_size) until #227 made the
// GPU transform RECTANGULAR; choose_fft_rect below ranks independent powers of
// two per axis under a cell budget the CPU model has no concept of, and at the
// export's ks it deliberately picks 8192 x 4096 (three tiles) where the square
// selector picks 4096 (twelve). `fft_convolve_transform_size` is not called
// from this file any more. If you are chasing a GPU/CPU difference, the shape
// chooser is a place the two genuinely diverge -- by design, on the Fast GPU
// contract, not by accident.
//
// ONE SUBMISSION PER TILE, not one per convolution. A 4096 x 4096 tile is 17
// dispatches over 16.7M elements each (pack, 7 forward, multiply, 7 inverse,
// unpack -- each 2-D transform being 3 radix-16 stages per axis plus one
// transpose); batching a whole multi-tile convolution into one command buffer
// is the shape that trips the ~2 s GPU watchdog. A tile is the natural unit
// anyway -- it is what the CPU path loops over.
namespace {

// std430 push constant; must match fft_convolve.comp's Push block exactly.
struct FftPush {
    uint32_t op;
    uint32_t nx;
    uint32_t ny;
    uint32_t len;
    uint32_t rows;
    uint32_t twn;
    uint32_t stage;
    uint32_t sign_neg;
    uint32_t src_is_a;
    uint32_t groups_x;
    uint32_t pad_w;
    uint32_t pad_h;
    uint32_t tile_x;
    uint32_t tile_y;
    uint32_t radius;
    uint32_t src_w;
    uint32_t src_h;
    uint32_t kern_base;
    uint32_t ks;
    uint32_t out_w;
    uint32_t out_h;
    uint32_t out_x;
    uint32_t out_y;
    uint32_t out_stride;
    uint32_t out_offset;
    uint32_t kern_offset;
    uint32_t src2_base;
    uint32_t out2_offset;
    uint32_t kern_offset2;
    float scale;
};
// 120 after pair mode (#227) added src2_base / out2_offset / kern_offset2 and
// the rectangular transform replaced `n` with nx / ny / len / rows / twn.
// Vulkan guarantees maxPushConstantsSize >= 128, so this still fits everywhere
// (the Adreno 840 this was measured on reports 256).
static_assert(sizeof(FftPush) == 120, "push block must match fft_convolve.comp");
static_assert(sizeof(FftPush) <= 128, "push block exceeds the guaranteed minimum");

// Pick the transform rectangle. Overlap-save keeps a (nx-ks+1) x (ny-ks+1) block
// per tile, so a SQUARE transform is tied to the worse axis: at ks = 3059 on a
// 4080x3060 frame, 4096^2 keeps a 1038 px block and needs 4 x 3 = twelve tiles.
// 8192 x 4096 doubles the elements per tile but keeps 5134 x 1038 -- one tile
// across, three down -- for 1.9x less total work.
//
// Cost is the transform's own work, tiles * elements * log2(elements). It is a
// RANKING, not a prediction of milliseconds, and ties go to the smaller
// allocation because memory is what actually refuses on a phone.
//
// THIS MODEL WAS ACCUSED OF BEING WRONG AT THE TOP END AND IT WAS NOT. With the
// naive transpose the wide 8192 x 4096 rectangle measured ~10% slower than the
// 4096 square even though it transforms half the cells, which looked like proof
// that cost grows superlinearly with transform size. Calibrating the exponent to
// that point (tiles * cells^2) fit the top end and WRECKED the bottom -- it drove
// the chooser to tiny transforms with enormous tile counts where dispatch
// overhead dominates: a 96x72 ks=11 case went from 20 tiles / 348 dispatches to
// 192 tiles / 2502, 28.5 ms -> 183.0 ms, 6.4x worse.
//
// The real cause was the TRANSPOSE, whose locality collapses as the array grows
// and which was costing ~12 butterfly passes. Tiled, the comparison inverts --
// wide 1015.0 ms against square 1270.9, 1.23x -- and the work model is right at
// both ends after all.
//
// Two things worth keeping from that: a single counter-example is not enough to
// re-fit a model (two points cannot carry two parameters), and a shape verdict is
// only as good as the inner loop it was taken on. See docs/research/perf-lab.md
// section 32.
struct FftRect { int nx = 0, ny = 0, tiles = 0; };
FftRect choose_fft_rect(int w, int h, int ks, int max_axis, uint64_t max_elements) {
    FftRect best;
    double best_cost = 0.0;
    for (int nx = 1; nx <= max_axis; nx *= 2) {
        if (nx < ks + 1) continue;
        const int bx = nx - ks + 1;
        for (int ny = 1; ny <= max_axis; ny *= 2) {
            if (ny < ks + 1) continue;
            const uint64_t elems = static_cast<uint64_t>(nx) * ny;
            if (elems > max_elements) continue;
            const int by = ny - ks + 1;
            const int tx = (w + bx - 1) / bx;
            const int ty = (h + by - 1) / by;
            const double e = static_cast<double>(elems);
            const double cost = static_cast<double>(tx) * ty * e * std::log2(e);
            if (best.nx == 0 || cost < best_cost ||
                (cost == best_cost && elems < static_cast<uint64_t>(best.nx) * best.ny)) {
                best_cost = cost;
                best = FftRect{nx, ny, tx * ty};
            }
        }
    }
    return best;
}

constexpr uint32_t kFftOpPack = 0u;
constexpr uint32_t kFftOpStage = 1u;
constexpr uint32_t kFftOpTranspose = 2u;
constexpr uint32_t kFftOpMul = 3u;
constexpr uint32_t kFftOpUnpack = 4u;
constexpr uint32_t kFftOpStage4 = 5u;
constexpr uint32_t kFftOpPackKernel = 6u;
constexpr uint32_t kFftOpPack2 = 7u;
constexpr uint32_t kFftOpMul2 = 8u;
constexpr uint32_t kFftOpUnpack2 = 9u;
constexpr uint32_t kFftOpTransposeTiled = 10u;
constexpr uint32_t kFftOpStage16 = 11u;

}  // namespace

bool fft_convolve(const FftConvolveRequest& r, double* out,
                  FftConvolveDiagnostics* diagnostics) {
    FftConvolveDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };

    // Every shape question is answered before Vulkan is touched, so a bad
    // request can never half-write the caller's output.
    if (out == nullptr || r.src_rgb == nullptr || r.kern == nullptr)
        return give_up("null-span");
    if (r.ks < 1 || (r.ks % 2) == 0) return give_up("kernel-not-odd");
    if (r.width < 1 || r.height < 1) return give_up("empty-frame");
    if (r.channel < 0 || r.channel > 2) return give_up("bad-channel");
    if (r.out_stride < 1 || r.out_offset < 0 || r.out_offset >= r.out_stride)
        return give_up("bad-out-addressing");
    // Pair mode is all-or-nothing: a half-specified second channel is a caller
    // bug that would otherwise convolve the wrong plane into the wrong slot.
    const bool pair = r.channel2 >= 0;
    if (pair) {
        if (r.channel2 > 2 || r.channel2 == r.channel) return give_up("bad-channel2");
        if (!r.kern2) return give_up("null-kern2");
        if (r.out_offset2 < 0 || r.out_offset2 >= r.out_stride)
            return give_up("bad-out-addressing2");
    }

    const int w = r.width, h = r.height, ks = r.ks;
    const int radius = (ks - 1) / 2;
    const int pw = w + ks - 1, ph = h + ks - 1;
    int cap = r.max_transform;
    if (cap > kFftGpuMaxTransform) cap = kFftGpuMaxTransform;
    // `max_elements` is the memory lever and `cap` the per-axis one. The caller
    // walks max_elements DOWN on refusal, exactly as model/diffusion.cpp's
    // reserve_fft_scratch walks the CPU ceiling down, so a memory-tight device
    // gets a smaller rectangle rather than no GPU route at all.
    const FftRect rect = choose_fft_rect(w, h, ks, cap, r.max_elements);
    if (rect.nx <= 0) return give_up("transform-too-large");
    const int tnx = rect.nx, tny = rect.ny;
    // Reported as the LARGER axis: the field is an int and existing callers read
    // it as "how big a transform did this run", which the wider axis answers.
    d.transform_size = tnx > tny ? tnx : tny;

    const uint32_t utnx = static_cast<uint32_t>(tnx);
    const uint32_t utny = static_cast<uint32_t>(tny);
    // One twiddle table serves both axes: a length-L transform wants
    // exp(-2*pi*i*k/(2L)), whose index into a twn-sized table is k*twn/(2L) --
    // the length cancels. So the table is built once at the larger extent.
    const uint32_t twn = utnx > utny ? utnx : utny;
    const int block_x = tnx - ks + 1;
    const int block_y = tny - ks + 1;

    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok) return give_up("gpu-unavailable");
    const VkPhysicalDeviceLimits& limits = c.properties.limits;
    Ctx::Kernel& s = c.fftK;

    // Buffer roles: in = complex A, out = complex B, dyeB = twiddles + kernel
    // spectrum, cmfB = the real plane (padded input, then the output window).
    const uint64_t complexCount = static_cast<uint64_t>(tnx) * tny;
    const VkDeviceSize complexBytes = complexCount * 8;             // vec2 f32
    // A FULL turn of twiddles, not a half one: a radix-4 group needs
    // W^(3*k*step), whose index reaches 3n/4. n extra vec2 is 32 KB at n = 4096.
    const uint32_t kernOffset = twn;                                // in vec2 units
    // Pair mode holds BOTH kernel spectra live at once, because the split-and-
    // recombine reads them in the same pass. That is the whole memory cost of
    // the mode; if the device will not give it, ensureResidentBuf fails and the
    // caller drops to two single-channel calls.
    const uint64_t kernSpectra = pair ? 2u : 1u;
    const uint32_t kernOffset2 =
        pair ? static_cast<uint32_t>(kernOffset + complexCount) : 0u;
    const VkDeviceSize twBytes =
        (static_cast<uint64_t>(kernOffset) + kernSpectra * complexCount) * 8;
    // The real plane buffer: the source plane, the output window, and a staging
    // slot for this channel's kernel. No padded plane -- that is the point.
    const uint64_t srcCount = static_cast<uint64_t>(w) * h;
    const uint64_t outCount = srcCount;
    const uint64_t kernCount = static_cast<uint64_t>(ks) * ks;
    const uint64_t planes = pair ? 2u : 1u;
    const uint64_t src2Base = srcCount;                  // pair mode only
    const uint64_t outBase = planes * srcCount;
    const uint64_t out2Base = outBase + outCount;        // pair mode only
    const uint64_t kernBase = outBase + planes * outCount;
    const VkDeviceSize realBytes =
        (planes * srcCount + planes * outCount + kernCount) * sizeof(float);
    if (complexBytes > limits.maxStorageBufferRange ||
        twBytes > limits.maxStorageBufferRange ||
        realBytes > limits.maxStorageBufferRange)
        return give_up("buffer-too-large");

    uint32_t dispatches = 0;
    bool grid_ok = true;

    bool ok = false;
    do {
        if (!s.pipelineReady &&
            !build_scan_pipeline(c, s, kFftConvolveSpv, sizeof(kFftConvolveSpv),
                                 sizeof(FftPush)))
            break;

        // A, B and the table are GPU-only scratch: device-local, never mapped.
        // The staging buffer for the twiddles is host-visible and tiny (n vec2,
        // 32 KB at n = 4096), copied in at the head of the first submission.
        constexpr VkBufferUsageFlags kWorkUsage =
            VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT |
            VK_BUFFER_USAGE_TRANSFER_DST_BIT;
        const VkDeviceSize twStageBytes = static_cast<VkDeviceSize>(kernOffset) * 8;
        PointwiseChainDiagnostics unused{};
        const bool hadA = c.fftWork[0].cap >= complexBytes && c.fftWork[0].buf;
        const bool hadB = c.fftWork[1].cap >= complexBytes && c.fftWork[1].buf;
        const bool hadTw = c.fftWork[2].cap >= twBytes && c.fftWork[2].buf;
        const bool hadReal = s.cmfB.cap >= realBytes && s.cmfB.buf;
        if (!c.ensureResidentBuf(c.fftWork[0], complexBytes, kWorkUsage,
                                 VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                                 VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                                 /*persistentMap=*/false, unused,
                                 VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) break;
        if (!c.ensureResidentBuf(c.fftWork[1], complexBytes, kWorkUsage,
                                 VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                                 VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                                 /*persistentMap=*/false, unused,
                                 VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) break;
        if (!c.ensureResidentBuf(c.fftWork[2], twBytes, kWorkUsage,
                                 VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                                 VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
                                 /*persistentMap=*/false, unused,
                                 VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) break;
        if (!c.ensureBuf(s.dyeB, twStageBytes)) break;   // twiddle staging, mapped
        if (!c.ensureBuf(s.cmfB, realBytes)) break;      // real plane, mapped
        // Report what the driver actually handed back, because "device-local"
        // is a request, not a guarantee: a device whose every memory type is
        // host-visible will fall through to one, and the pass would then be
        // running on exactly the memory it meant to avoid, silently.
        d.scratch_host_visible =
            (c.fftWork[0].memoryFlags & VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT) != 0;
        if (!hadA || !hadB || !hadTw || !hadReal) {
            VkBuffer bufs[4] = {c.fftWork[0].buf, c.fftWork[1].buf,
                                c.fftWork[2].buf, s.cmfB.buf};
            VkDeviceSize caps[4] = {c.fftWork[0].cap, c.fftWork[1].cap,
                                    c.fftWork[2].cap, s.cmfB.cap};
            VkDescriptorBufferInfo dbi[4];
            VkWriteDescriptorSet wds[4];
            for (uint32_t i = 0; i < 4; ++i) {
                dbi[i] = VkDescriptorBufferInfo{bufs[i], 0, caps[i]};
                wds[i] = VkWriteDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
                wds[i].dstSet = s.dset;
                wds[i].dstBinding = i;
                wds[i].descriptorCount = 1;
                wds[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
                wds[i].pBufferInfo = &dbi[i];
            }
            vkUpdateDescriptorSets(c.device, 4, wds, 0, nullptr);
        }

        // Twiddles, in f64, once per call. w[k] = exp(-2*pi*i*k/n) for k < n;
        // the inverse conjugates in the shader rather than needing a second table.
        const auto t_up = std::chrono::steady_clock::now();
        {
            float* tw = static_cast<float*>(s.dyeB.mapped);   // staging
            const double step =
                -6.283185307179586476925286766559 / static_cast<double>(twn);
            for (uint32_t k = 0; k < twn; ++k) {
                const double a = step * static_cast<double>(k);
                tw[k * 2 + 0] = static_cast<float>(std::cos(a));
                tw[k * 2 + 1] = static_cast<float>(std::sin(a));
            }
        }
        float* real = static_cast<float*>(s.cmfB.mapped);
        // The source plane, gathered out of the interleaved image, and the
        // kernel. Non-finite inputs are guarded HERE and not in the shader: the
        // CPU path propagates them through a linear sum, but a NaN inside a
        // transform poisons the whole tile rather than one output, which is a
        // different failure.
        {
            const double* src = r.src_rgb;
            const int ch = r.channel;
            const int ch2 = r.channel2;
            const bool two = pair;
            parallel_for(0, static_cast<int>(srcCount), [&](int lo, int hi) {
                for (int i = lo; i < hi; ++i) {
                    const double v = src[static_cast<size_t>(i) * 3 + ch];
                    real[i] = std::isfinite(v) ? static_cast<float>(v) : 0.0f;
                    if (two) {
                        const double v2 = src[static_cast<size_t>(i) * 3 + ch2];
                        real[src2Base + i] =
                            std::isfinite(v2) ? static_cast<float>(v2) : 0.0f;
                    }
                }
            });
            for (size_t i = 0; i < kernCount; ++i)
                real[kernBase + i] = static_cast<float>(r.kern[i]);
        }
        d.upload_ms = std::chrono::duration<double, std::milli>(
                          std::chrono::steady_clock::now() - t_up).count();

        auto barrier = [](VkCommandBuffer cmd, VkAccessFlags src, VkAccessFlags dst,
                          VkPipelineStageFlags srcStage, VkPipelineStageFlags dstStage) {
            VkMemoryBarrier mb{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
            mb.srcAccessMask = src;
            mb.dstAccessMask = dst;
            vkCmdPipelineBarrier(cmd, srcStage, dstStage, 0, 1, &mb, 0, nullptr, 0, nullptr);
        };

        auto emit = [&](VkCommandBuffer cmd, FftPush& p, uint32_t op, uint64_t threads) {
            if (threads == 0 || threads > UINT32_MAX) { grid_ok = false; return; }
            const PointwiseDispatchGrid g = plan_pointwise_dispatch(
                static_cast<uint32_t>(threads), limits.maxComputeWorkGroupCount[0],
                limits.maxComputeWorkGroupCount[1]);
            if (!g.valid) { grid_ok = false; return; }
            p.op = op;
            p.groups_x = g.groups_x;
            vkCmdPushConstants(cmd, s.pl, VK_SHADER_STAGE_COMPUTE_BIT, 0,
                               sizeof(FftPush), &p);
            vkCmdDispatch(cmd, g.groups_x, g.groups_y, 1);
            barrier(cmd, VK_ACCESS_SHADER_WRITE_BIT,
                    VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT,
                    VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,
                    VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
            ++dispatches;
        };

        // One 2D transform: FFT along rows, transpose, FFT along rows again.
        // Forward leaves the spectrum TRANSPOSED and the inverse undoes exactly
        // that, so the pair round-trips to the original orientation.
        // RADIX 4 WHEREVER IT FITS. Each butterfly pass reads and writes the whole
        // n x n plane -- 268 MB of traffic at n = 4096 -- so the pass COUNT is the
        // cost, and radix 4 needs log4(n) passes where radix 2 needs log2(n).
        // A radix-2 pass finishes the sizes whose log2 is odd; `stage` carries the
        // accumulated L rather than a stage index precisely so the two can mix.
        // RADIX 2 vs RADIX 4, selectable, because the device did not agree with
        // the arithmetic. Radix 4 halves the number of whole-plane passes, which
        // on a memory-bound kernel should halve the time; measured on an Adreno
        // 840 it was SLOWER. The suspects are the three scattered twiddle
        // gathers a radix-4 group needs against radix 2's one, and four
        // concurrent memory streams per thread against two. Rather than argue
        // it, this makes the two comparable in ONE binary on a cooled device --
        // the only comparison this phone's ~30% between-capture drift does not
        // swamp.
        // SPK_FFT_TRANSPOSE=0 restores the naive scatter in the SAME binary, so
        // the two can be interleaved on one cooled device. The transpose is ~half
        // the 2-D transform (see the derivation in fft_convolve.comp), which makes
        // it the one pass most worth an A/B.
        bool tiled_transpose = true;
        if (const char* tv = std::getenv("SPK_FFT_TRANSPOSE")) tiled_transpose = tv[0] != '0';
        // SPK_FFT_RADIX16=0 drops back to radix 4 in the SAME binary. Sixteen
        // values live per thread is real register pressure, and a spill would
        // hand back exactly the global traffic the radix exists to remove, so
        // this one is measured rather than assumed.
        bool radix16 = true;
        if (const char* r16 = std::getenv("SPK_FFT_RADIX16")) radix16 = r16[0] != '0';
        bool use_radix4 = true;
        if (const char* rv = std::getenv("SPK_FFT_RADIX"))
            if (rv[0] == '2') use_radix4 = false;

        // Forward runs x then y and leaves the spectrum TRANSPOSED ([kx][ky]);
        // the inverse runs y then x and transposes it back, so the two cancel and
        // no third transpose is needed. That is why the inverse's axis order is
        // the reverse of the forward's rather than the same.
        auto emit_fft2 = [&](VkCommandBuffer cmd, FftPush& p, bool inverse) {
            p.sign_neg = inverse ? 0u : 1u;
            const uint32_t first_len = inverse ? utny : utnx;
            const uint32_t second_len = inverse ? utnx : utny;
            for (int pass = 0; pass < 2; ++pass) {
                const uint32_t len = pass == 0 ? first_len : second_len;
                p.len = len;
                p.rows = static_cast<uint32_t>(complexCount / len);
                for (uint32_t L = 1u; L < len;) {
                    p.stage = L;
                    // Take the highest radix the remaining transform divides by:
                    // every stage moves the whole plane, so the pass COUNT is the
                    // cost and a bigger radix is strictly fewer passes for the
                    // same butterflies. 16 -> 4 -> 2 as the remainder runs out.
                    if (radix16 && (len / L) % 16u == 0u) {
                        emit(cmd, p, kFftOpStage16, complexCount / 16);
                        L *= 16u;
                    } else if (use_radix4 && (len / L) % 4u == 0u) {
                        emit(cmd, p, kFftOpStage4, complexCount / 4);
                        L *= 4u;
                    } else {
                        emit(cmd, p, kFftOpStage, complexCount / 2);
                        L *= 2u;
                    }
                    p.src_is_a ^= 1u;
                }
                if (pass == 0) {
                    // Transposes the rows x len array the pass just produced.
                    //
                    // The tiled variant wants ONE WORKGROUP PER 16x16 TILE, not
                    // one thread per cell, so the thread count it is dispatched
                    // with is a group count in disguise: the planner turns
                    // tiles*WG threads into exactly `tiles` groups, and the
                    // shader rebuilds the linear group index from groups_x.
                    if (tiled_transpose) {
                        const uint64_t tx = (p.len + 15u) / 16u;
                        const uint64_t ty = (p.rows + 15u) / 16u;
                        emit(cmd, p, kFftOpTransposeTiled, tx * ty * 64u);
                    } else {
                        emit(cmd, p, kFftOpTranspose, complexCount);
                    }
                    p.src_is_a ^= 1u;
                }
            }
        };

        auto run = [&](auto&& record) -> bool {
            if (vkResetCommandBuffer(s.cmd, 0) != VK_SUCCESS) return false;
            VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            if (vkBeginCommandBuffer(s.cmd, &bi) != VK_SUCCESS) return false;
            vkCmdBindPipeline(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pipe);
            vkCmdBindDescriptorSets(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pl, 0, 1,
                                    &s.dset, 0, nullptr);
            // Host writes (the twiddles, the padded plane) and the previous
            // submission's transfer into the twiddle buffer both have to be
            // visible to this one. Cross-submission visibility is not implied by
            // the fence for device reads, so it is stated once per command buffer.
            barrier(s.cmd, VK_ACCESS_HOST_WRITE_BIT | VK_ACCESS_TRANSFER_WRITE_BIT,
                    VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT,
                    VK_PIPELINE_STAGE_HOST_BIT | VK_PIPELINE_STAGE_TRANSFER_BIT,
                    VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
            record(s.cmd);
            if (vkEndCommandBuffer(s.cmd) != VK_SUCCESS) return false;
            VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
            si.commandBufferCount = 1;
            si.pCommandBuffers = &s.cmd;
            if (vkQueueSubmit(c.queue, 1, &si, s.fence) != VK_SUCCESS) return false;
            if (!c.waitFence(s.fence))
                return false;
            if (vkResetFences(c.device, 1, &s.fence) != VK_SUCCESS) return false;
            return true;
        };

        const auto t_gpu = std::chrono::steady_clock::now();
        bool gpu_ok = true;

        // Pass 1: the kernel spectrum. The kernel sits at the ORIGIN of the
        // transform, not centred -- centring would translate the image by the
        // radius (see the derivation in kernels/fft_convolve.cpp). It is
        // transformed by the same code as the tiles, so it lands in the same
        // transposed layout the pointwise multiply expects.
        // One submission per kernel, landing its spectrum at `destVec2`. Pair
        // mode runs this twice; the kernel STAGING slot is reused between the
        // two because `run` waits on its fence, so the host write that follows
        // it cannot race the pass that read it.
        auto transform_kernel = [&](uint32_t destVec2, bool first) {
            FftPush p{};
            p.nx = utnx;
            p.ny = utny;
            p.twn = twn;
            p.ks = static_cast<uint32_t>(ks);
            p.kern_base = static_cast<uint32_t>(kernBase);
            p.kern_offset = kernOffset;
            p.src_is_a = 1u;
            return run([&](VkCommandBuffer cmd) {
                if (first) {
                    // The twiddles go device-side first: they are read by every
                    // butterfly pass, so leaving them in host-coherent memory
                    // would reintroduce exactly the cost the resident buffers
                    // remove.
                    VkBufferCopy twCopy{0, 0, twStageBytes};
                    vkCmdCopyBuffer(cmd, s.dyeB.buf, c.fftWork[2].buf, 1, &twCopy);
                    barrier(cmd, VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_SHADER_READ_BIT,
                            VK_PIPELINE_STAGE_TRANSFER_BIT,
                            VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT);
                }
                emit(cmd, p, kFftOpPackKernel, complexCount);  // always writes A
                emit_fft2(cmd, p, /*inverse=*/false);
                barrier(cmd, VK_ACCESS_SHADER_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT,
                        VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
                VkBufferCopy region{0, static_cast<VkDeviceSize>(destVec2) * 8, complexBytes};
                vkCmdCopyBuffer(cmd, p.src_is_a ? c.fftWork[0].buf : c.fftWork[1].buf,
                                c.fftWork[2].buf, 1, &region);
            });
        };

        gpu_ok = transform_kernel(kernOffset, /*first=*/true);
        if (gpu_ok && pair) {
            for (size_t i = 0; i < kernCount; ++i)
                real[kernBase + i] = static_cast<float>(r.kern2[i]);
            gpu_ok = transform_kernel(kernOffset2, /*first=*/false);
        }

        // Pass 2..N: one overlap-save tile per submission.
        const float scale = static_cast<float>(
            1.0 / (static_cast<double>(tnx) * static_cast<double>(tny)));
        for (int y0 = 0; gpu_ok && grid_ok && y0 < h; y0 += block_y) {
            for (int x0 = 0; gpu_ok && grid_ok && x0 < w; x0 += block_x) {
                const int ny = std::min(block_y, h - y0);
                const int nx = std::min(block_x, w - x0);
                FftPush p{};
                p.nx = utnx;
                p.ny = utny;
                p.twn = twn;
                p.pad_w = static_cast<uint32_t>(pw);
                p.pad_h = static_cast<uint32_t>(ph);
                p.tile_x = static_cast<uint32_t>(x0);
                p.tile_y = static_cast<uint32_t>(y0);
                p.radius = static_cast<uint32_t>(radius);
                p.src_w = static_cast<uint32_t>(w);
                p.src_h = static_cast<uint32_t>(h);
                p.out_w = static_cast<uint32_t>(nx);
                p.out_h = static_cast<uint32_t>(ny);
                p.out_x = static_cast<uint32_t>(ks - 1);
                p.out_y = static_cast<uint32_t>(ks - 1);
                p.out_stride = static_cast<uint32_t>(w);
                p.out_offset = static_cast<uint32_t>(
                    outBase + static_cast<uint64_t>(y0) * w + x0);
                p.kern_offset = kernOffset;
                p.kern_offset2 = kernOffset2;
                p.src2_base = static_cast<uint32_t>(src2Base);
                p.out2_offset = static_cast<uint32_t>(
                    out2Base + static_cast<uint64_t>(y0) * w + x0);
                p.scale = scale;
                p.src_is_a = 1u;
                gpu_ok = run([&](VkCommandBuffer cmd) {
                    emit(cmd, p, pair ? kFftOpPack2 : kFftOpPack, complexCount);
                    emit_fft2(cmd, p, /*inverse=*/false);
                    if (pair) {
                        // OP_MUL2 reads k and -k, so it cannot run in place and
                        // the ping-pong has to flip. OP_MUL can and does not.
                        emit(cmd, p, kFftOpMul2, complexCount);
                        p.src_is_a ^= 1u;
                    } else {
                        emit(cmd, p, kFftOpMul, complexCount);  // in place: no flip
                    }
                    emit_fft2(cmd, p, /*inverse=*/true);
                    emit(cmd, p, pair ? kFftOpUnpack2 : kFftOpUnpack,
                         static_cast<uint64_t>(nx) * static_cast<uint64_t>(ny));
                });
                ++d.tiles;
            }
        }
        d.gpu_ms = std::chrono::duration<double, std::milli>(
                       std::chrono::steady_clock::now() - t_gpu).count();
        d.dispatches = dispatches;
        if (!gpu_ok) break;
        if (!grid_ok) { d.reason = "dispatch-too-large"; break; }

        const auto t_back = std::chrono::steady_clock::now();
        {
            const int stride = r.out_stride;
            auto scatter = [&](uint64_t base, int offset) {
                const float* src = real + base;
                parallel_for(0, h, [&](int lo, int hi) {
                    for (int y = lo; y < hi; ++y) {
                        const float* srow = src + static_cast<size_t>(y) * w;
                        double* drow = out + static_cast<size_t>(y) * w * stride + offset;
                        for (int x = 0; x < w; ++x)
                            drow[static_cast<size_t>(x) * stride] = srow[x];
                    }
                });
            };
            scatter(outBase, r.out_offset);
            if (pair) scatter(out2Base, r.out_offset2);
        }
        d.readback_ms = std::chrono::duration<double, std::milli>(
                            std::chrono::steady_clock::now() - t_back).count();
        ok = true;
    } while (false);

    if (!ok) {
        const char* reason = d.reason && d.reason[0] ? d.reason : "dispatch-failed";
        if (!c.last_wait_cancelled) c.destroyScan();
        return give_up(reason);
    }
    d.engaged = true;
    d.paired = pair;
    d.reason = "";
    if (diagnostics) *diagnostics = d;
    return true;
}

// ---------------------------------------------------------------------------
// In-emulsion scatter + back-reflection halation (issue #206).
//
// Shader: gpu/halation_scatter.comp, adapted from spektrafilm OFX (see the file
// header and docs/research/spektrafilm-ofx-port.md). The dispatch sequence
// follows upstream's SpektraVulkanRenderer.cpp halation pass; the single
// weighted sum buffer, the whole-frame residency, the f64 staging and the
// parameter plumbing are Android additions.
//
// Model (model/diffusion.cpp::apply_halation_um, per channel c):
//   core   = G(sigma_core[c]) * raw
//   tail   = sum_k amp_k * G(ratio_k * lambda_tail[c]) * raw    (k = 0..2)
//   raw'   = (1 - s) * raw + s * ((1 - w[c]) * core + w[c] * tail)
//   blur   = sum_k decay_k * G(sigma_h[c] * sqrt(k)) * raw'      (k = 1..N)
//   out    = raw' + a[c] * blur, / (1 + a[c]) when renormalising
//
// Residency: the whole frame lives on the device for the pass (four packed
// f32 planes), so every blur, IIR sweeps included, sees the complete image
// exactly as the CPU pass does; the earlier row slicing with a halo left an
// IIR transient at slice joins and could not fit the DIR tail's 10-sigma halo
// at export scale. Upload and readback go through a fixed staging band of
// whole rows, which never touches the numbers (a test proves this).
// ---------------------------------------------------------------------------
namespace {

// CoreParams in halation_scatter.comp: upstream's 104-byte push block, of
// which this pass consumes width/height/operation/sigmaMode/component.
struct HalationPush {
    uint32_t width = 0, height = 0;
    float filmExposureEv = 0.f, filmGamma = 0.f;
    uint32_t exposureCount = 0;
    int32_t inputColorSpace = 0, rgbToRawMethod = 0;
    uint32_t colorSpaceCount = 0, transferLutSize = 0;
    float colorDecodeMin = 0.f, colorDecodeMax = 0.f;
    uint32_t hanatosWidth = 0, hanatosHeight = 0;
    uint32_t operation = 0, sigmaMode = 0, component = 0;
    int32_t filmPushPullMode = 0;
    float filmPushPullStops = 0.f;
    uint32_t fullWidth = 0, fullHeight = 0, tileOriginX = 0, tileOriginY = 0;
    uint32_t activeOriginX = 0, activeOriginY = 0, activeWidth = 0, activeHeight = 0;
};
static_assert(sizeof(HalationPush) == 104, "push block must match halation_scatter.comp");

constexpr uint32_t kHalOpClear = 0u;
constexpr uint32_t kHalOpScatterResolve = 4u;
constexpr uint32_t kHalOpBounceResolveRaw = 10u;
constexpr uint32_t kHalOpLineInPlace = 12u;      // IIR channels, one thread per column, in place on buf1
constexpr uint32_t kHalOpLineYAccumulate = 13u;  // IIR channels, buf1 += w * blur(in0), buf3 scratch
constexpr uint32_t kHalOpFirX = 14u;             // FIR channels, per pixel
constexpr uint32_t kHalOpFirYAccumulate = 16u;
constexpr uint32_t kHalOpTranspose = 17u;        // tiled, component = channel mask
constexpr uint32_t kHalLineThreads = 256u;       // kThreadsPerGroup in the shader
constexpr uint32_t kHalTransposeTile = 32u;
constexpr uint32_t kHalSigmaCore = 0u;
constexpr uint32_t kHalSigmaTail = 1u;
constexpr uint32_t kHalSigmaBounce = 2u;
// FrameFloats indices (binding 27), as the shader reads them.
constexpr uint32_t kHalFramePixelSizeUm = 29u;
constexpr uint32_t kHalFrameScatterAmount = 30u;
constexpr uint32_t kHalFrameScatterScale = 31u;
constexpr uint32_t kHalFrameHalationAmount = 32u;
constexpr uint32_t kHalFrameHalationScale = 33u;
constexpr uint32_t kHalFrameStrength = 34u;      // +0..2
constexpr uint32_t kHalFrameFirstSigma = 37u;    // +0..2
constexpr uint32_t kHalFrameCoreUm = 80u;        // +0..2
constexpr uint32_t kHalFrameTailUm = 83u;        // +0..2
constexpr uint32_t kHalFrameTailWeight = 86u;    // +0..2
constexpr uint32_t kHalFrameRenormalize = 91u;
// BlurTable (see the shader): per blur slot and channel, the sigma, the
// FIR/IIR class, the accumulation weight and the four Young-van Vliet
// coefficients as double-float pairs. Slot 0 is the scatter core, 1..3 the
// tail surrogates, 4.. the bounces.
constexpr uint32_t kHalFrameBlurBase = 96u;
constexpr uint32_t kHalBlurStride = 12u;
constexpr uint32_t kHalBlurFieldSigma = 0u;
constexpr uint32_t kHalBlurFieldIsIir = 1u;
constexpr uint32_t kHalBlurFieldWeight = 2u;
constexpr uint32_t kHalBlurFieldB = 3u;          // hi, lo
constexpr uint32_t kHalBlurFieldP1 = 5u;
constexpr uint32_t kHalBlurFieldP2 = 7u;
constexpr uint32_t kHalBlurFieldP3 = 9u;
constexpr uint32_t kHalBlurFieldFirRadius = 11u;
constexpr int kHalMaxFirRadius = 256;            // the shader's tap-loop bound
constexpr uint32_t kHalMaxBounces = 8u;          // the UI allows 1..5
// The mixture (#213) puts one slot per Gaussian and a 7-term fit over three
// groups reaches 54, so the table is sized for it rather than for the bounces.
// The shader indexes frameFloats as a runtime-sized array and derives no bound of
// its own, so this is a host-side capacity decision only -- no SPIR-V change.
constexpr uint32_t kHalMaxMixture = 64u;
constexpr uint32_t kHalBlurSlots = 4u + kHalMaxBounces + kHalMaxMixture;
constexpr uint32_t kHalFrameFloatCount = kHalFrameBlurBase + kHalBlurSlots * 3u * kHalBlurStride;
constexpr double kHalSmallSigmaMax = 3.0;        // kSmallSigmaMaxD: IIR at and above
// Largest blur sigma (px) the pass accepts. The gate measures the double-float
// recursion against the f64 CPU filter up to this value on a flat field, a
// step and the real blends (the DIR tail is 63 px at 12.5 MP, and the widest
// UI-reachable halation bounce is 157 px).
constexpr double kHalMaxSigma = 256.0;
// fast_exponential_filter's three-Gaussian surrogate of the isotropic
// exponential kernel (kernels/exponential_filter.cpp).
constexpr double kHalTailAmplitude[3] = {0.1633, 0.6496, 0.1870};
constexpr double kHalTailRatio[3] = {0.5360, 1.5236, 2.7684};
constexpr uint32_t kHalSetCount = 11u;
constexpr VkDeviceSize kHalPixelBytes = 12;      // three f32, packed
constexpr uint32_t kHalWorkBuffers = 4u;         // src, sum, x, xT
// Whole-frame residency ceiling for the four work buffers (48 B/px: ~22 MP).
// Above it the pass refuses and the CPU runs; bringing back row bands with the
// IIR state carried through host-side storage is the upgrade path if a larger
// export ever needs the GPU pass.
constexpr VkDeviceSize kHalWorkBudgetBytes = 1024ull << 20;
constexpr VkDeviceSize kHalStagingBytes = 64ull << 20;  // upload/readback band
constexpr uint32_t kHalGroupX = 32u, kHalGroupY = 8u;
constexpr uint32_t kHalSrc = 0u, kHalSum = 1u, kHalX = 2u, kHalXT = 3u;

bool build_halation_pipeline(Ctx& c, Ctx::HalationKernel& k) {
    VkShaderModuleCreateInfo smci{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};
    smci.codeSize = sizeof(kHalationScatterSpv);
    smci.pCode = kHalationScatterSpv;
    if (vkCreateShaderModule(c.device, &smci, nullptr, &k.shader) != VK_SUCCESS) return false;
    const uint32_t bindingIds[5] = {0u, 1u, 2u, 3u, 27u};
    VkDescriptorSetLayoutBinding b[5]{};
    for (uint32_t i = 0; i < 5; ++i) {
        b[i].binding = bindingIds[i];
        b[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
        b[i].descriptorCount = 1;
        b[i].stageFlags = VK_SHADER_STAGE_COMPUTE_BIT;
    }
    VkDescriptorSetLayoutCreateInfo dlci{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};
    dlci.bindingCount = 5;
    dlci.pBindings = b;
    if (vkCreateDescriptorSetLayout(c.device, &dlci, nullptr, &k.dsl) != VK_SUCCESS) return false;
    if (sizeof(HalationPush) > c.properties.limits.maxPushConstantsSize) return false;
    VkPushConstantRange pcr{VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(HalationPush)};
    VkPipelineLayoutCreateInfo plci{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};
    plci.setLayoutCount = 1;
    plci.pSetLayouts = &k.dsl;
    plci.pushConstantRangeCount = 1;
    plci.pPushConstantRanges = &pcr;
    if (vkCreatePipelineLayout(c.device, &plci, nullptr, &k.pl) != VK_SUCCESS) return false;
    VkComputePipelineCreateInfo cpci{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};
    cpci.stage.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO;
    cpci.stage.stage = VK_SHADER_STAGE_COMPUTE_BIT;
    cpci.stage.module = k.shader;
    cpci.stage.pName = "main";
    cpci.layout = k.pl;
    if (vkCreateComputePipelines(c.device, VK_NULL_HANDLE, 1, &cpci, nullptr, &k.pipe) != VK_SUCCESS) return false;
    VkDescriptorPoolSize ps{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER, 5u * kHalSetCount};
    VkDescriptorPoolCreateInfo dpci{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};
    dpci.maxSets = kHalSetCount;
    dpci.poolSizeCount = 1;
    dpci.pPoolSizes = &ps;
    if (vkCreateDescriptorPool(c.device, &dpci, nullptr, &k.dpool) != VK_SUCCESS) return false;
    std::array<VkDescriptorSetLayout, kHalSetCount> layouts{};
    layouts.fill(k.dsl);
    VkDescriptorSetAllocateInfo dsai{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};
    dsai.descriptorPool = k.dpool;
    dsai.descriptorSetCount = kHalSetCount;
    dsai.pSetLayouts = layouts.data();
    if (vkAllocateDescriptorSets(c.device, &dsai, k.dsets.data()) != VK_SUCCESS) return false;
    VkCommandPoolCreateInfo cpci2{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};
    cpci2.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    cpci2.queueFamilyIndex = c.queueFamily;
    if (vkCreateCommandPool(c.device, &cpci2, nullptr, &k.cpool) != VK_SUCCESS) return false;
    VkCommandBufferAllocateInfo cbai{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};
    cbai.commandPool = k.cpool;
    cbai.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
    cbai.commandBufferCount = 1;
    if (vkAllocateCommandBuffers(c.device, &cbai, &k.cmd) != VK_SUCCESS) return false;
    VkFenceCreateInfo fci{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};
    if (vkCreateFence(c.device, &fci, nullptr, &k.fence) != VK_SUCCESS) return false;
    k.pipelineReady = true;
    return true;
}

// Buffer roles per descriptor set: (in0, buf1, in2, buf3) over the four
// whole-frame work buffers S (source), SUM (weighted blur sum), X (X-blurred
// image, later the scattered image), XT (transposed scratch). One separable
// blur is: X pass S -> X (FIR channels per pixel; IIR channels transpose
// S -> XT, filter XT in place, transpose back XT -> X), then a Y pass
// SUM += w * blurY(X) (IIR channels use XT as the forward-sweep scratch).
//   0 X FIR S -> X          1 transpose S -> XT, IIR in place on XT
//   2 transpose XT -> X     3 Y accumulate X -> SUM (scratch XT)
//   4 clear SUM             5 resolve (S, SUM) -> X
// The bounce blurs after a scatter step read the scattered image in X and
// use S, now free, as their X-blurred buffer:
//   6 X FIR X -> S          7 transpose X -> XT, IIR in place on XT
//   8 transpose XT -> S     9 Y accumulate S -> SUM (scratch XT)
//  10 resolve (X, SUM) -> S
// Unused bindings of a set hold a buffer the op never touches.
void write_halation_sets(Ctx& c, Ctx::HalationKernel& k) {
    const VkBuffer S = k.work[kHalSrc].buf, SUM = k.work[kHalSum].buf,
                   X = k.work[kHalX].buf, XT = k.work[kHalXT].buf;
    const VkBuffer roles[kHalSetCount][4] = {
        {S, X, S, S},     {S, XT, S, S},    {XT, X, XT, XT}, {X, SUM, X, XT},
        {S, SUM, S, S},   {S, SUM, S, X},   {X, S, X, X},    {X, XT, X, X},
        {XT, S, XT, XT},  {S, SUM, S, XT},  {X, SUM, X, S},
    };
    std::array<VkDescriptorBufferInfo, kHalSetCount * 5> infos{};
    std::array<VkWriteDescriptorSet, kHalSetCount * 5> writes{};
    size_t n = 0;
    for (uint32_t s = 0; s < kHalSetCount; ++s) {
        const uint32_t bindingIds[5] = {0u, 1u, 2u, 3u, 27u};
        for (uint32_t i = 0; i < 5; ++i) {
            infos[n] = VkDescriptorBufferInfo{i < 4 ? roles[s][i] : k.frame.buf, 0, VK_WHOLE_SIZE};
            writes[n] = VkWriteDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
            writes[n].dstSet = k.dsets[s];
            writes[n].dstBinding = bindingIds[i];
            writes[n].descriptorCount = 1;
            writes[n].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
            writes[n].pBufferInfo = &infos[n];
            ++n;
        }
    }
    vkUpdateDescriptorSets(c.device, static_cast<uint32_t>(n), writes.data(), 0, nullptr);
}

bool halation_scatter_locked(Ctx& c, const HalationScatterRequest& r, double* out,
                             HalationScatterDiagnostics& d, float* out_f32 = nullptr) {
    d.attempted = true;
    if (!c.ok) { d.reason = "no-device"; return false; }
    if (r.width <= 0 || r.height <= 0 || !(r.pixel_size_um > 0.0)) {
        d.reason = "bad-request";
        return false;
    }
    // RESIDENT (#220): the source is already on the device and the result may
    // stay there, so the host planes are not required -- and must not be, or a
    // resident caller would have to keep a 300 MB f64 buffer alive for a pass
    // that never touches it. The two banded host loops below collapse to one
    // device-to-device copy each: ~50 ms of conversion and bus traffic per call
    // at 12.5 MP, and this pass runs three times per frame (halation, the DIR
    // diffusion, and every gaussian_blur_rgb caller).
    const bool resident = c.frame.open && c.frame.width == r.width &&
                          c.frame.height == r.height;
    const bool src_is_f32 = r.raw_rgb_f32 != nullptr;
    if (r.raw_rgb && r.raw_rgb_f32) { d.reason = "bad-request"; return false; }
    if (!resident && ((!r.raw_rgb && !r.raw_rgb_f32) ||
                      (!out && !out_f32) ||
                      (r.raw_rgb && out == r.raw_rgb))) {
        d.reason = "bad-request";
        return false;
    }
    const uint64_t npix64 = static_cast<uint64_t>(r.width) * static_cast<uint64_t>(r.height);
    if (npix64 > static_cast<uint64_t>(std::numeric_limits<int32_t>::max()) / 3u) {
        d.reason = "too-many-pixels";
        return false;
    }
    const double values[] = {r.scatter_amount, r.scatter_spatial_scale, r.halation_amount,
                             r.halation_spatial_scale, r.halation_bounce_decay};
    for (double v : values) if (!std::isfinite(v)) { d.reason = "bad-request"; return false; }
    for (int ch = 0; ch < 3; ++ch) {
        const double per[] = {r.scatter_core_um[ch], r.scatter_tail_um[ch], r.scatter_tail_weight[ch],
                              r.halation_strength[ch], r.halation_first_sigma_um[ch]};
        for (double v : per) if (!std::isfinite(v)) { d.reason = "bad-request"; return false; }
        // The CPU blends (1 - w) * core + w * tail with the raw weight, and a
        // weight outside [0, 1] makes that a difference of two larger numbers.
        // The f32 sum buffer cannot hold the result inside the tolerance band
        // once it does (measured 5.3e-4 on log10(raw) at w = 1.2), so the pass
        // declines rather than returning an image it cannot bound. Presets can
        // carry such a weight: the import range check covers only the
        // resource-amplifying parameters.
        if (!(r.scatter_tail_weight[ch] >= 0.0 && r.scatter_tail_weight[ch] <= 1.0)) {
            d.reason = "tail-weight-out-of-range";
            return false;
        }
    }

    // Activity by the CPU pass's own rules.
    double sigmaCore[3], lambdaTail[3], aTot[3], sigmaH[3];
    bool anyScatterSigma = false, anyA = false, anySigmaH = false;
    bool coreNeeded = false, tailNeeded = false;
    for (int ch = 0; ch < 3; ++ch) {
        sigmaCore[ch] = r.scatter_core_um[ch] * r.scatter_spatial_scale / r.pixel_size_um;
        lambdaTail[ch] = r.scatter_tail_um[ch] * r.scatter_spatial_scale / r.pixel_size_um;
        if (sigmaCore[ch] > 0.0 || lambdaTail[ch] > 0.0) anyScatterSigma = true;
        // The CPU blend is (1 - w) * core + w * tail with the RAW w
        // (model/diffusion.cpp), and w is known to be in [0, 1] here because
        // the validation above declined anything else. A blur whose weight is
        // exactly zero for all three channels contributes nothing, so it is
        // the one case worth skipping.
        if (r.scatter_tail_weight[ch] != 1.0) coreNeeded = true;
        if (r.scatter_tail_weight[ch] != 0.0) tailNeeded = true;
        aTot[ch] = r.halation_strength[ch] * r.halation_amount;
        sigmaH[ch] = r.halation_first_sigma_um[ch] * r.halation_spatial_scale / r.pixel_size_um;
        if (aTot[ch] > 0.0) anyA = true;
        if (sigmaH[ch] > 0.0) anySigmaH = true;
    }
    // Mixture mode (#213) supplies its own component set, so the scatter core /
    // tail micrometre fields are unused and cannot be what decides activation.
    // Every component is a tail slot; there is no separate core.
    if (r.mixture_count > 0) {
        anyScatterSigma = false;
        for (int i = 0; i < r.mixture_count; ++i)
            if (r.mixture_sigma_px[i] > 0.0) { anyScatterSigma = true; break; }
        coreNeeded = false;
        tailNeeded = anyScatterSigma;
    }
    const bool scatterActive = r.scatter_amount > 0.0 && anyScatterSigma;
    const int bounces = r.halation_n_bounces;
    const bool bounceActive = bounces >= 1 && anyA && anySigmaH;
    const size_t total = static_cast<size_t>(npix64) * 3u;
    if (!scatterActive && !bounceActive) {
        std::memcpy(out, r.raw_rgb, total * sizeof(double));
        d.engaged = false;
        d.reason = "nothing-to-do";
        return true;
    }
    double sigmaMax = 0.0;
    for (int ch = 0; ch < 3; ++ch) {
        if (scatterActive) {
            sigmaMax = std::max(sigmaMax, sigmaCore[ch]);
            sigmaMax = std::max(sigmaMax, lambdaTail[ch] * kHalTailRatio[2]);
        }
        if (bounceActive) {
            sigmaMax = std::max(sigmaMax, sigmaH[ch] * std::sqrt(static_cast<double>(bounces)));
        }
    }
    if (bounceActive && static_cast<uint32_t>(bounces) > kHalMaxBounces) { d.reason = "too-many-bounces"; return false; }
    if (r.mixture_count > 0) {
        if (!r.mixture_sigma_px || !r.mixture_weight) { d.reason = "invalid-request"; return false; }
        if (static_cast<uint32_t>(r.mixture_count) > kHalMaxMixture) { d.reason = "too-many-components"; return false; }
        for (int i = 0; i < r.mixture_count * 3; ++i)
            if (!std::isfinite(r.mixture_weight[i])) { d.reason = "invalid-request"; return false; }
        // MIXTURE SIGMAS MUST FEED sigmaMax. They did not, and that was a hole:
        // in mixture mode blur_sigma() returns mixture_sigma_px[component]
        // directly, so sigmaCore/lambdaTail -- the only inputs sigmaMax was built
        // from -- are unused, and the kHalMaxSigma check below was testing values
        // this request never uses. An arbitrarily large mixture sigma therefore
        // passed validation. The pass is meant to be fail-closed, so it is
        // checked on the value that actually reaches the kernel.
        for (int i = 0; i < r.mixture_count; ++i) {
            if (!std::isfinite(r.mixture_sigma_px[i])) { d.reason = "invalid-request"; return false; }
            if (r.mixture_sigma_px[i] < 0.0) { d.reason = "invalid-request"; return false; }
            sigmaMax = std::max(sigmaMax, r.mixture_sigma_px[i]);
        }
    }
    if (!(sigmaMax <= kHalMaxSigma)) { d.reason = "sigma-too-large"; return false; }

    // Whole-frame residency: four packed f32 planes, each one storage range,
    // against the fixed budget and the device's largest device-local heap.
    const uint32_t W = static_cast<uint32_t>(r.width), H = static_cast<uint32_t>(r.height);
    const VkDeviceSize frameBytes = static_cast<VkDeviceSize>(npix64) * kHalPixelBytes;
    const VkDeviceSize workBytes = frameBytes * kHalWorkBuffers;
    const VkPhysicalDeviceLimits& lim = c.properties.limits;
    const uint32_t maxDim = std::max(W, H);
    if (workBytes > kHalWorkBudgetBytes || frameBytes > lim.maxStorageBufferRange ||
        workBytes > c.largestHeapFor(VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) ||
        (maxDim + kHalLineThreads - 1u) / kHalLineThreads > lim.maxComputeWorkGroupCount[0] ||
        (maxDim + kHalTransposeTile - 1u) / kHalTransposeTile >
            std::min(lim.maxComputeWorkGroupCount[0], lim.maxComputeWorkGroupCount[1]) ||
        (W + kHalGroupX - 1u) / kHalGroupX > lim.maxComputeWorkGroupCount[0] ||
        (H + kHalGroupY - 1u) / kHalGroupY > lim.maxComputeWorkGroupCount[1]) {
        d.reason = "frame-too-large";
        return false;
    }
    // Upload/readback go through one mapped staging band of whole rows; the
    // band size never touches the numbers (a test proves it).
    const VkDeviceSize rowBytes = static_cast<VkDeviceSize>(W) * kHalPixelBytes;
    const VkDeviceSize bandCap = r.staging_bytes_override ? r.staging_bytes_override : kHalStagingBytes;
    const uint32_t bandRows = static_cast<uint32_t>(
        std::min<VkDeviceSize>(H, std::max<VkDeviceSize>(1, bandCap / rowBytes)));
    const VkDeviceSize stagingBytes = static_cast<VkDeviceSize>(bandRows) * rowBytes;

    Ctx::HalationKernel& k = c.halation;
    if (!k.pipelineReady && !build_halation_pipeline(c, k)) { d.reason = "pipeline-failed"; return false; }
    if (!c.ensureBuf(k.staging, stagingBytes)) { d.reason = "allocation-failed"; return false; }
    if (!c.ensureBuf(k.frame, kHalFrameFloatCount * sizeof(float))) { d.reason = "allocation-failed"; return false; }
    PointwiseChainDiagnostics scratchDiagnostics{};
    // GPU-private if the device has such a type: these four are written and read
    // only by the IIR/FIR sweeps, never by the host (the staging band above is
    // what the host touches). Without the avoid mask, DEVICE_LOCAL on a
    // unified-memory phone resolves to the first matching type, which is
    // normally HOST_VISIBLE|HOST_COHERENT -- see findPreferredMemType.
    for (ResidentBuf& b : k.work) {
        if (!c.ensureResidentBuf(b, frameBytes,
                                 VK_BUFFER_USAGE_STORAGE_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_SRC_BIT |
                                     VK_BUFFER_USAGE_TRANSFER_DST_BIT,
                                 0, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT, false,
                                 scratchDiagnostics,
                                 VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT)) {
            d.reason = "allocation-failed";
            return false;
        }
    }

    // Per-channel sigma in pixels of one blur, as apply_halation_um derives it
    // (model/diffusion.cpp): the scatter core, one of the three surrogate
    // Gaussians of the exponential tail, or bounce b at sigma_h * sqrt(b + 1).
    auto blur_sigma = [&](uint32_t sigmaMode, uint32_t component, uint32_t ch) {
        const double scale = sigmaMode == kHalSigmaBounce ? std::max(r.halation_spatial_scale, 0.0)
                                                          : std::max(r.scatter_spatial_scale, 0.0);
        if (sigmaMode == kHalSigmaCore) return std::max(r.scatter_core_um[ch], 0.0) * scale / r.pixel_size_um;
        if (sigmaMode == kHalSigmaTail) {
            // Mixture components arrive already in pixels: the caller resolved
            // spatial_scale and pixel_size_um when it built them, so applying them
            // again here would square the scaling.
            if (r.mixture_count > 0)
                return std::max(r.mixture_sigma_px[component], 0.0);
            return std::max(r.scatter_tail_um[ch], 0.0) * kHalTailRatio[component] * scale / r.pixel_size_um;
        }
        return std::max(r.halation_first_sigma_um[ch], 0.0) * scale *
               std::sqrt(static_cast<double>(component + 1u)) / r.pixel_size_um;
    };
    // The FIR/IIR split, in f64, exactly as gaussian_blur_plane_d dispatches it.
    // This decision is the HOST's alone: it selects which dispatches run, and
    // the shader reads it back from the table rather than recomputing it in
    // f32, where a sigma either side of 3.0 could classify the other way and
    // leave a channel of that blur unwritten.
    auto blur_is_iir = [&](uint32_t sigmaMode, uint32_t component, uint32_t ch) {
        return blur_sigma(sigmaMode, component, ch) >= kHalSmallSigmaMax;
    };
    auto iir_mask = [&](uint32_t sigmaMode, uint32_t component) {
        uint32_t mask = 0;
        for (uint32_t ch = 0; ch < 3; ++ch) if (blur_is_iir(sigmaMode, component, ch)) mask |= 1u << ch;
        return mask;
    };

    // FrameFloats: the engine's HalationParams and the blur table, as the
    // shader expects them. Everything the shader needs about a blur -- sigma,
    // class, accumulation weight, Young-van Vliet coefficients -- is computed
    // here in f64 and rounded once; the shader derives nothing.
    {
        float* f = static_cast<float*>(k.frame.mapped);
        std::memset(f, 0, kHalFrameFloatCount * sizeof(float));
        f[kHalFramePixelSizeUm] = static_cast<float>(r.pixel_size_um);
        f[kHalFrameScatterAmount] = static_cast<float>(r.scatter_amount);
        f[kHalFrameScatterScale] = static_cast<float>(r.scatter_spatial_scale);
        f[kHalFrameHalationAmount] = static_cast<float>(r.halation_amount);
        f[kHalFrameHalationScale] = static_cast<float>(r.halation_spatial_scale);
        f[kHalFrameRenormalize] = r.halation_renormalize ? 1.0f : 0.0f;
        for (uint32_t ch = 0; ch < 3; ++ch) {
            f[kHalFrameStrength + ch] = static_cast<float>(r.halation_strength[ch]);
            f[kHalFrameFirstSigma + ch] = static_cast<float>(r.halation_first_sigma_um[ch]);
            f[kHalFrameCoreUm + ch] = static_cast<float>(r.scatter_core_um[ch]);
            f[kHalFrameTailUm + ch] = static_cast<float>(r.scatter_tail_um[ch]);
            f[kHalFrameTailWeight + ch] = static_cast<float>(r.scatter_tail_weight[ch]);
        }
        // A coefficient reaches the shader as a double-float pair: the f64
        // value and the residual of its own rounding. Rounding the poles to
        // f32 alone is NOT enough -- they sit ~1/q from the unit circle, so a
        // relative perturbation of 1e-7 in a coefficient moves the pole by
        // ~q^3 in relative terms and changes the filter's shape (measured
        // against the f64 CPU filter on a unit step: 2.5e-3 at sigma 63 px,
        // 0.20 at the 256 px cap), even though the DC gain can be pinned.
        auto put_df = [&](float* dst, double v) {
            const float hi = static_cast<float>(v);
            dst[0] = hi;
            dst[1] = static_cast<float>(v - static_cast<double>(hi));
        };
        auto fill = [&](uint32_t slot, uint32_t sigmaMode, uint32_t component) {
            for (uint32_t ch = 0; ch < 3; ++ch) {
                const double sigma = blur_sigma(sigmaMode, component, ch);
                const bool isIir = blur_is_iir(sigmaMode, component, ch);
                double weight = 0.0;
                if (sigmaMode == kHalSigmaCore) {
                    // In mixture mode there is no separate core: the whole PSF is
                    // the component set, which already sums to one.
                    weight = r.mixture_count > 0 ? 0.0 : 1.0 - r.scatter_tail_weight[ch];
                } else if (sigmaMode == kHalSigmaTail) {
                    // Mixture weights are per component per channel and already
                    // carry the group weight and the halo warmth tint.
                    weight = r.mixture_count > 0
                                 ? r.mixture_weight[component * 3u + ch]
                                 : r.scatter_tail_weight[ch] * kHalTailAmplitude[component];
                } else {
                    // pow(decay, b) / sum_b pow(decay, b), with the CPU's
                    // std::pow(0, 0) == 1 for a zero decay (which the UI
                    // allows); GLSL's pow(0, 0) is undefined, so this weight is
                    // never computed on the device.
                    double norm = 0.0;
                    for (int b = 0; b < std::max(bounces, 1); ++b) norm += std::pow(r.halation_bounce_decay, static_cast<double>(b));
                    weight = std::pow(r.halation_bounce_decay, static_cast<double>(component)) / std::max(norm, 1e-12);
                }
                float* dst = f + kHalFrameBlurBase + (slot * 3u + ch) * kHalBlurStride;
                dst[kHalBlurFieldSigma] = static_cast<float>(sigma);
                dst[kHalBlurFieldIsIir] = isIir ? 1.0f : 0.0f;
                dst[kHalBlurFieldWeight] = static_cast<float>(weight);
                if (!isIir) {
                    // gaussian_kernel_1d: radius = int(3 * sigma + 0.5) on the
                    // f64 sigma. Derived on the device from the f32 sigma it
                    // gains a tap pair wherever rounding crosses an integer.
                    const double capped = std::max(sigma, 1e-6);  // max_eps, as the CPU callers apply it
                    const double radius = std::floor(3.0 * capped + 0.5);
                    dst[kHalBlurFieldFirRadius] =
                        static_cast<float>(std::min(radius, static_cast<double>(kHalMaxFirRadius)));
                    continue;
                }
                // yvv_coeffs (kernels/exponential_filter.cpp), verbatim in f64.
                const double q = sigma >= 2.5 ? 0.98711 * sigma - 0.96330
                                              : 3.97156 - 4.14554 * std::sqrt(1.0 - 0.26891 * sigma);
                const double q2 = q * q, q3 = q2 * q;
                const double b0 = 1.57825 + 2.44413 * q + 1.4281 * q2 + 0.422205 * q3;
                const double b1 = 2.44413 * q + 2.85619 * q2 + 1.26661 * q3;
                const double b2 = -(1.4281 * q2 + 1.26661 * q3);
                const double b3 = 0.422205 * q3;
                put_df(dst + kHalBlurFieldB, 1.0 - (b1 + b2 + b3) / b0);
                put_df(dst + kHalBlurFieldP1, b1 / b0);
                put_df(dst + kHalBlurFieldP2, b2 / b0);
                put_df(dst + kHalBlurFieldP3, b3 / b0);
            }
        };
        if (scatterActive) {
            fill(0u, kHalSigmaCore, 0u);
            const uint32_t tailComps =
                r.mixture_count > 0 ? static_cast<uint32_t>(r.mixture_count) : 3u;
            for (uint32_t comp = 0; comp < tailComps; ++comp) fill(1u + comp, kHalSigmaTail, comp);
        }
        if (bounceActive) {
            for (uint32_t b = 0; b < static_cast<uint32_t>(bounces); ++b) fill(4u + b, kHalSigmaBounce, b);
        }
    }
    write_halation_sets(c, k);
    HalationPush push{};
    push.fullWidth = W;
    push.fullHeight = H;
    uint32_t dispatches = 0, bands = 0;
    auto barrier = [&](VkPipelineStageFlags srcStage, VkAccessFlags srcAccess,
                       VkPipelineStageFlags dstStage, VkAccessFlags dstAccess) {
        VkMemoryBarrier mb{VK_STRUCTURE_TYPE_MEMORY_BARRIER};
        mb.srcAccessMask = srcAccess;
        mb.dstAccessMask = dstAccess;
        vkCmdPipelineBarrier(k.cmd, srcStage, dstStage, 0, 1, &mb, 0, nullptr, 0, nullptr);
    };
    auto begin = [&]() {
        if (vkResetCommandBuffer(k.cmd, 0) != VK_SUCCESS) return false;
        VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
        bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        if (vkBeginCommandBuffer(k.cmd, &bi) != VK_SUCCESS) return false;
        // Everything an earlier submission wrote (uploads, dispatches) is made
        // visible to this one.
        barrier(VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_ACCESS_MEMORY_WRITE_BIT,
                VK_PIPELINE_STAGE_ALL_COMMANDS_BIT, VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT);
        return true;
    };
    auto submit_wait = [&]() {
        if (vkEndCommandBuffer(k.cmd) != VK_SUCCESS) return false;
        VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
        si.commandBufferCount = 1;
        si.pCommandBuffers = &k.cmd;
        if (vkQueueSubmit(c.queue, 1, &si, k.fence) != VK_SUCCESS) return false;
        if (!c.waitFence(k.fence)) return false;
        stage_timing_note_gpu_submissions(1);
        return vkResetFences(c.device, 1, &k.fence) == VK_SUCCESS;
    };
    // `width`/`height` are the dims of the image the op walks: the frame, or
    // the transposed frame for the IIR column pass of an X blur.
    auto dispatch = [&](uint32_t set, uint32_t op, uint32_t sigmaMode, uint32_t component,
                        uint32_t width, uint32_t height) {
        push.operation = op;
        push.sigmaMode = sigmaMode;
        push.component = component;
        push.width = width;
        push.height = height;
        vkCmdBindPipeline(k.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, k.pipe);
        vkCmdBindDescriptorSets(k.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, k.pl, 0, 1, &k.dsets[set], 0, nullptr);
        vkCmdPushConstants(k.cmd, k.pl, VK_SHADER_STAGE_COMPUTE_BIT, 0, sizeof(HalationPush), &push);
        if (op == kHalOpLineInPlace || op == kHalOpLineYAccumulate) {
            vkCmdDispatch(k.cmd, (width + kHalLineThreads - 1u) / kHalLineThreads, 1, 1);
        } else if (op == kHalOpTranspose) {
            vkCmdDispatch(k.cmd, (width + kHalTransposeTile - 1u) / kHalTransposeTile,
                          (height + kHalTransposeTile - 1u) / kHalTransposeTile, 1);
        } else {
            vkCmdDispatch(k.cmd, (width + kHalGroupX - 1u) / kHalGroupX, (height + kHalGroupY - 1u) / kHalGroupY, 1);
        }
        barrier(VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_ACCESS_SHADER_WRITE_BIT,
                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_ACCESS_SHADER_READ_BIT | VK_ACCESS_SHADER_WRITE_BIT);
        ++dispatches;
    };
    // One separable blur into SUM. `fromScattered` selects the bounce sets
    // that read the scattered image in X and use S as scratch.
    auto blur = [&](uint32_t sigmaMode, uint32_t component, bool fromScattered) {
        const uint32_t xFir = fromScattered ? 6u : 0u, tFwd = fromScattered ? 7u : 1u,
                       tBack = fromScattered ? 8u : 2u, yAcc = fromScattered ? 9u : 3u;
        const uint32_t iirMask = iir_mask(sigmaMode, component);
        const bool anyFir = iirMask != 7u;
        const bool anyIir = iirMask != 0u;
        if (anyFir) dispatch(xFir, kHalOpFirX, sigmaMode, component, W, H);
        if (anyIir) {
            dispatch(tFwd, kHalOpTranspose, sigmaMode, 0, W, H);            // source -> XT
            dispatch(tFwd, kHalOpLineInPlace, sigmaMode, component, H, W);  // columns of the transposed
            dispatch(tBack, kHalOpTranspose, sigmaMode, iirMask, H, W);     // XT -> x-blurred, IIR channels
        }
        if (anyFir) dispatch(yAcc, kHalOpFirYAccumulate, sigmaMode, component, W, H);
        if (anyIir) dispatch(yAcc, kHalOpLineYAccumulate, sigmaMode, component, W, H);
    };

    // Upload: rows [y0, y1) as packed f32 (the engine's deterministic parallel
    // chunks, disjoint writes), one copy per band -- unless the frame is
    // resident, in which case the plane is already device-side in the right
    // format and one copy replaces the whole loop.
    if (resident) {
        const auto t0 = std::chrono::steady_clock::now();
        if (!begin()) { d.reason = "dispatch-failed"; return false; }
        barrier(VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_ACCESS_SHADER_WRITE_BIT,
                VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_READ_BIT);
        VkBufferCopy whole{0, 0, frameBytes};
        vkCmdCopyBuffer(k.cmd, c.frame.plane[c.frame.front].buf,
                        k.work[kHalSrc].buf, 1, &whole);
        if (!submit_wait()) { d.reason = "dispatch-failed"; return false; }
        ++bands;
        d.upload_ms += std::chrono::duration<double, std::milli>(
                           std::chrono::steady_clock::now() - t0).count();
    } else {
        const auto t0 = std::chrono::steady_clock::now();
        for (uint32_t y0 = 0; y0 < H; y0 += bandRows) {
            const uint32_t rows = std::min(bandRows, H - y0);
            const size_t n = static_cast<size_t>(rows) * W * 3u;
            float* dst = static_cast<float*>(k.staging.mapped);
            if (src_is_f32) {
                std::memcpy(dst, r.raw_rgb_f32 + static_cast<size_t>(y0) * W * 3u,
                            n * sizeof(float));
            } else {
                const double* src = r.raw_rgb + static_cast<size_t>(y0) * W * 3u;
                parallel_for(0, static_cast<int>(n), [&](int lo, int hi) {
                    for (int i = lo; i < hi; ++i) dst[i] = static_cast<float>(src[i]);
                });
            }
            if (!begin()) { d.reason = "dispatch-failed"; return false; }
            barrier(VK_PIPELINE_STAGE_HOST_BIT, VK_ACCESS_HOST_WRITE_BIT,
                    VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_READ_BIT);
            VkBufferCopy upload{0, static_cast<VkDeviceSize>(y0) * rowBytes, static_cast<VkDeviceSize>(rows) * rowBytes};
            vkCmdCopyBuffer(k.cmd, k.staging.buf, k.work[kHalSrc].buf, 1, &upload);
            if (!submit_wait()) { d.reason = "dispatch-failed"; return false; }
            ++bands;
        }
        d.upload_ms += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    }

    // The whole pass, one submission.
    const auto gpuStart = std::chrono::steady_clock::now();
    if (!begin()) { d.reason = "dispatch-failed"; return false; }
    if (scatterActive) {
        dispatch(4, kHalOpClear, 0, 0, W, H);
        if (coreNeeded) blur(kHalSigmaCore, 0, false);
        if (tailNeeded) {
            const uint32_t tailComps =
                r.mixture_count > 0 ? static_cast<uint32_t>(r.mixture_count) : 3u;
            for (uint32_t comp = 0; comp < tailComps; ++comp) blur(kHalSigmaTail, comp, false);
        }
        dispatch(5, kHalOpScatterResolve, 0, 0, W, H);  // scattered -> X
    }
    if (bounceActive) {
        dispatch(4, kHalOpClear, 0, 0, W, H);
        for (uint32_t b = 0; b < static_cast<uint32_t>(bounces); ++b) blur(kHalSigmaBounce, b, scatterActive);
        dispatch(scatterActive ? 10u : 5u, kHalOpBounceResolveRaw, 0, 0, W, H);
    }
    const VkBuffer result = (scatterActive && bounceActive) ? k.work[kHalSrc].buf : k.work[kHalX].buf;
    if (!submit_wait()) { d.reason = "dispatch-failed"; return false; }
    d.gpu_ms += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - gpuStart).count();

    // Readback: rows [y0, y1) into the caller's f64 plane, one copy per band --
    // or, resident, straight into the other half of the ping-pong, and the
    // caller's f64 plane is never written because nobody is going to read it.
    if (resident) {
        const auto t0 = std::chrono::steady_clock::now();
        if (!begin()) { d.reason = "dispatch-failed"; return false; }
        barrier(VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_ACCESS_SHADER_WRITE_BIT,
                VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_READ_BIT);
        VkBufferCopy whole{0, 0, frameBytes};
        vkCmdCopyBuffer(k.cmd, result, c.frame.plane[c.frame.front ^ 1u].buf, 1, &whole);
        if (!submit_wait()) { d.reason = "dispatch-failed"; return false; }
        c.frame.front ^= 1u;
        d.readback_ms += std::chrono::duration<double, std::milli>(
                             std::chrono::steady_clock::now() - t0).count();
    } else {
        const auto t0 = std::chrono::steady_clock::now();
        for (uint32_t y0 = 0; y0 < H; y0 += bandRows) {
            const uint32_t rows = std::min(bandRows, H - y0);
            if (!begin()) { d.reason = "dispatch-failed"; return false; }
            barrier(VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_ACCESS_SHADER_WRITE_BIT,
                    VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_READ_BIT);
            VkBufferCopy readback{static_cast<VkDeviceSize>(y0) * rowBytes, 0, static_cast<VkDeviceSize>(rows) * rowBytes};
            vkCmdCopyBuffer(k.cmd, result, k.staging.buf, 1, &readback);
            barrier(VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_WRITE_BIT,
                    VK_PIPELINE_STAGE_HOST_BIT, VK_ACCESS_HOST_READ_BIT);
            if (!submit_wait()) { d.reason = "dispatch-failed"; return false; }
            const float* srcf = static_cast<const float*>(k.staging.mapped);
            const size_t n = static_cast<size_t>(rows) * W * 3u;
            if (out_f32) {
                std::memcpy(out_f32 + static_cast<size_t>(y0) * W * 3u, srcf,
                            n * sizeof(float));
            } else {
                double* dst = out + static_cast<size_t>(y0) * W * 3u;
                parallel_for(0, static_cast<int>(n), [&](int lo, int hi) {
                    for (int i = lo; i < hi; ++i) dst[i] = static_cast<double>(srcf[i]);
                });
            }
        }
        d.readback_ms += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    }
    d.engaged = true;
    d.reason = "none";
    d.bands = bands;
    d.dispatches = dispatches;
    d.resident = resident;
    return true;
}

}  // namespace

bool halation_scatter(const HalationScatterRequest& request, double* out_rgb,
                      HalationScatterDiagnostics* diagnostics) noexcept {
    HalationScatterDiagnostics local{};
    HalationScatterDiagnostics& d = diagnostics ? *diagnostics : local;
    d = {};
    bool ok = false;
    try {
        std::lock_guard<std::mutex> lk(gpu_mutex());
        Ctx& c = ctx();
        ok = halation_scatter_locked(c, request, out_rgb, d);
        // A refusal decided before any Vulkan call (bad request, sigma or slice
        // geometry) leaves the kernel state valid and warm; only a failure of the
        // device path itself tears it down so the next call rebuilds from scratch.
        if (!ok && (std::strcmp(d.reason, "pipeline-failed") == 0 ||
                    std::strcmp(d.reason, "allocation-failed") == 0 ||
                    std::strcmp(d.reason, "dispatch-failed") == 0)) {
            c.destroyHalation();
        }
    } catch (...) {
        d.reason = "exception";
        ok = false;
        try {
            std::lock_guard<std::mutex> lk(gpu_mutex());
            ctx().destroyHalation();
        } catch (...) {
        }
    }
    return ok;
}

// Per-channel Gaussian blur, expressed on the halation kernel's mixture mode.
// See the header for why this needs no shader of its own.
namespace {

// Shared by both blur entry points: everything except which plane type it moves.
//
// IIR-CLASS SIGMAS GO BACK TO THE CPU, on measurement rather than taste. Above
// sigma 3 the CPU switches to Young-van Vliet, which is O(1) in sigma; this pass
// pays whole-frame residency and a transpose whatever the sigma is. On device
// (Adreno 840, tools/gpu_probe/probe_spatial_main.cpp):
//
//   sigma 0.70 (FIR)  1080p  50.7 -> 34.7 ms  1.46x   12.5MP 285.1 -> 179.8 ms  1.59x
//   sigma 3.50 (IIR)  1080p  46.5 -> 51.2 ms  0.91x   12.5MP 161.4 -> 261.5 ms  0.62x
//
// So the GPU lost outright at 12.5 MP for a wide blur, and the CPU IIR was even
// faster there than its own FIR at sigma 0.7. The threshold is the same
// kSmallSigmaMax the CPU dispatches on, which is not a coincidence: it is
// exactly where the CPU stops paying for radius.
//
// THAT MEASUREMENT PREDATES THE WORK BUFFERS BECOMING GPU-PRIVATE. It was taken
// while halation's four whole-frame scratch buffers came from the first
// DEVICE_LOCAL memory type, which on a unified-memory phone is normally
// HOST_VISIBLE|HOST_COHERENT -- so the pass was paying host-coherent bandwidth
// for every sweep, which is exactly what a wide IIR blur is made of.
// SPK_GPU_BLUR_IIR=1 lifts the gate so the two can be compared in one binary
// rather than argued about.
//
// ONE COMPONENT PER DISTINCT SIGMA. The mixture carries one sigma per component
// and a weight per component per channel, so equal sigmas collapse to a single
// blur while unequal ones become three disjoint ones -- channel c takes
// component c with weight 1 and the others with weight 0.
bool build_blur_request(int width, int height, const double sigma_px[3],
                        double sigma_out[3], double weight_out[9], int* ncomp_out) {
    if (!sigma_px || width <= 0 || height <= 0) return false;
    for (int c = 0; c < 3; ++c)
        if (!std::isfinite(sigma_px[c]) || sigma_px[c] <= 0.0) return false;
    // CLOSED BY DEFAULT, and this time on a PAIRED, COOLED, INTERLEAVED
    // measurement rather than a single capture. I opened it on the reasoning
    // that the original numbers were taken while halation's work buffers were
    // host-coherent -- true, and it demonstrably mattered elsewhere (halation
    // 256.6 -> 72.3 ms, and the FFT) -- but it did not change THIS conclusion.
    // At 12.5 MP, two interleaved pairs:
    //
    //   lens_blur    sigma 3.03 (IIR)   GPU 291.9 / 252.5   CPU 148.1 / 146.6
    //   scan_spatial FIR                GPU 322.8 / 326.1   CPU 350.7 / 340.7
    //
    // i.e. the GPU loses 1.8x on the IIR side and wins ~1.05x on the FIR side,
    // and the split falls exactly on this threshold. The CPU's Young-van Vliet
    // is O(1) in sigma while this pass pays whole-frame residency and a
    // transpose whatever the sigma is; no memory fix changes that shape.
    //
    // SPK_GPU_BLUR_IIR=1 opens it, for measuring rather than for shipping.
    // Correctness is not the reason it is closed: a sigma-18 IIR blur matches
    // the CPU filter to 8.3e-07.
    double iir_gate = 3.0;
    if (const char* v = std::getenv("SPK_GPU_BLUR_IIR"))
        if (v[0] == '1') iir_gate = std::numeric_limits<double>::infinity();
    for (int c = 0; c < 3; ++c)
        if (sigma_px[c] >= iir_gate) return false;
    const bool uniform = (sigma_px[0] == sigma_px[1]) && (sigma_px[1] == sigma_px[2]);
    for (int i = 0; i < 9; ++i) weight_out[i] = 0.0;
    if (uniform) {
        sigma_out[0] = sigma_px[0];
        weight_out[0] = weight_out[1] = weight_out[2] = 1.0;
        *ncomp_out = 1;
    } else {
        for (int c = 0; c < 3; ++c) {
            sigma_out[c] = sigma_px[c];
            weight_out[c * 3 + c] = 1.0;
        }
        *ncomp_out = 3;
    }
    return true;
}

}  // namespace

bool gaussian_blur_rgb_f32(float* rgb, int width, int height,
                           const double sigma_px[3]) {
    if (!rgb) return false;
    double sigma[3] = {0.0, 0.0, 0.0};
    double weight[9];
    int ncomp = 0;
    if (!build_blur_request(width, height, sigma_px, sigma, weight, &ncomp))
        return false;

    HalationScatterRequest request{};
    request.raw_rgb_f32 = rgb;
    request.width = width;
    request.height = height;
    request.pixel_size_um = 1.0;
    request.scatter_spatial_scale = 1.0;
    request.scatter_amount = 1.0;
    request.mixture_sigma_px = sigma;
    request.mixture_weight = weight;
    request.mixture_count = ncomp;
    request.halation_amount = 0.0;
    request.halation_n_bounces = 0;

    // No f64 scratch at all: the pass reads the caller's float plane and writes
    // a float plane back. That is the whole point of this entry point -- the
    // f64 one allocates a whole-frame double buffer here (300 MB at 12.5 MP)
    // purely to hold a result it immediately converts.
    std::vector<float> out;
    try {
        out.resize(static_cast<size_t>(width) * height * 3u);
    } catch (const std::bad_alloc&) {
        return false;
    }
    HalationScatterDiagnostics diagnostics{};
    bool ok = false;
    try {
        std::lock_guard<std::mutex> lk(gpu_mutex());
        Ctx& c = ctx();
        ok = halation_scatter_locked(c, request, nullptr, diagnostics, out.data());
        if (!ok && (std::strcmp(diagnostics.reason, "pipeline-failed") == 0 ||
                    std::strcmp(diagnostics.reason, "allocation-failed") == 0 ||
                    std::strcmp(diagnostics.reason, "dispatch-failed") == 0)) {
            c.destroyHalation();
        }
    } catch (...) {
        return false;
    }
    if (!ok || !diagnostics.engaged) return false;
    std::memcpy(rgb, out.data(), out.size() * sizeof(float));
    return true;
}

bool gaussian_blur_rgb(double* rgb, int width, int height,
                       const double sigma_px[3]) {
    if (!rgb) return false;
    double sigma[3] = {0.0, 0.0, 0.0};
    double weight[9];
    int ncomp = 0;
    if (!build_blur_request(width, height, sigma_px, sigma, weight, &ncomp))
        return false;

    HalationScatterRequest request{};
    request.raw_rgb = rgb;
    request.width = width;
    request.height = height;
    // Sigmas are already in pixels, so the pass must not scale them again.
    request.pixel_size_um = 1.0;
    request.scatter_spatial_scale = 1.0;
    // amount 1 turns the resolve (1 - amount) * src + amount * blurred into a
    // plain blur; halation is a separate stage and must not run here.
    request.scatter_amount = 1.0;
    request.mixture_sigma_px = sigma;
    request.mixture_weight = weight;
    request.mixture_count = ncomp;
    request.halation_amount = 0.0;
    request.halation_n_bounces = 0;

    const size_t total = static_cast<size_t>(width) * static_cast<size_t>(height) * 3u;
    std::vector<double> out;
    try {
        out.resize(total);
    } catch (const std::bad_alloc&) {
        return false;
    }
    HalationScatterDiagnostics diagnostics{};
    const bool ok = halation_scatter(request, out.data(), &diagnostics);
    if (!ok || !diagnostics.engaged) return false;
    parallel_for(0, static_cast<int>(total), [&](int lo, int hi) {
        for (int i = lo; i < hi; ++i) rgb[i] = out[i];
    });
    return true;
}

// --- Viewing-glare field (#215) ---------------------------------------------
// One dispatch: lognormal field, its blur, the /100 and the add into XYZ. See
// gpu/glare.comp for why the blur needs no scratch plane.
namespace {

struct GlarePush {
    uint32_t npix;
    uint32_t groups_x;
    uint32_t width;
    uint32_t height;
    uint32_t radius;
    uint32_t seed;
    float mu;
    float sigma;
    float scale;
};

}  // namespace

bool glare_field(float* field, int width, int height, const GlareRequest& request,
                 GlareDiagnostics* diagnostics) {
    GlareDiagnostics d{};
    d.attempted = true;
    auto give_up = [&](const char* reason) {
        d.reason = reason;
        if (diagnostics) *diagnostics = d;
        return false;
    };

    if (!field || width <= 0 || height <= 0) return give_up("empty-frame");
    if (!std::isfinite(request.amount) || !std::isfinite(request.roughness) ||
        !std::isfinite(request.blur_px))
        return give_up("invalid-request");
    if (!(request.amount > 0.0)) return give_up("inactive");

    // mu and sigma exactly as model/glare.cpp derives them, in f64, once.
    const double m = request.amount;
    // `sd` not `s`: the kernel reference below is also called s, and the two
    // shadow each other in a way the no-Vulkan build cannot see (it compiles the
    // stub instead of this function).
    const double sd = request.roughness * request.amount;
    double mu = 0.0, sigma = 0.0;
    if (m > 0.0) {
        const double sigma2 = std::log(1.0 + (sd * sd) / (m * m));
        sigma = std::sqrt(sigma2);
        mu = std::log(m) - sigma2 / 2.0;
    }
    if (!std::isfinite(mu) || !std::isfinite(sigma)) return give_up("invalid-request");

    // The blur reduction, matching kernels/gaussian.cpp. A recompute loop cannot
    // express an IIR recursion, so sigma at or above the CPU's FIR/IIR switch is
    // refused outright rather than silently answered with a FIR.
    const float blur = static_cast<float>(request.blur_px);
    if (blur >= 3.0f) return give_up("blur-is-iir-class");
    int radius = 0;
    float taps[2 * kGlareMaxBlurRadius + 1] = {0.0f};
    if (blur > 0.0f) {
        radius = static_cast<int>(3.0f * blur + 0.5f);
        if (radius < 0) radius = 0;
        if (radius > kGlareMaxBlurRadius) return give_up("blur-too-wide");
        if (radius > 0) {
            const int size = 2 * radius + 1;
            double total = 0.0;
            for (int i = 0; i < size; ++i) {
                const double x = static_cast<double>(i - radius);
                const double val = std::exp(-0.5 * (x / blur) * (x / blur));
                taps[i] = static_cast<float>(val);
                total += val;
            }
            if (total != 0.0)
                for (int i = 0; i < size; ++i)
                    taps[i] = static_cast<float>(taps[i] / total);
        }
    }
    d.blur_radius = static_cast<uint32_t>(radius);
    if (radius > 0 &&
        (width < 2 * radius + 1 || height < 2 * radius + 1))
        return give_up("frame-smaller-than-kernel");

    const uint32_t npix = static_cast<uint32_t>(width) * static_cast<uint32_t>(height);

    std::lock_guard<std::mutex> lk(gpu_mutex());
    Ctx& c = ctx();
    if (!c.ok) return give_up("gpu-unavailable");
    const VkPhysicalDeviceLimits& limits = c.properties.limits;
    Ctx::Kernel& s = c.glareK;

    const PointwiseDispatchGrid grid =
        plan_pointwise_dispatch(npix, limits.maxComputeWorkGroupCount[0],
                                limits.maxComputeWorkGroupCount[1]);
    if (!grid.valid) return give_up("dispatch-too-large");

    // One plane out, not three: this pass produces the field, and the
    // `xyz += field * illuminant` half stays fused in scanning.cpp's f64 loop.
    const VkDeviceSize frameBytes = static_cast<VkDeviceSize>(npix) * sizeof(float);
    const VkDeviceSize tapBytes =
        static_cast<VkDeviceSize>(2 * kGlareMaxBlurRadius + 1) * sizeof(float);
    if (frameBytes > limits.maxStorageBufferRange) return give_up("buffer-too-large");

    bool ok = false;
    do {
        if (!s.pipelineReady &&
            !build_scan_pipeline(c, s, kGlareSpv, sizeof(kGlareSpv)))
            break;
        const bool hadIn = s.in.cap >= 16 && s.in.buf;
        const bool hadOut = s.out.cap >= frameBytes && s.out.buf;
        if (!c.ensureBuf(s.in, 16)) break;   // binding 0 is unused by this shader
        if (!c.ensureBuf(s.out, frameBytes)) break;
        if (!c.ensureBuf(s.dyeB, tapBytes)) break;
        if (!c.ensureBuf(s.cmfB, 16)) break;   // unused; the layout wants 4 bindings
        if (!hadIn || !hadOut) {
            VkBuffer bufs[4] = {s.in.buf, s.out.buf, s.dyeB.buf, s.cmfB.buf};
            VkDeviceSize caps[4] = {s.in.cap, s.out.cap, s.dyeB.cap, s.cmfB.cap};
            VkDescriptorBufferInfo dbi[4];
            VkWriteDescriptorSet wds[4];
            for (uint32_t i = 0; i < 4; ++i) {
                dbi[i] = VkDescriptorBufferInfo{bufs[i], 0, caps[i]};
                wds[i] = VkWriteDescriptorSet{VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};
                wds[i].dstSet = s.dset;
                wds[i].dstBinding = i;
                wds[i].descriptorCount = 1;
                wds[i].descriptorType = VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;
                wds[i].pBufferInfo = &dbi[i];
            }
            vkUpdateDescriptorSets(c.device, 4, wds, 0, nullptr);
        }
        std::memcpy(s.dyeB.mapped, taps, static_cast<size_t>(tapBytes));

        // Nothing to upload: the field is generated from its seed, so this pass
        // reads no image at all. That also means it moves npix floats instead of
        // 4*npix, which is most of why it is cheap.
        const size_t ncomp = static_cast<size_t>(npix);

        GlarePush push{};
        push.npix = npix;
        push.groups_x = grid.groups_x;
        push.width = static_cast<uint32_t>(width);
        push.height = static_cast<uint32_t>(height);
        push.radius = static_cast<uint32_t>(radius);
        push.seed = request.seed;
        push.mu = static_cast<float>(mu);
        push.sigma = static_cast<float>(sigma);
        push.scale = 0.01f;   // glare.py: random /= 100

        const auto t_gpu = std::chrono::steady_clock::now();
        bool dispatch_ok = true;
        do {
            if (vkResetCommandBuffer(s.cmd, 0) != VK_SUCCESS) { dispatch_ok = false; break; }
            VkCommandBufferBeginInfo bi{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};
            bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
            if (vkBeginCommandBuffer(s.cmd, &bi) != VK_SUCCESS) { dispatch_ok = false; break; }
            vkCmdBindPipeline(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pipe);
            vkCmdBindDescriptorSets(s.cmd, VK_PIPELINE_BIND_POINT_COMPUTE, s.pl, 0, 1,
                                    &s.dset, 0, nullptr);
            vkCmdPushConstants(s.cmd, s.pl, VK_SHADER_STAGE_COMPUTE_BIT, 0,
                               sizeof(GlarePush), &push);
            vkCmdDispatch(s.cmd, grid.groups_x, grid.groups_y, 1);
            if (vkEndCommandBuffer(s.cmd) != VK_SUCCESS) { dispatch_ok = false; break; }
            VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};
            si.commandBufferCount = 1;
            si.pCommandBuffers = &s.cmd;
            if (vkQueueSubmit(c.queue, 1, &si, s.fence) != VK_SUCCESS) { dispatch_ok = false; break; }
            if (!c.waitFence(s.fence)) { dispatch_ok = false; break; }
            if (vkResetFences(c.device, 1, &s.fence) != VK_SUCCESS) { dispatch_ok = false; break; }
        } while (false);
        d.gpu_ms = std::chrono::duration<double, std::milli>(
                       std::chrono::steady_clock::now() - t_gpu).count();
        if (!dispatch_ok) break;

        const auto t_back = std::chrono::steady_clock::now();
        {
            const float* outp = static_cast<const float*>(s.out.mapped);
            parallel_for(0, static_cast<int>(ncomp), [&](int lo, int hi) {
                std::memcpy(field + lo, outp + lo,
                            static_cast<size_t>(hi - lo) * sizeof(float));
            });
        }
        d.readback_ms = std::chrono::duration<double, std::milli>(
                            std::chrono::steady_clock::now() - t_back).count();
        ok = true;
    } while (false);

    if (!ok) {
        if (!c.last_wait_cancelled) c.destroyScan();
        return give_up("dispatch-failed");
    }
    d.engaged = true;
    d.reason = "";
    if (diagnostics) *diagnostics = d;
    return true;
}

}  // namespace spk::gpu

#endif  // SPK_ENABLE_VULKAN
