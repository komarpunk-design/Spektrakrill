/*
 * Spektrafilm for Android — native engine: density characteristic curves.
 * Copyright (C) 2026 Spektrafilm Android contributors.
 *
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later
 * version. See <https://www.gnu.org/licenses/>.
 *
 * Port of spektrafilm (GPLv3) by Andrea Volpato — film modeling powered by
 * spektrafilm. Ports spektrafilm/model/density_curves.py and the curve
 * normalisation in spektrafilm/model/emulsion.py::develop.
 */
#include "density_curves.h"

#include <cmath>
#include <vector>

#include "../kernels/interp.h"
#include "../kernels/parallel.h"

namespace spk {

void interpolate_exposure_to_density(const float* log_exposure_rgb, int npix,
                                     const float* density_curves,
                                     const float* log_exposure, int n,
                                     const float gamma_factor[3],
                                     float* density_cmy_out) {
    // density_curves.py::interpolate_exposure_to_density
    //   density_cmy = fast_interp(log_exposure_rgb,
    //                             log_exposure[:,None]/gamma_factor[None,:],
    //                             density_curves)
    // Build the channel-specific axis xp (n,3): xp[k,c] = log_exposure[k]/gamma[c].
    std::vector<float> xp(static_cast<size_t>(n) * 3);
    for (int k = 0; k < n; ++k) {
        for (int c = 0; c < 3; ++c) {
            float g = gamma_factor[c];
            xp[k * 3 + c] = (g != 0.0f) ? (log_exposure[k] / g) : log_exposure[k];
        }
    }
    // fp is density_curves (n,3); channel-specific axis -> common_axis = false.
    // Chunked through the deterministic parallel_for (pixels are independent and
    // the kernel runs serially inside each chunk), so the output is byte-identical
    // to the plain serial call for any thread count.
    parallel_for(0, npix, [&](int lo, int hi) {
        interp1d_planar3(log_exposure_rgb + static_cast<size_t>(lo) * 3, hi - lo,
                         xp.data(), /*common_axis=*/false, density_curves, n,
                         density_cmy_out + static_cast<size_t>(lo) * 3);
    });
}

void interpolate_exposure_to_density(const float* log_exposure_rgb, int npix,
                                     const float* density_curves,
                                     const float* log_exposure, int n,
                                     float gamma_factor,
                                     float* density_cmy_out) {
    // np.size(gamma_factor)==1 -> broadcast to [g,g,g].
    const float g3[3] = {gamma_factor, gamma_factor, gamma_factor};
    interpolate_exposure_to_density(log_exposure_rgb, npix, density_curves,
                                    log_exposure, n, g3, density_cmy_out);
}

void normalize_density_curves(const float* in, int n, float* out) {
    // emulsion.py::develop: density_curves - np.nanmin(density_curves, axis=0)
    float mn[3];
    for (int c = 0; c < 3; ++c) {
        float m = 0.0f;
        bool found = false;
        for (int k = 0; k < n; ++k) {
            float v = in[k * 3 + c];
            if (std::isnan(v)) continue;
            if (!found || v < m) { m = v; found = true; }
        }
        mn[c] = found ? m : 0.0f;
    }
    for (int k = 0; k < n; ++k) {
        for (int c = 0; c < 3; ++c) {
            float v = in[k * 3 + c];
            out[k * 3 + c] = std::isnan(v) ? v : (v - mn[c]);
        }
    }
}

void interp_density_cmy_layers(const float* density_cmy, int npix,
                               const float* density_curves,
                               const float* density_curves_layers, int n,
                               bool positive_film,
                               float* out) {
    // density_curves.py::interp_density_cmy_layers
    // For each channel ch and each layer L:
    //   out[pix, L, ch] = interp(density_cmy[pix, ch],
    //                            density_curves[:, ch],
    //                            density_curves_layers[:, L, ch])
    // positive_film negates the query and the axis (interp on -x against -axis),
    // which preserves the monotonic-ascending requirement of interp1d.
    std::vector<float> axis(n);
    std::vector<float> fp(n);
    for (int ch = 0; ch < 3; ++ch) {
        // Per-channel density axis (negated for positive film).
        for (int k = 0; k < n; ++k) {
            float a = density_curves[k * 3 + ch];
            axis[k] = positive_film ? -a : a;
        }
        for (int L = 0; L < 3; ++L) {
            // Layer L curve for this channel: layers[k, L, ch] = k*9 + L*3 + ch.
            for (int k = 0; k < n; ++k) {
                fp[k] = density_curves_layers[k * 9 + L * 3 + ch];
            }
            // Per-element map with disjoint writes -> deterministic chunks, so
            // the result is byte-identical for any worker count. This was the
            // single largest component of the grain stage on device: nine
            // passes (3 channels x 3 layers) of npix interpolations, 112 M
            // calls at 12.5 MP, on ONE core -- 1864-2153 ms of a ~3.6 s stage,
            // measured, which is more than the particle sampler costs.
            const float* axis_p = axis.data();
            const float* fp_p = fp.data();
            spk::parallel_for(0, npix, [&](int p0, int p1) {
                for (int p = p0; p < p1; ++p) {
                    float x = density_cmy[p * 3 + ch];
                    if (positive_film) x = -x;
                    float v = interp1d_scalar(x, axis_p, fp_p, n);
                    out[p * 9 + L * 3 + ch] = v;
                }
            });
        }
    }
}

void interp_density_cmy_layer(const float* density_cmy, int npix,
                              const float* density_curves,
                              const float* density_curves_layers, int n,
                              bool positive_film, int layer, int ch,
                              float* out_plane) {
    if (density_cmy == nullptr || density_curves == nullptr ||
        density_curves_layers == nullptr || out_plane == nullptr ||
        npix <= 0 || n < 2 || layer < 0 || layer > 2 || ch < 0 || ch > 2)
        return;
    std::vector<float> axis(static_cast<size_t>(n));
    std::vector<float> fp(static_cast<size_t>(n));
    for (int k = 0; k < n; ++k) {
        float a = density_curves[k * 3 + ch];
        axis[static_cast<size_t>(k)] = positive_film ? -a : a;
        fp[static_cast<size_t>(k)] =
            density_curves_layers[k * 9 + layer * 3 + ch];
    }
    const float* axis_p = axis.data();
    const float* fp_p = fp.data();
    spk::parallel_for(0, npix, [&](int p0, int p1) {
        for (int p = p0; p < p1; ++p) {
            float x = density_cmy[p * 3 + ch];
            if (positive_film) x = -x;
            out_plane[p] = interp1d_scalar(x, axis_p, fp_p, n);
        }
    });
}

}  // namespace spk
