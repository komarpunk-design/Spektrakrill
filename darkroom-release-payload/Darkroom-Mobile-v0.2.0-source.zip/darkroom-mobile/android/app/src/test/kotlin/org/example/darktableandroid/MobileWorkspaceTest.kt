/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.net.Uri
import android.view.View
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.semantics.SemanticsActions
import androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry
import androidx.test.runner.lifecycle.Stage
import java.io.File
import org.example.darktableandroid.nativecore.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExternalResource
import org.junit.rules.RuleChain
import org.junit.rules.TestRule
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

/** Executes the production UI with callback fixtures; this is not native RAW/device validation. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "en-w400dp-h800dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class MobileWorkspaceTest {
    private val compose = createComposeRule()
    private val context get() = RuntimeEnvironment.getApplication()
    @get:Rule val rules: TestRule = RuleChain.outerRule(object : ExternalResource() {
        override fun before() {
            shadowOf(context.packageManager).addOrUpdateActivity(ActivityInfo().apply {
                name = ComponentActivity::class.java.name
                packageName = context.packageName
                applicationInfo = context.applicationInfo
                theme = android.R.style.Theme_Material_Light_NoActionBar
                enabled = true; exported = true
            })
        }
    }).around(compose)

    private fun module(id: String, name: String, enabled: Boolean = true) = EditorModule(id, name, enabled, true,
        listOf(ModuleParameter("exposure", "Exposure", "float", 0.0, -4.0, 4.0, emptyList(), defaultValue = 0.0)))

    private fun ready() = EditorState.Ready(Uri.parse("content://mobile-workspace/photo.nef"), 91L,
        BitmapFactory.decodeFile("../../data/style/image-1.jpg") ?: Bitmap.createBitmap(300, 200, Bitmap.Config.ARGB_8888),
        listOf(module("exposure", "Exposure"), module("exposure@7", "Exposure 7", false),
            module("sharpen", "Sharpen"), module("crop", "Crop")),
        listOf(ExportFormat("png", "PNG", "png", "image/png", 16)), selectedModule = "exposure",
        history = EditHistory(true, false, 1, 1))

    @Composable
    private fun Fixture(state: EditorState, onSelect: (String) -> Unit,
                        onParameter: (String, String, Double) -> Unit = { _, _, _ -> },
                        onEnabled: (String, Boolean) -> Unit = { _, _ -> },
                        available: Boolean = true, onOpen: () -> Unit = {}, onCancel: () -> Unit = {}) {
        DarktableTheme(AppTheme.DESKTOP) {
            EditorWorkspace(state, RuntimeAvailability(false, available), onOpen, {}, {}, {}, onCancel, {},
                onSelect, onEnabled) { module, query ->
                ModuleControls(module, module.enabled, true, {}, {}, onEnabled, onParameter,
                    { _, _, _, _ -> }, { _, _ -> }, { _, _, _ -> }, { _, _ -> }, { _, _ -> }, { _, _, _ -> },
                    controlQuery = query, sessionId = 91L, showHeader = false)
            }
        }
    }

    private fun capture(name: String) {
        compose.waitForIdle()
        compose.runOnIdle {
            val activity = ActivityLifecycleMonitorRegistry.getInstance().getActivitiesInStage(Stage.RESUMED).single()
            val content = activity.findViewById<View>(android.R.id.content)
            val bitmap = Bitmap.createBitmap(content.width, content.height, Bitmap.Config.ARGB_8888)
            content.draw(Canvas(bitmap))
            val file = File("build/reports/mobile-workspace/$name.png").apply { parentFile?.mkdirs() }
            file.outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) }
        }
    }

    @Test fun numericDraftSurvivesCategorySwitchAndCommitsTheExactNativeAddress() {
        var state by mutableStateOf(ready())
        val edits = mutableListOf<Triple<String, String, Double>>()
        compose.setContent { Fixture(state, { state = state.copy(selectedModule = it) },
            { operation, parameter, value -> edits += Triple(operation, parameter, value) }) }
        compose.onNode(hasSetTextAction() and hasText("Exposure")).performTextReplacement("0.375")
        compose.onNodeWithText(context.getString(R.string.workspace_tab_detail)).performClick()
        compose.onNodeWithText(context.getString(R.string.workspace_tab_adjustments)).performClick()
        compose.onNode(hasSetTextAction() and hasText("Exposure")).assertTextContains("0.375")
        compose.onNodeWithText(context.getString(R.string.apply)).performClick()
        compose.runOnIdle { assertEquals(listOf(Triple("exposure", "exposure", .375)), edits) }
    }

    @Test fun fullscreenAndResizeKeepDraftsAndNativeState() {
        var state by mutableStateOf(ready())
        val edits = mutableListOf<Triple<String, String, Double>>()
        compose.setContent { Fixture(state, { state = state.copy(selectedModule = it) },
            { a, b, c -> edits += Triple(a, b, c) }) }
        val before = compose.onNodeWithTag("editor_preview_pane").fetchSemanticsNode().boundsInRoot.height
        compose.onNodeWithTag("editor_resize_handle").performSemanticsAction(SemanticsActions.SetProgress) { it(.70f) }
        assertTrue(compose.onNodeWithTag("editor_preview_pane").fetchSemanticsNode().boundsInRoot.height > before)
        compose.onNode(hasSetTextAction() and hasText("Exposure")).performTextReplacement("-0.125")
        compose.onNodeWithTag("editor_full_preview").performClick()
        compose.onNodeWithTag("editor_tools_pane").assertDoesNotExist()
        compose.onNodeWithTag("editor_full_preview").performClick()
        compose.onNode(hasSetTextAction() and hasText("Exposure")).assertTextContains("-0.125")
        compose.runOnIdle { assertTrue(edits.isEmpty()); assertEquals("exposure", state.selectedModule) }
    }

    @Test fun catalogSearchSelectsAnExactDisabledInstanceWithoutEnablingIt() {
        var state by mutableStateOf(ready())
        val toggles = mutableListOf<Pair<String, Boolean>>()
        compose.setContent { Fixture(state, { state = state.copy(selectedModule = it) },
            onEnabled = { a, b -> toggles += a to b }) }
        compose.onNodeWithTag("editor_tool_picker").performClick()
        compose.onNodeWithTag("editor_catalog_search").performTextReplacement("exposure 7")
        compose.onNodeWithTag("editor_catalog_exposure@7").performClick()
        compose.onNodeWithTag("editor_tool_catalog").assertDoesNotExist()
        compose.onNodeWithTag("editor_tool_switch").assertIsOff()
        compose.runOnIdle { assertEquals("exposure@7", state.selectedModule); assertTrue(toggles.isEmpty()) }
    }

    @Test fun portraitWorkspaceShowsPhotoAndControlsAndExportsACapture() {
        var state by mutableStateOf(ready())
        compose.setContent { Fixture(state, { state = state.copy(selectedModule = it) }) }
        val photo = compose.onNodeWithTag("editor_preview_pane").fetchSemanticsNode().boundsInRoot
        val tools = compose.onNodeWithTag("editor_tools_pane").fetchSemanticsNode().boundsInRoot
        assertTrue(photo.bottom <= tools.top)
        compose.onNodeWithTag("editor_export").assertIsEnabled()
        capture("portrait")
    }

    @Test fun previewZoomCanBeResetWithoutChangingTheEngine() {
        var writes = 0
        compose.setContent { Fixture(ready(), {}, onParameter = { _, _, _ -> writes++ }) }
        compose.onNodeWithTag("editor_photo_viewport").performTouchInput { doubleClick(center) }
        compose.onNodeWithTag("editor_zoom_reset").assertIsDisplayed().performClick()
        compose.onNodeWithTag("editor_zoom_reset").assertDoesNotExist()
        compose.runOnIdle { assertEquals(0, writes) }
    }

    @Test fun discardConfirmationNeverDiscardsOnDismiss() {
        var discarded = 0
        var dismissed = 0
        compose.setContent { DarktableTheme(AppTheme.DESKTOP) {
            WorkspaceConfirmDialog(R.string.studio_stop_title, R.string.studio_stop_message, R.string.studio_stop_confirm,
                onDismiss = { dismissed++ }, onConfirm = { discarded++ })
        } }
        compose.onNodeWithText(context.getString(R.string.studio_keep_working)).performClick()
        compose.runOnIdle { assertEquals(1, dismissed); assertEquals(0, discarded) }
        compose.onNodeWithText(context.getString(R.string.studio_stop_confirm)).performClick()
        compose.runOnIdle { assertEquals(1, discarded) }
    }

    @Test @Config(qualifiers = "en-w840dp-h480dp-land-mdpi")
    fun landscapePlacesTheInspectorBesideThePhoto() {
        var state by mutableStateOf(ready())
        compose.setContent { Fixture(state, { state = state.copy(selectedModule = it) }) }
        val photo = compose.onNodeWithTag("editor_preview_pane").fetchSemanticsNode().boundsInRoot
        val tools = compose.onNodeWithTag("editor_tools_pane").fetchSemanticsNode().boundsInRoot
        assertTrue(photo.right <= tools.left)
        assertTrue(tools.width >= 280f)
        compose.onNodeWithTag("editor_resize_handle").performSemanticsAction(SemanticsActions.SetProgress) { it(.72f) }
        assertTrue(compose.onNodeWithTag("editor_tools_pane").fetchSemanticsNode().boundsInRoot.width >= 279.9f)
        capture("landscape")
    }

    @Test @Config(qualifiers = "ru-w320dp-h640dp-mdpi")
    fun smallRussianScreenKeepsPrimaryActionsAndNumericInputReachable() {
        val catalog = context.assets.open("darktable-runtime/locale/ru/LC_MESSAGES/darktable.mo").use {
            requireNotNull(GettextCatalog.parse(it.readBytes()))
        }
        val native = ready().copy(modules = ready().modules.map { module ->
            module.copy(name = module.name.lowercase(), parameters = module.parameters.map {
                it.copy(label = it.label.lowercase())
            })
        })
        var state by mutableStateOf(native.forDisplay(catalog) as EditorState.Ready)
        compose.setContent { Fixture(state, { state = state.copy(selectedModule = it) }) }
        compose.onNodeWithTag("editor_open").assertIsDisplayed()
        compose.onNodeWithTag("editor_export").assertIsDisplayed()
        compose.onNode(hasSetTextAction() and hasText("Экспозиция")).assertIsDisplayed()
        assertEquals("Настройки", context.getString(R.string.workspace_tab_settings))
        capture("russian-small")
    }

    @Test fun welcomeHasOnePrimaryImportActionAndNoEmptyInspector() {
        var opened = 0
        compose.setContent { Fixture(EditorState.Empty, {}, onOpen = { opened++ }) }
        compose.onNodeWithTag("editor_welcome_open").performClick()
        compose.onNodeWithTag("editor_tools_pane").assertDoesNotExist()
        compose.runOnIdle { assertEquals(1, opened) }
        capture("welcome")
    }

    @Test fun preparingTheFirstPhotoCanStillBeCancelled() {
        var cancelled = 0
        compose.setContent { Fixture(EditorState.Working(EditorState.Stage.DECODING), {}, onCancel = { cancelled++ }) }
        compose.onNodeWithText(context.getString(R.string.cancel)).performClick()
        compose.runOnIdle { assertEquals(1, cancelled) }
    }

    @Test fun anEngineMissingBuildNeverOffersFakeEditing() {
        compose.setContent { Fixture(EditorState.Empty, {}, available = false) }
        compose.onNodeWithTag("editor_welcome_open").assertIsNotEnabled()
        compose.onNodeWithTag("editor_export").assertIsNotEnabled()
        compose.onNodeWithText(context.getString(R.string.workspace_tab_settings)).performClick()
        compose.onNodeWithTag("app_language_picker").assertIsDisplayed()
    }

    @Test fun maskSectionsDiscloseControlsWithoutEditingAnything() {
        val module = module("exposure", "Exposure").copy(parameters = listOf(
            ModuleParameter("blend.opacity", "Opacity", "float", 100.0, 0.0, 100.0, emptyList())))
        var writes = 0
        compose.setContent { Fixture(ready().copy(modules = listOf(module)), {}, onParameter = { _, _, _ -> writes++ }) }
        compose.onNodeWithText("Opacity").assertDoesNotExist()
        compose.onNodeWithText(context.getString(R.string.module_blending)).performClick()
        compose.onNode(hasSetTextAction() and hasText("Opacity")).assertIsDisplayed()
        compose.runOnIdle { assertEquals(0, writes) }
    }
}
