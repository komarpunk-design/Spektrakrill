/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.compose.material3.Text
import androidx.compose.ui.semantics.SemanticsActions
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import org.example.darktableandroid.nativecore.*
import org.example.darktableandroid.storage.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExternalResource
import org.junit.rules.RuleChain
import org.junit.rules.TestRule
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@android.annotation.TargetApi(35)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "en-w400dp-h800dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class DesktopWorkflowUiTest {
    private val compose = createComposeRule()
    private val context get() = RuntimeEnvironment.getApplication()
    @get:Rule val rules: TestRule = RuleChain.outerRule(object : ExternalResource() {
        override fun before() {
            shadowOf(context.packageManager).addOrUpdateActivity(ActivityInfo().apply {
                name = ComponentActivity::class.java.name
                packageName = context.packageName
                applicationInfo = context.applicationInfo
                theme = android.R.style.Theme_Material_Light_NoActionBar
                enabled = true; exported = true
            })
        }
    }).around(compose)

    private fun capture(name: String) {
        compose.waitForIdle()
        compose.runOnIdle {
            val activity = androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry.getInstance()
                .getActivitiesInStage(androidx.test.runner.lifecycle.Stage.RESUMED).single()
            val view = activity.findViewById<android.view.View>(android.R.id.content)
            val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            canvas.drawColor(android.graphics.Color.BLACK)
            // Sheets and dropdowns own separate Android windows. Drawing only
            // Activity.content misses those production controls entirely.
            val windows = android.view.inspector.WindowInspector.getGlobalWindowViews()
                .filter { it.isShown && it.width > 0 && it.height > 0 }
            if(windows.isEmpty()) view.draw(canvas) else windows.forEach { window ->
                val position = IntArray(2)
                window.getLocationOnScreen(position)
                canvas.save()
                canvas.translate(position[0].toFloat(), position[1].toFloat())
                window.draw(canvas)
                canvas.restore()
            }
            val file = File("build/reports/desktop-workflow/$name.png").apply { parentFile?.mkdirs() }
            file.outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) }
        }
    }

    @Test fun savedPhotographsAreReachableBeforeOpeningANewSource() {
        var opens = 0
        compose.setContent { DarktableTheme {
            PhotoWorkspaceMenu(false, true, { opens++ }, {}, {}, {}, {}, {}, {}, {})
        } }
        compose.onNodeWithTag("photo_workspace_menu").performClick()
        compose.onNodeWithText(context.getString(R.string.desktop_library)).performClick()
        compose.runOnIdle { assertEquals(1, opens) }
        compose.onNodeWithText(context.getString(R.string.desktop_export_xmp)).assertDoesNotExist()
    }

    @Test fun nativeStyleCatalogSearchesToolsAndDispatchesTheExactStyleId() {
        val styles = listOf(PhotoStyle("first", "Warm", "", setOf("filmicrgb"), File("a")),
            PhotoStyle("second", "Mono", "", setOf("monochrome"), File("b")))
        val selected = mutableListOf<String>()
        compose.setContent { DarktableTheme { PhotoStyleLibrary(styles, {}, {}, {}, { selected += it }, {}) } }
        compose.onNodeWithTag("style_library_search").performTextReplacement("filmic")
        compose.onNodeWithTag("style_first").assertIsDisplayed()
        compose.onNodeWithTag("style_second").assertDoesNotExist()
        compose.onNodeWithText(context.getString(R.string.apply)).performClick()
        compose.runOnIdle { assertEquals(listOf("first"), selected) }
    }

    @Test fun styleApplicationDefaultsToNativeAppendAndRequiresExplicitConfirmation() {
        val choices = mutableListOf<Boolean>()
        compose.setContent { DarktableTheme { ApplyStyleDialog({}, { choices += it }) } }
        compose.runOnIdle { assertTrue(choices.isEmpty()) }
        compose.onNode(isToggleable()).assertIsOff()
        compose.onNodeWithText(context.getString(R.string.apply)).performClick()
        compose.runOnIdle { assertEquals(listOf(false), choices) }
    }

    @Test fun cameraStylesAreSeparateAndNativeLocalizationMarkersNeverLeakIntoTheCatalog() {
        val selected = mutableListOf<String>()
        val styles = listOf(
            PhotoStyle("example", "_l10n_darktable|_l10n_examples|_l10n_effects|_l10n_fog", "", setOf("colorbalancergb"),
                File("example.dtstyle"), StyleOrigin.EXAMPLE),
            PhotoStyle("camera", "_l10n_darktable|_l10n_camera styles|Nikon|D700", "", setOf("filmicrgb"),
                File("camera.dtstyle"), StyleOrigin.CAMERA))
        compose.setContent { DarktableTheme { PhotoStyleLibrary(styles, {}, {}, {}, { selected += it }, {}) } }
        compose.onNodeWithTag("style_example").assertIsDisplayed()
        compose.onNodeWithTag("style_camera").assertDoesNotExist()
        compose.onNodeWithTag("style_group_CAMERA").performScrollTo().performClick()
        compose.onNodeWithText("Nikon / D700").assertIsDisplayed()
        compose.onNodeWithTag("style_example").assertDoesNotExist()
        compose.onNodeWithText(context.getString(R.string.apply)).performClick()
        compose.runOnIdle { assertEquals(listOf("camera"), selected) }
    }

    @Test fun historyBrowserNavigatesWithoutApplyingWhileTheSliderMoves() {
        val jumps = mutableListOf<Int>()
        compose.setContent { DarktableTheme {
            ProcessingSnapshots(emptyList(), EditHistory(true, false, 5, 5), {}, {}, { jumps += it })
        } }
        compose.onNodeWithTag("session_history_position").performSemanticsAction(SemanticsActions.SetProgress) { it(2f) }
        compose.runOnIdle { assertTrue(jumps.isEmpty()) }
        compose.onNodeWithText(context.getString(R.string.apply)).performClick()
        compose.runOnIdle { assertEquals(listOf(2), jumps) }
    }

    @Test @Config(qualifiers = "ru-w320dp-h640dp-mdpi")
    fun styleCatalogKeepsItsFooterReachableOnASmallRussianScreen() {
        val styles = (1..25).map { PhotoStyle("$it", "Настольный стиль с длинным названием $it", "",
            setOf("exposure", "filmicrgb"), File("style$it")) }
        compose.setContent { DarktableTheme { PhotoStyleLibrary(styles, {}, {}, {}, {}, {}) } }
        compose.onNodeWithText(context.getString(R.string.done)).assertIsDisplayed()
        compose.onNodeWithTag("style_library_search").performTextReplacement("25")
        compose.onNodeWithTag("style_25").assertIsDisplayed()
        capture("styles-russian-small")
    }

    @Test @Config(qualifiers = "ru-w320dp-h640dp-mdpi")
    fun allWorkspaceMenuActionsRemainReachableOnASmallScreen() {
        var exports = 0
        var otherActions = 0
        compose.setContent { DarktableTheme {
            PhotoWorkspaceMenu(true, true, { otherActions++ }, { otherActions++ }, { otherActions++ },
                { otherActions++ }, { exports++ }, { otherActions++ }, { otherActions++ }, { otherActions++ })
        } }
        compose.onNodeWithTag("photo_workspace_menu").performClick()
        capture("workspace-menu-russian")
        compose.onNodeWithText(context.getString(R.string.desktop_export_xmp)).performScrollTo().performClick()
        compose.runOnIdle { assertEquals(1, exports); assertEquals(0, otherActions) }
    }

    @Test fun comparisonAndHistogramOnlyChangePresentation() {
        val bitmap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888)
        val reference = Bitmap.createBitmap(200, 100, Bitmap.Config.ARGB_8888)
        val module = EditorModule("exposure", "Exposure", true, true, emptyList())
        val state = EditorState.Ready(Uri.parse("content://fixture/image"), 123, bitmap,
            listOf(module), emptyList(), selectedModule = "exposure", comparison = reference)
        var edits = 0
        compose.setContent { DarktableTheme {
            EditorWorkspace(state, RuntimeAvailability(false, true), {}, {}, {}, {}, {}, {}, {},
                { _, _ -> edits++ }, showHistogram = true) { _, _ -> Text("Controls") }
        } }
        compose.onNodeWithTag("preview_histogram").assertIsDisplayed()
        compose.onNodeWithTag("preview_compare").performClick()
        compose.onNodeWithText(context.getString(R.string.desktop_compare_reference)).assertIsDisplayed()
        compose.onNodeWithTag("preview_compare").performClick()
        compose.onNodeWithText(context.getString(R.string.desktop_compare_current)).assertIsDisplayed()
        compose.runOnIdle { assertEquals(0, edits); assertSame(bitmap, state.preview) }
        capture("comparison-histogram")
    }
}
