/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.example.darktableandroid.storage.PhotoProject
import org.example.darktableandroid.storage.ProjectSnapshot
import org.example.darktableandroid.storage.PhotoStyle
import org.example.darktableandroid.storage.StyleOrigin
import org.example.darktableandroid.nativecore.GettextCatalog
import org.example.darktableandroid.nativecore.styleName
import org.example.darktableandroid.nativecore.styleDescription
import java.text.DateFormat
import java.util.Date

@Composable
internal fun PhotoWorkspaceMenu(ready: Boolean, enabled: Boolean, onLibrary: () -> Unit,
    onHistory: () -> Unit, onSnapshot: () -> Unit, onImport: () -> Unit, onExport: () -> Unit,
    onStyles: () -> Unit, onPin: () -> Unit, onHistogram: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }, enabled = enabled, modifier = Modifier.testTag("photo_workspace_menu")) {
            Icon(painterResource(R.drawable.studio_ic_more), stringResource(R.string.desktop_more))
        }
        DropdownMenu(open, { open = false }) {
            fun run(action: () -> Unit) { open = false; action() }
            DropdownMenuItem({ Text(stringResource(R.string.desktop_library)) }, { run(onLibrary) })
            if(ready) {
                DropdownMenuItem({ Text(stringResource(R.string.desktop_styles)) }, { run(onStyles) })
                DropdownMenuItem({ Text(stringResource(R.string.desktop_pin_comparison)) }, { run(onPin) })
                DropdownMenuItem({ Text(stringResource(R.string.desktop_histogram)) }, { run(onHistogram) })
                DropdownMenuItem({ Text(stringResource(R.string.desktop_snapshots)) }, { run(onHistory) })
                DropdownMenuItem({ Text(stringResource(R.string.desktop_save_snapshot)) }, { run(onSnapshot) })
                HorizontalDivider()
                DropdownMenuItem({ Text(stringResource(R.string.desktop_import_xmp)) }, { run(onImport) })
                DropdownMenuItem({ Text(stringResource(R.string.desktop_export_xmp)) }, { run(onExport) })
                Text(stringResource(R.string.desktop_autosave), Modifier.widthIn(max = 260.dp).padding(16.dp),
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PhotoLibrary(projects: List<PhotoProject>, onDismiss: () -> Unit, onOpen: (String) -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).testTag("photo_library")) {
            Text(stringResource(R.string.desktop_library), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.desktop_library_hint), style = MaterialTheme.typography.bodySmall)
            LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(max = 480.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if(projects.isEmpty()) item { Text(stringResource(R.string.desktop_library_empty), Modifier.padding(vertical = 24.dp)) }
                items(projects, key = { it.id }) { project ->
                    val thumbnail by produceState<android.graphics.Bitmap?>(null, project.id, project.updated) {
                        value = withContext(Dispatchers.IO) { android.graphics.BitmapFactory.decodeFile(project.thumbnail.path) }
                    }
                    Surface(onClick = { onOpen(project.id) }, shape = MaterialTheme.shapes.medium,
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier.fillMaxWidth().testTag("project_${project.id}")) {
                        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            thumbnail?.let { Image(it.asImageBitmap(), null, Modifier.size(64.dp)) }
                            Column(Modifier.weight(1f)) {
                                Text(project.name, style = MaterialTheme.typography.titleSmall)
                                Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(project.updated)),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            TextButton(onDismiss) { Text(stringResource(R.string.done)) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ProcessingSnapshots(snapshots: List<ProjectSnapshot>, history: org.example.darktableandroid.nativecore.EditHistory?,
    onDismiss: () -> Unit, onRestore: (String) -> Unit, onHistory: (Int) -> Unit) {
    var selected by remember(history) { mutableFloatStateOf(history?.position?.toFloat() ?: 0f) }
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).testTag("processing_snapshots")) {
            Text(stringResource(R.string.desktop_snapshots), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.desktop_snapshot_hint), style = MaterialTheme.typography.bodySmall)
            if(history != null && history.length > 0) {
                Text(stringResource(R.string.desktop_session_history, selected.toInt(), history.length))
                Slider(selected, { selected = it }, valueRange = 0f..history.length.toFloat(),
                    steps = (history.length - 1).coerceAtLeast(0), modifier = Modifier.testTag("session_history_position"))
                OutlinedButton({ onHistory(selected.toInt()) }, enabled = selected.toInt() != history.position) {
                    Text(stringResource(R.string.apply))
                }
            }
            LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(max = 360.dp)) {
                if(snapshots.isEmpty()) item { Text(stringResource(R.string.desktop_snapshot_empty), Modifier.padding(vertical = 16.dp)) }
                items(snapshots, key = { it.id }) { snapshot ->
                    TextButton({ onRestore(snapshot.id) }, Modifier.fillMaxWidth().testTag("snapshot_${snapshot.id}")) {
                        Column(Modifier.fillMaxWidth()) {
                            Text(snapshot.name)
                            Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(snapshot.created)),
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            TextButton(onDismiss) { Text(stringResource(R.string.done)) }
        }
    }
}

@Composable
internal fun SnapshotNameDialog(onDismiss: () -> Unit, title: Int = R.string.desktop_save_snapshot,
    label: Int = R.string.desktop_snapshot_name, maxChars: Int = 200, onSave: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(stringResource(title)) },
        text = { OutlinedTextField(name, { name = it.take(maxChars) }, singleLine = true,
            label = { Text(stringResource(label)) }) },
        confirmButton = { TextButton({ onSave(name) }) { Text(stringResource(R.string.apply)) } },
        dismissButton = { TextButton(onDismiss) { Text(stringResource(R.string.cancel)) } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PhotoStyleLibrary(styles: List<PhotoStyle>, onDismiss: () -> Unit, onImport: () -> Unit,
    onCreate: () -> Unit, onApply: (String) -> Unit, onExport: (String) -> Unit,
    catalog: GettextCatalog = GettextCatalog.empty()) {
    var query by rememberSaveable { mutableStateOf("") }
    var help by remember { mutableStateOf(false) }
    var group by rememberSaveable { mutableStateOf(when {
        styles.any { it.origin == StyleOrigin.PERSONAL } -> StyleOrigin.PERSONAL.name
        styles.any { it.origin == StyleOrigin.EXAMPLE } -> StyleOrigin.EXAMPLE.name
        else -> "ALL"
    }) }
    val filtered = remember(styles, query, group, catalog) { styles.filter {
        val text = catalog.styleName(it.name) + " " + it.name + " " + catalog.styleDescription(it.description) +
            " " + it.operations.joinToString(" ") { operation -> operation + " " + catalog.translate(operation) }
        (group == "ALL" || group == it.origin.name) &&
            query.trim().split(Regex("\\s+")).all { word -> text.contains(word, true) }
    } }
    if(help) AlertDialog(onDismissRequest = { help = false },
        title = { Text(stringResource(R.string.desktop_styles)) },
        text = { Text(stringResource(R.string.desktop_style_hint) + "\n\n" +
            stringResource(R.string.desktop_camera_style_hint)) },
        confirmButton = { TextButton({ help = false }) { Text(stringResource(R.string.done)) } })
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).testTag("photo_style_library")) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(stringResource(R.string.desktop_styles), Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                IconButton({ help = true }) {
                    Icon(painterResource(R.drawable.workspace_ic_info), stringResource(R.string.desktop_style_help))
                }
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(StyleOrigin.PERSONAL.name to R.string.desktop_styles_personal,
                    StyleOrigin.EXAMPLE.name to R.string.desktop_styles_examples,
                    StyleOrigin.CAMERA.name to R.string.desktop_styles_cameras,
                    "ALL" to R.string.desktop_styles_all).forEach { (key, label) ->
                    val count = styles.count { key == "ALL" || it.origin.name == key }
                    FilterChip(group == key, { group = key }, enabled = count > 0,
                        modifier = Modifier.testTag("style_group_$key"),
                        label = { Text(stringResource(label) + " ($count)") })
                }
            }
            if(group == StyleOrigin.CAMERA.name) Text(stringResource(R.string.desktop_camera_style_hint),
                style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(query, { query = it }, singleLine = true,
                label = { Text(stringResource(R.string.desktop_style_search)) },
                modifier = Modifier.fillMaxWidth().testTag("style_library_search"))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onImport) { Text(stringResource(R.string.desktop_style_import)) }
                TextButton(onCreate, Modifier.weight(1f)) { Text(stringResource(R.string.desktop_style_create_action)) }
            }
            LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(max = 400.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if(filtered.isEmpty()) item { Text(stringResource(if(styles.isEmpty()) R.string.desktop_style_empty else
                    R.string.tools_no_matches), Modifier.padding(vertical = 24.dp)) }
                items(filtered, key = { it.id }) { style ->
                    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainer,
                        modifier = Modifier.fillMaxWidth().testTag("style_${style.id}")) {
                        Column(Modifier.padding(12.dp)) {
                            Text(catalog.styleName(style.name), style = MaterialTheme.typography.titleMedium)
                            if(style.description.isNotBlank()) Text(catalog.styleDescription(style.description),
                                maxLines = 3, style = MaterialTheme.typography.bodySmall)
                            Text(stringResource(R.string.desktop_style_details, style.operations.size, stringResource(when(style.origin) {
                                StyleOrigin.PERSONAL -> R.string.desktop_styles_personal
                                StyleOrigin.EXAMPLE -> R.string.desktop_styles_examples
                                StyleOrigin.CAMERA -> R.string.desktop_styles_cameras
                            })),
                                style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilledTonalButton({ onApply(style.id) }) { Text(stringResource(R.string.apply)) }
                                TextButton({ onExport(style.id) }) { Text(stringResource(R.string.export)) }
                            }
                        }
                    }
                }
            }
            TextButton(onDismiss) { Text(stringResource(R.string.done)) }
        }
    }
}

@Composable
internal fun ApplyStyleDialog(onDismiss: () -> Unit, onApply: (Boolean) -> Unit) {
    var overwrite by rememberSaveable { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(stringResource(R.string.desktop_style_apply_title)) },
        text = { Column {
            Text(stringResource(R.string.desktop_style_apply_hint))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(stringResource(R.string.desktop_style_overwrite), Modifier.weight(1f))
                Switch(overwrite, { overwrite = it })
            }
        } }, confirmButton = { TextButton({ onApply(overwrite) }) { Text(stringResource(R.string.apply)) } },
        dismissButton = { TextButton(onDismiss) { Text(stringResource(R.string.cancel)) } })
}
