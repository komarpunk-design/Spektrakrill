/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.nativecore

/** Original darktable XMP writer. The editor's native dispatcher owns all calls. */
internal object NativeDesktop {
    init { System.loadLibrary("darkroom_desktop") }
    fun ensureLoaded() = Unit
    external fun writeSidecar(source: String, target: String)
    external fun exportStyle(source: String, directory: String, name: String)
    external fun writeStyledSidecar(source: String, style: String, name: String, target: String, overwrite: Boolean)
}
