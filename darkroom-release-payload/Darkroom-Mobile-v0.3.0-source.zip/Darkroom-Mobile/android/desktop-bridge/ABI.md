# Desktop interop ABI

This bridge uses public C symbols from the pinned darktable source, not a
private `dt_mobile_session` or `dt_develop_t` memory layout:

- `dt_imgid_t` is `int32_t`: `src/common/darktable.h`.
- `dt_image_get_id_full_path`: `src/common/image.h`.
- `dt_exif_xmp_write`: `src/common/exif.h` (`TRUE` means failure).
- Style creation/import/export/apply/delete: `src/common/styles.h`.

The declarations retain the exact C ABI of the source revision. The only list
argument is passed as NULL; no GLib list layout is constructed. All symbols
are resolved against the verified engine during linking (`--no-undefined`).
The existing JNI UTF-8 conversion is reused, including rejection of NUL and
unpaired surrogates. Kotlin executes interop on its single native dispatcher.

Style application writes a native XMP before retiring the old develop context.
Even on error, the app loads the saved XMP into a replacement context and
retires the old context before publishing the result. Keeping the runtime alive
through this handoff avoids reinitializing the desktop global type registry.
It must never continue rendering an old context against a database altered by
the public style API. A recovery snapshot retains the
previous processing. Applying a style starts a fresh mobile Undo session.

Build a new stage with `android/tools/build-desktop-bridge.py`. The original
stage is read-only; all original library/data hashes remain identical. The
new ARM64 library is recorded explicitly in the derived stage manifest and
the complete stage/APK verifier is run. No binary is patched or renamed.
