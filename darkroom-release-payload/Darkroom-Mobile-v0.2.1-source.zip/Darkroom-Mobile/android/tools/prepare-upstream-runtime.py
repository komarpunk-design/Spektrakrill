#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Recover the exact published engine for a UI-only fork, without modifying ELF bytes."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys
import tempfile
import zipfile

SOURCE_COMMIT = "ae4139bdf18a5c39f71c24f1fb3eab320c139cc9"
APK_SHA256 = "be88cc10e2b9cd9b17ae73eecb49c105ab001d6d0f8a05e2512e5eeb65010d8a"
APK_URL = "https://github.com/togekk39/darktable-android/releases/download/dev-latest/darktable-android-dev-ae4139b.apk"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apk", required=True, type=Path, help="original ae4139b development APK")
    parser.add_argument("--ndk", required=True, type=Path, help="official NDK with AArch64 API 26 system stubs")
    parser.add_argument("--output", required=True, type=Path, help="new runtime stage directory")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists; choose a new directory")
    digest = hashlib.sha256(args.apk.read_bytes()).hexdigest()
    if digest != APK_SHA256:
        parser.error("the APK does not match the pinned published engine SHA-256")
    script = Path(__file__).resolve().parents[2] / "mobile/dependencies/stage-android-runtime.py"
    spec = importlib.util.spec_from_file_location("darktable_published_runtime", script)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    # Validate system stubs separately. The APK already supplies its matching
    # C++/OpenMP runtimes; substituting the chosen NDK's runtimes would change ABI.
    module.Closure([], args.ndk)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="darktable-published-engine-") as temporary:
        prefix = Path(temporary)
        observed_modules = []
        with zipfile.ZipFile(args.apk) as archive:
            if archive.testzip() is not None:
                parser.error("corrupt APK ZIP")
            seen = set()
            for item in archive.infolist():
                name = item.filename
                if name in seen or stat.S_ISLNK(item.external_attr >> 16):
                    parser.error("duplicate or symlink APK entry")
                seen.add(name)
                if any(part in ("", ".", "..") for part in name.rstrip("/").split("/")) or "\\" in name:
                    parser.error("invalid APK path")
                if item.is_dir():
                    continue
                if name.startswith("lib/arm64-v8a/") and name.endswith(".so"):
                    basename = Path(name).name
                    if basename == "libandroidx.graphics.path.so":
                        continue  # Gradle supplies the independently pinned AndroidX AAR.
                    destination = prefix / "lib" / basename
                    if basename.startswith(("libdt_iop_", "libdt_format_", "libdt_storage_")) or basename in (
                        "libdarktable.so", "libdt_mobile.so"
                    ):
                        observed_modules.append(basename)
                elif name.startswith("assets/darktable-runtime/"):
                    relative = name.removeprefix("assets/darktable-runtime/")
                    if relative.startswith("data/"):
                        destination = prefix / "share/darktable" / relative.removeprefix("data/")
                    elif relative.startswith(("locale/", "lensfun/")):
                        destination = prefix / "share" / relative
                    else:
                        parser.error("unknown published runtime asset category")
                else:
                    continue
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(archive.read(item))
        # This is the inventory observed in the published APK, not an assertion
        # that every desktop feature was enabled by its original CMake build.
        if len(observed_modules) != 113:
            parser.error("unexpected published module inventory")
        manifest = prefix / "share/darktable-mobile/android-runtime-libraries.txt"
        manifest.parent.mkdir(parents=True, exist_ok=True)
        manifest.write_text("\n".join(sorted(observed_modules)) + "\n")
        closure = module.Closure([prefix / "lib"], None)
        stage_args = argparse.Namespace(prefix=prefix, output=args.output, ndk=args.ndk,
                                        library_root=[], lensfun_data=None)
        module.stage(stage_args, closure)
    provenance = {"sourceRepository": "https://github.com/togekk39/darktable-android",
                  "sourceCommit": SOURCE_COMMIT, "sourceApkUrl": APK_URL, "sourceApkSha256": digest,
                  "inventory": "observed published APK; native engine not rebuilt",
                  "androidExecutionVerified": False}
    args.output.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
