# Darkroom Mobile: Android UI fork

Based on `togekk39/darktable-android` master
`ae4139bdf18a5c39f71c24f1fb3eab320c139cc9` (2026-11-26).
The processing source lock identifies darktable
`1c4eaea9df6dbe8336449ca297acbb0120d8e968`.
This is an unofficial development fork, independent of Spektrafilm.

## Workspace

- A fixed top toolbar contains Open, Undo, Redo and Export.
- The photograph is above its inspector in portrait and beside it in landscape.
  Drag the separator to resize them. Accessibility progress actions resize the
  same separator; activating it restores the default ratio. Landscape retains at
  least 280 dp for controls and 240 dp for the photo.
- The preview supports pinch/pan, double-tap zoom/fit, a Fit button and expansion
  into the inspector area. These transformations never enter the pixel pipeline.
  Native photo-coordinate tools reset/disable preview zoom so their existing
  geometry mapping remains valid.
- Light/Color, Detail/Repair and Geometry/Effects retain the complete original
  tool inventory. Settings opens a full-height application preferences page.
- Tap the tool name for a searchable category catalog. The separate search
  button searches names and parameter labels across all categories. Exact
  native instance IDs and On/Off states are retained. Navigation never enables
  a tool or creates a native edit.
- Parameters retain their original controls, ranges and precise number inputs.
  Numeric drafts now survive tool switches, full-photo view and saved-state
  restoration. Blending/parametric masks and drawn/repair masks have labeled
  expandable sections; nothing is removed or merged.
- Russian app resources cover every translatable shell string. Tool labels use
  the original Russian darktable MO catalog. Native IDs, values and the native
  processing locale are unchanged. The existing languages remain selectable.
- Opening another edited photo from the editor asks before opening the picker.
  Cancelling that picker leaves the photo intact. The original engine's Cancel
  is terminal for the session; stopping an operation with a previous photo now
  explicitly confirms that it will close the session. Finishing an operation
  automatically removes an obsolete stop dialog.

| Original location | Fork location | Processing behavior |
| --- | --- | --- |
| Actions below preview | Top toolbar | Original callbacks and document pickers |
| Fixed 50/50 vertical split | Resizable portrait/landscape panes | Presentation only |
| Category tool dropdown | Searchable category catalog | Exact instance selection, no auto-enable |
| Cross-category search | Search beside tool selector | Original name/parameter search |
| Light/color controls, curves, WB | Light/Color inspector | Original controls and native calls |
| Denoise, sharpening, repair | Detail/Repair inspector | Original controls and native calls |
| Crop, perspective, lens, effects | Geometry/Effects inspector | Original controls and native calls |
| Blending/parametric controls | Expandable section in the same tool | All existing parameters retained |
| Drawn/repair mask controls | Expandable section in the same tool | All existing shapes/nodes retained |
| Settings in half-screen panel | Full-height Settings | Languages, themes and licenses retained |
| Export dialog | Top Export button, original dialog | Original full-resolution native export |

## Build with the original processing runtime

The UI fork does **not** rebuild, translate or substitute the native processing
algorithms. Its engine comes byte-for-byte from the checksum-verified upstream
APK for the exact Android source revision above. The published APK contains 115
engine/runtime libraries, one independently pinned AndroidX native library and
830 runtime data files. The recovered module list is the inventory observed in
that APK, not proof that every optional desktop module was enabled.

Use JDK 17, Gradle 8.14.4, Android Platform/Build Tools 35 and an official NDK
providing API 26 AArch64 system stubs. The official wrapper JAR and distribution checksum are included; see
[README.md](README.md). From the repository root:

```sh
curl --fail --location \
  https://github.com/togekk39/darktable-android/releases/download/dev-latest/darktable-android-dev-ae4139b.apk \
  --output /tmp/darktable-upstream-ae4139b.apk
python3 android/tools/prepare-upstream-runtime.py \
  --apk /tmp/darktable-upstream-ae4139b.apk --ndk /absolute/path/to/ndk \
  --output /absolute/path/to/new-runtime-stage
cd android
./gradlew :app:testDevDebugUnitTest :app:testDevReleaseUnitTest \
  :app:assembleDevRelease :app:lintDevRelease \
  -PdarktableRuntimeStage=/absolute/path/to/new-runtime-stage
```

The recovery tool requires upstream APK SHA-256
`be88cc10e2b9cd9b17ae73eecb49c105ab001d6d0f8a05e2512e5eeb65010d8a`.
It never rewrites native bytes. It validates the API 26 system stubs separately
without mixing another NDK's C++/OpenMP runtimes into the APK's original closure.
The original staging and final APK verifiers check all runtime hashes and ELF
metadata. For a native source build, use the upstream
[engine bootstrap instructions](../mobile/dependencies/ENGINE_BOOTSTRAP.md) and
supply that matching stage instead.

Normal builds now require an explicit engine stage. The old engine-disabled
route requires `-PdarktableDependencyProbe=true`; it remains explicitly unable
to open/process photos. An unsigned or dependency-only APK is not this delivery.
The development release uses application ID `design.komarpunk.darkroom.dev`,
version 0.2.1/code 3, and a development signing key. It installs beside the
original author's app. Keep a persistent production key before distributing
updates beyond this development build.

## Validation boundary

The original revision passed 189 Android/JVM tests, 39 runtime producer/verifier
checks, four host C adapter tests and an engine-enabled debug build locally.
The new workspace adds host-executed Compose checks for exact numeric dispatch,
draft retention, fullscreen/resize, disabled instances, search, narrow Russian
screens, landscape limits, zoom, import/cancellation and confirmation controls.
Captures under `app/build/reports/mobile-workspace` render the actual Compose
view tree with a sample image. They are UI fixtures, not RAW-engine screenshots.

The [functional audit](FUNCTION_AUDIT.md) records the 0.2.1 results: 289 host
Android/JVM checks per variant, the native engine suite and real NEF/RAF processing
through the original JNI bridge on Linux. Robolectric itself does not execute
the native engine. The APK retains the original ARM64 native bytes; the audit's
Linux engine build is separate. There was no attached Android phone/emulator.
Every camera, every control's pixel effect, OEM document providers, performance
and process-death behavior remain outside the verified scope. Preview/export
differences were measured and are explicitly documented in the audit.

Inherited limitations remain: session edits are not a persistent catalog;
external Android share intents start a new photo session; full desktop preset
browsing, several automatic pickers, linked liquify/freehand mask workflows and
optional codecs have the upstream port's documented coverage limits. See
[control coverage](../mobile/CONTROL_PARITY.md). Existing scalar/dedicated
controls were not removed to conceal these gaps.

## GitHub fork

The local branch is `feat/mobile-workspace`. Creating a GitHub fork through the
connected integration returned HTTP 403 `Resource not accessible by integration`.
No application source changes were pushed to the author's repository or to
Spektrakrill's main branch. Separate delivery branches and prereleases in
Spektrakrill distribute the APK, matching source ZIP, patch and audit evidence;
they do not integrate this editor into Spektrafilm. GitHub's automatic Source
code archives for those tags are not the Darkroom source ZIP.
Create the fork in the owning GitHub account, grant the connector access to it,
and then push the reviewed branch to that new repository. Never force-push an
existing fork or substitute the author's `master` remote as a writable target.
