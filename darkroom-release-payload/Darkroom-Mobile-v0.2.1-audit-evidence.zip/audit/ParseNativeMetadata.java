import java.nio.file.*;
import java.util.*;
import org.example.darktableandroid.nativecore.*;
import org.json.*;
public final class ParseNativeMetadata {
  public static void main(String[] args) throws Exception {
    JSONArray results=new JSONArray();
    for(String name: List.of("rgb","nef","raf")) {
      Path root=Path.of(args[0],"jni-"+name);
      List<EditorModule> modules=EditorMetadataKt.parseModules(Files.readString(root.resolve("modules.json")));
      List<ExportFormat> formats=EditorMetadataKt.parseExportFormats(Files.readString(root.resolve("formats.json")));
      Set<String> ids=new HashSet<>();int parameters=0,editable=0;
      for(EditorModule m:modules) {
        if(!ids.add(m.getOperation())) throw new AssertionError("duplicate native ID");
        parameters+=m.getParameters().size();if(EditorMetadataKt.getHasEditableControls(m))editable++;
      }
      for(ExportFormat f:formats) {
        if(List.of("jpeg","png","tiff","xcf").contains(f.getId())&&f.getOptions()==null) throw new AssertionError("missing codec controls "+f.getId());
        if(f.getOptions()!=null&&!f.getOptions().isValid(f.getOptions().defaultSettings(null)))throw new AssertionError("invalid encoder defaults "+f.getId());
      }
      results.put(new JSONObject().put("input",name).put("modules",modules.size()).put("editable",editable).put("parameters",parameters).put("formats",formats.size()).put("all_codec_defaults_valid",true));
    }
    Files.writeString(Path.of(args[0],"kotlin-metadata-readback.json"),results.toString(2));System.out.println(results.toString(2));
  }
}
