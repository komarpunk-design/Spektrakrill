#!/bin/sh
set -eu
python3 /audit/build-host-jni.py > /audit/jni-build.log 2>&1
/jdk/bin/javac -encoding UTF-8 -cp /audit/jni-classes:/stdlib.jar:/json.jar -d /work/jni /audit/NativeBridgeProbe.java >> /audit/jni-build.log 2>&1
export OMP_NUM_THREADS=2
for entry in 'rgb:/workspace/darktable-android/data/style/image-1.jpg:all-formats' 'nef:/raws/2249.NEF:raw' 'raf:/raws/2783.RAF:raw'; do
  label=${entry%%:*}; remain=${entry#*:}; file=${remain%%:*}; mode=${remain#*:}
  /jdk/bin/java -Xint -Djava.library.path=/work/jni -cp /work/jni:/audit/jni-classes:/stdlib.jar:/json.jar NativeBridgeProbe "$file" "/audit/jni-$label" "$mode" > "/audit/jni-$label.log" 2>&1
  printf 'JNI probe passed: %s\n' "$label"
done
