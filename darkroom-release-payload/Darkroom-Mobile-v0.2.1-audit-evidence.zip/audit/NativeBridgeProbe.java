import org.example.darktableandroid.nativecore.NativeCore;
import org.json.*;
import java.nio.file.*;
import java.util.*;
import java.security.MessageDigest;

public final class NativeBridgeProbe {
    static final NativeCore core=NativeCore.INSTANCE;
    static String hash(byte[] data) throws Exception { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data)); }
    static void check(boolean ok,String message) { if(!ok) throw new AssertionError(message); }
    static void save(Path p,Object value) throws Exception { Files.writeString(p,value.toString()); }
    static byte[] preview(long h,Path path) throws Exception {
        int[] size=new int[2]; byte[] pixels=core.renderPreview(h,512,512,size);
        check(size[0]>0&&size[1]>0&&pixels.length==(long)size[0]*size[1]*4,"invalid preview layout");
        Files.write(path,pixels); save(Path.of(path+".json"),new JSONObject().put("width",size[0]).put("height",size[1]).put("order","BGRA").put("sha256",hash(pixels)));
        return pixels;
    }
    static JSONObject module(JSONArray modules,String id) {
        for(int i=0;i<modules.length();i++) if(modules.getJSONObject(i).getString("operation").equals(id))return modules.getJSONObject(i);
        throw new AssertionError("Missing module "+id);
    }
    static double parameter(JSONArray modules,String id,String name) {
        JSONArray params=module(modules,id).getJSONArray("parameters");
        for(int i=0;i<params.length();i++) if(params.getJSONObject(i).getString("name").equals(name))return params.getJSONObject(i).getDouble("value");
        throw new AssertionError("Missing parameter "+id+"/"+name);
    }
    static void reject(Runnable action) {
        try { action.run(); } catch(Throwable expected) { return; }
        throw new AssertionError("invalid call unexpectedly accepted");
    }
    static int[] settings(int bits,int edge) { return new int[]{edge,edge,95,bits,-1,-1,-1,-1,0,1,0,1}; }
    public static void main(String[] args) throws Exception {
        Path out=Path.of(args[1]);Files.createDirectories(out);
        JSONObject result=new JSONObject().put("input",Path.of(args[0]).getFileName().toString()).put("platform","Linux x86-64 JNI; actual compiled Kotlin NativeCore.class; not Android APK execution");
        long h=0;
        try {
            Path tmp=out.resolve("runtime");Files.createDirectories(tmp);
            core.configureRuntime("/work/engine/share/darktable","/work/engine/lib/darktable",tmp.toString());
            check((core.capabilities()&1)!=0,"engine unavailable");
            h=core.open(args[0]);check(h!=0,"open returned zero");
            JSONArray modules=new JSONArray(core.listModules(h)); save(out.resolve("modules.json"),modules);
            result.put("module_count",modules.length());
            JSONArray formats=new JSONArray(core.listExportFormats(h));save(out.resolve("formats.json"),formats);
            byte[] first=preview(h,out.resolve("first-preview.bgra"));byte[] baseline=preview(h,out.resolve("baseline-preview.bgra"));
            result.put("first_preview_stable",Arrays.equals(first,baseline));
            final long handle=h;
            double before=parameter(modules,"exposure","exposure");
            core.setParameter(h,"exposure","exposure",before+.75);
            check(Math.abs(parameter(new JSONArray(core.listModules(h)),"exposure","exposure")-before-.75)<1e-5,"exposure metadata mismatch");
            byte[] changed=preview(h,out.resolve("changed-preview.bgra"));check(!Arrays.equals(baseline,changed),"exposure did not change actual pixels");
            core.undo(h);byte[] undone=preview(h,out.resolve("undo-preview.bgra"));check(Arrays.equals(baseline,undone),"undo pixels mismatch");
            core.redo(h);byte[] redone=preview(h,out.resolve("redo-preview.bgra"));check(Arrays.equals(changed,redone),"redo pixels mismatch");core.undo(h);
            result.put("exposure_pixels_changed",true).put("undo_redo_pixel_exact",true);
            String snapshot=core.history(h);reject(()->core.setParameter(handle,"exposure","exposure",Double.NaN));check(snapshot.equals(core.history(h)),"invalid call changed history");
            result.put("invalid_parameter_rejected_without_mutation",true);
            if(args.length>2&&args[2].equals("all-formats")) {
                JSONArray outputs=new JSONArray();
                for(int i=0;i<formats.length();i++) {
                    JSONObject f=formats.getJSONObject(i);String id=f.getString("id");
                    Path file=out.resolve("export-"+id+"."+f.getString("extension"));
                    core.exportWithSettings(h,file.toString(),id,settings(0,128));
                    check(Files.size(file)>16,"empty export: "+id);
                    outputs.put(new JSONObject().put("format",id).put("file",file.getFileName().toString()).put("bytes",Files.size(file)));
                }
                result.put("exports",outputs);
                JSONObject watermark=module(new JSONArray(core.listModules(h)),"watermark");
                JSONArray texts=watermark.optJSONArray("textParameters");
                if(texts!=null) for(int i=0;i<texts.length();i++) {
                    JSONObject t=texts.getJSONObject(i);
                    if(t.getString("name").equals("text")) {
                        String value="Русский 📷";core.setTextParameter(h,"watermark","text",value);
                        JSONArray after=module(new JSONArray(core.listModules(h)),"watermark").getJSONArray("textParameters");boolean found=false;
                        for(int j=0;j<after.length();j++) if(after.getJSONObject(j).getString("name").equals("text")) found=value.equals(after.getJSONObject(j).getString("value"));
                        check(found,"JNI Unicode roundtrip failed");core.undo(h);result.put("unicode_watermark_roundtrip",true);break;
                    }
                }
            } else {
                Path png=out.resolve("full-resolution-16bit.png");core.exportWithSettings(h,png.toString(),"png",settings(2,0));
                check(Files.size(png)>1024,"empty full-resolution PNG");
                result.put("png_full_resolution",png.getFileName().toString()).put("png_bytes",Files.size(png));
                core.exportWithSettings(h,out.resolve("preview-export.jpg").toString(),"jpeg",settings(1,512));
                core.exportWithSettings(h,out.resolve("preview-export-16bit.tiff").toString(),"tiff",settings(2,512));
            }
            result.put("status","passed");save(out.resolve("result.json"),result.toString(2));System.out.println(result.toString(2));
        } catch(Throwable e) {
            result.put("status","failed").put("error",e.toString());save(out.resolve("result.json"),result.toString(2));throw e;
        } finally { if(h!=0)core.close(h); }
    }
}
