from pathlib import Path
import re,json
source=Path('/workspace/darktable-android/android/app/src/androidTest/kotlin/org/example/darktableandroid')
out=Path('/workspace/artifacts/darktable-function-audit-20261126/host-ui-suite')
meta=[]
for p in sorted(source.glob('*.kt')):
 text=p.read_text();name=re.search(r'^class (\w+)',text,re.M).group(1)
 assert 'NativeCore' not in text and 'createAndroidComposeRule' not in text
 audit='AuditComponent'+name
 text=text.replace('class '+name+' {','''@org.junit.runner.RunWith(org.robolectric.RobolectricTestRunner::class)
@org.robolectric.annotation.Config(sdk = [35], qualifiers = "en-w400dp-h800dp-mdpi")
@org.robolectric.annotation.GraphicsMode(org.robolectric.annotation.GraphicsMode.Mode.NATIVE)
class '''+audit+' {')
 text=text.replace('@get:Rule val compose = createComposeRule()', '''private val compose = createComposeRule()
    @get:Rule val auditRules: org.junit.rules.TestRule = org.junit.rules.RuleChain.outerRule(
        object : org.junit.rules.ExternalResource() {
            override fun before() {
                val app = org.robolectric.RuntimeEnvironment.getApplication()
                org.robolectric.Shadows.shadowOf(app.packageManager).addOrUpdateActivity(
                    android.content.pm.ActivityInfo().apply {
                        this.name = androidx.activity.ComponentActivity::class.java.name
                        packageName = app.packageName
                        applicationInfo = app.applicationInfo
                        theme = android.R.style.Theme_Material_Light_NoActionBar
                        enabled = true
                        exported = true
                    })
            }
        }).around(compose)''')
 assert '@get:Rule val compose' not in text,p
 (out/(audit+'.kt')).write_text(text)
 meta.append({'original':str(p),'host_class':audit,'test_methods':len(re.findall(r'@Test',text)),'adaptation':'Robolectric SDK35 runner and temporary test Activity registration only; production controls and test bodies unchanged'})
(out.parent/'host-ui-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print(len(meta),'classes;',sum(m['test_methods'] for m in meta),'component cases prepared')
