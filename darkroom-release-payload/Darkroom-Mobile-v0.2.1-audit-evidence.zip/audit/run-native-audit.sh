#!/bin/sh
set -eu
cd /workspace/darktable-android
export OMP_NUM_THREADS=2
python3 mobile/tools/configure-engine.py -B /work/engine -- -G Ninja \
  -DCMAKE_BUILD_TYPE=Release -DBINARY_PACKAGE_BUILD=ON \
  -DDT_MOBILE_HOST_INTEGRATION_TESTS=ON -DBUILD_MOBILE_LIBRARY_ONLY=ON \
  -DDT_MOBILE_BUILD_TESTS=ON -DDT_MOBILE_WITH_GPR_SDK=ON \
  -DFETCHCONTENT_SOURCE_DIR_DT_GPR_SOURCE=/gpr \
  -DRAWSPEED_ENABLE_DEBUG_INFO=OFF -DDT_MOBILE_ANDROID_DEPENDENCIES=OFF -DBUILD_TESTING=OFF \
  -DUSE_LIBRAW=ON -DDONT_USE_INTERNAL_LIBRAW=OFF -DUSE_ISOBMFF=ON \
  -DUSE_LUA=OFF -DUSE_MAP=OFF -DBUILD_PRINT=OFF -DUSE_COLORD=OFF \
  -DUSE_KWALLET=OFF -DUSE_LIBSECRET=OFF -DUSE_GRAPHICSMAGICK=OFF -DUSE_IMAGEMAGICK=OFF \
  -DUSE_GMIC=OFF -DUSE_SDL2=OFF -DUSE_OPENCL=OFF -DUSE_AI=OFF \
  -DUSE_MCP=OFF -DUSE_WAYLAND=OFF -DUSE_OPENCV=OFF \
  -DUSE_JXL=OFF -DUSE_AVIF=OFF -DUSE_HEIF=OFF -DUSE_OPENJPEG=OFF \
  -DUSE_WEBP=OFF -DUSE_OPENEXR=OFF -DUSE_XCF=ON -DUSE_ICU=OFF \
  -DUSE_CAMERA_SUPPORT=OFF -DUSE_PORTMIDI=OFF -DUSE_XMLLINT=OFF > /audit/native-configure.log 2>&1
printf 'Native configuration passed\n'
cmake --build /work/engine --parallel 3 --target \
  dt_mobile_engine_test dt_mobile_raw_engine_test dt_mobile_rawspeed_gpr_test dt_mobile_api_test \
  dt_mobile_mock_api_test dt_mobile_gpr_test dt_mobile_temperature_test dt_mobile_zonemap_test \
  dt_mobile_locations_desktop_test dt_mobile_locations_android_test > /audit/native-build.log 2>&1
printf 'Native build passed\n'
ctest --test-dir /work/engine -R '^dt_mobile_' --output-on-failure --output-junit /audit/native-tests.xml > /audit/native-tests.log 2>&1
printf 'Native tests passed\n'
