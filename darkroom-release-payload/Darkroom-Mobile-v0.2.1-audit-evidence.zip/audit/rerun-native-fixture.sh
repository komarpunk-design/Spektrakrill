#!/bin/sh
set -eu
python3 - <<'PY'
from pathlib import Path
import shutil,hashlib
source=Path('/workspace/darktable-android/data/pixmaps/256x256/darktable.png')
target=Path('/work/engine/runtime-fixture-source.png');shutil.copyfile(source,target)
assert hashlib.sha256(source.read_bytes()).digest()==hashlib.sha256(target.read_bytes()).digest()
p=Path('/work/engine/mobile/CTestTestfile.cmake');s=p.read_text();s=s.replace('/work/engine/_upstream/mobile/../data/pixmaps/256x256/darktable.png',str(target));p.write_text(s)
print('Identical fixture copied onto the same writable volume for the hard-link protection check')
PY
ctest --test-dir /work/engine -R '^dt_mobile_engine_test$' --output-on-failure --output-junit /audit/native-engine-rerun.xml > /audit/native-engine-rerun.log 2>&1
