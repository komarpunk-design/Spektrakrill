import json,re,shlex,subprocess
from pathlib import Path
root=Path('/work/engine');out=Path('/work/jni');out.mkdir(exist_ok=True)
text=(root/'build.ninja').read_text();block=text.split('build mobile/dt_mobile_engine_test:',1)[1].split('\n\n',1)[0]
libs=shlex.split(re.search(r'^  LINK_LIBRARIES = (.*)$',block,re.M).group(1));libs=[x for x in libs if x!='mobile/libdt_mobile_core.a']
cmd=['cc','-std=c11','-fPIC','-shared','-Wall','-Wextra','-I/jdk/include','-I/jdk/include/linux','-I/workspace/darktable-android/mobile/include','/workspace/darktable-android/mobile/jni/dt_mobile_jni.c','-o',str(out/'libdt_mobile.so'),'-Wl,--whole-archive','mobile/libdt_mobile_core.a','-Wl,--no-whole-archive',*libs,'-Wl,--no-undefined']
subprocess.run(cmd,cwd=root,check=True)
print('Original JNI C adapter linked with the original PIC engine; no image algorithms replaced')
