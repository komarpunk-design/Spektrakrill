set -eu
/jdk/bin/javac -encoding UTF-8 -cp /audit/classes:/stdlib.jar:/json.jar -d /work/desktop-jni /audit/FactoryStyleProbe.java
export OMP_NUM_THREADS=2
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
/jdk/bin/java -Xint -Djava.library.path=/work/desktop-jni:/work/jni -cp /work/desktop-jni:/audit/classes:/stdlib.jar:/json.jar FactoryStyleProbe /workspace/darktable-android/data/style/image-1.jpg /audit/factory-rgb 'examples_colors_extreme saturation.dtstyle' > /audit/factory-rgb.log 2>&1
printf 'PASS factory RGB example\n'
/jdk/bin/java -Xint -Djava.library.path=/work/desktop-jni:/work/jni -cp /work/desktop-jni:/audit/classes:/stdlib.jar:/json.jar FactoryStyleProbe /raws/2249.NEF /audit/factory-nef darktable_Nikon_D700.dtstyle 'examples_colors_extreme saturation.dtstyle' > /audit/factory-nef.log 2>&1
printf 'PASS factory Nikon D700 + example\n'
/jdk/bin/java -Xint -Djava.library.path=/work/desktop-jni:/work/jni -cp /work/desktop-jni:/audit/classes:/stdlib.jar:/json.jar FactoryStyleProbe /raws/2783.RAF /audit/factory-raf darktable_Fujifilm_X-T3.dtstyle 'examples_colors_extreme saturation.dtstyle' > /audit/factory-raf.log 2>&1
printf 'PASS factory Fujifilm X-T3 + example\n'
