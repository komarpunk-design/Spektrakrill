set -eu
mkdir -p /work/desktop-jni
cc -std=c11 -shared -fPIC -Wall -Wextra -Werror -I/jdk/include -I/jdk/include/linux /workspace/darktable-android/android/desktop-bridge/desktop_bridge.c -L/work/engine/bin -ldarktable -Wl,-rpath,/work/engine/bin -Wl,--no-undefined -o /work/desktop-jni/libdarkroom_desktop.so
/jdk/bin/javac -encoding UTF-8 -cp /audit/classes:/stdlib.jar:/json.jar -d /work/desktop-jni /audit/DesktopInteropProbe.java
export OMP_NUM_THREADS=2
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
for entry in 'rgb:/workspace/darktable-android/data/style/image-1.jpg' 'nef:/raws/2249.NEF' 'raf:/raws/2783.RAF'; do
 label=${entry%%:*}; source=${entry#*:}
 for mode in save restore handoff style restore-style style-handoff style-overwrite-handoff failed-style; do
  /jdk/bin/java -Xint -Djava.library.path=/work/desktop-jni:/work/jni -cp /work/desktop-jni:/audit/classes:/stdlib.jar:/json.jar DesktopInteropProbe "$source" "/audit/qualified-$label" "$mode" > "/audit/$label-$mode.log" 2>&1
  printf 'PASS %s %s\n' "$label" "$mode"
 done
done
