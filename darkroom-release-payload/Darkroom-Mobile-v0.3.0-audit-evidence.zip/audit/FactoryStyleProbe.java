import org.example.darktableandroid.nativecore.NativeCore;
import org.example.darktableandroid.nativecore.NativeDesktop;
import java.nio.file.*;
import java.util.*;
import org.json.*;
public class FactoryStyleProbe {
 static final NativeCore c=NativeCore.INSTANCE;static final NativeDesktop d=NativeDesktop.INSTANCE;
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 public static void main(String[] args)throws Exception{
  Path out=Path.of(args[1]);Files.createDirectories(out);Path rt=out.resolve("runtime");Files.createDirectories(rt);
  Path source=out.resolve("factory-source."+Path.of(args[0]).getFileName().toString().replaceAll("^.*\\.",""));Files.copy(Path.of(args[0]),source,StandardCopyOption.REPLACE_EXISTING);
  c.configureRuntime("/work/engine/share/darktable","/work/engine/lib/darktable",rt.toString());long h=0;JSONArray results=new JSONArray();
  try{
   h=c.open(source.toString());
   for(int i=2;i<args.length;i++){
    Path style=Path.of("/workspace/darktable-android/data/styles",args[i]);
    var doc=javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(style.toFile());String name=doc.getElementsByTagName("name").item(0).getTextContent();
    byte[] before=c.renderPreview(h,512,512,new int[2]);
    d.writeStyledSidecar(source.toString(),style.toString(),name,source+".xmp",false);
    c.cancel(h);long next=c.open(source.toString());c.close(h);h=next;
    byte[] after=c.renderPreview(h,512,512,new int[2]);check(after.length>0,"empty factory preview");
    boolean changed=!Arrays.equals(before,after);if(args[i].startsWith("examples_"))check(changed,"factory example did not change pixels");
    results.put(new JSONObject().put("file",args[i]).put("raw_native_name",name).put("rendered",true).put("pixels_changed",changed));
   }
   Files.writeString(out.resolve("result.json"),new JSONObject().put("factory_style_applications",results).put("platform","Linux JNI; not Android device").put("status","passed").toString(2));
   System.out.println(results.toString(2));
  }finally{if(h!=0)c.close(h);}
 }
}
