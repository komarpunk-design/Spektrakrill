import org.example.darktableandroid.nativecore.NativeCore;
import org.example.darktableandroid.nativecore.NativeDesktop;
import org.json.*;
import java.nio.file.*;
import java.util.*;
public class DesktopInteropProbe {
 static final NativeCore c=NativeCore.INSTANCE;
 static final NativeDesktop d=NativeDesktop.INSTANCE;
 static void check(boolean x,String m){if(!x)throw new AssertionError(m);}
 static byte[] preview(long h){return c.renderPreview(h,512,512,new int[2]);}
 static double value(long h,String name){JSONArray a=new JSONArray(c.listModules(h));for(int i=0;i<a.length();i++){JSONObject m=a.getJSONObject(i);if(m.getString("operation").equals("exposure")){JSONArray p=m.getJSONArray("parameters");for(int j=0;j<p.length();j++)if(p.getJSONObject(j).getString("name").equals(name))return p.getJSONObject(j).getDouble("value");}}throw new AssertionError("missing "+name);}
 public static void main(String[] args)throws Exception{
  Path out=Path.of(args[1]);Files.createDirectories(out);Path source=out.resolve("source."+Path.of(args[0]).getFileName().toString().replaceAll("^.*\\.",""));
  Path rt=out.resolve("runtime");Files.createDirectories(rt);c.configureRuntime("/work/engine/share/darktable","/work/engine/lib/darktable",rt.toString());
  String mode=args[2];long h=0;
  try{
   if(mode.equals("save")){
    Files.copy(Path.of(args[0]),source,StandardCopyOption.REPLACE_EXISTING);h=c.open(source.toString());
    c.setParameter(h,"exposure","exposure",.75);
    Path styles=out.resolve("styles");Files.createDirectories(styles);d.exportStyle(source.toString(),styles.toString(),"Native Style");
    Path style;try(var files=Files.list(styles)){style=files.filter(p->p.toString().endsWith(".dtstyle")).findFirst().orElseThrow();}check(Files.size(style)>100,"style not exported");
    c.setParameter(h,"exposure","mask.add.circle",1);
    Files.write(out.resolve("expected.bgra"),preview(h));Files.writeString(out.resolve("modules-before.json"),c.listModules(h));
    Path unicode=out.resolve("снимок-📷.xmp");d.writeSidecar(source.toString(),unicode.toString());
    check(Files.size(unicode)>100,"empty XMP");Files.copy(unicode,Path.of(source+".xmp"),StandardCopyOption.REPLACE_EXISTING);
    try {d.writeSidecar(out.resolve("missing.raw").toString(),out.resolve("bad.xmp").toString());throw new AssertionError("missing source accepted");}catch(Throwable ok){check(ok instanceof java.io.IOException,"unexpected invalid-source failure: "+ok);}
    check(!Files.exists(out.resolve("bad.xmp")),"invalid source created sidecar");
    Files.writeString(out.resolve("save-result.json"),new JSONObject().put("saved",true).put("native_style_exported",true).put("unicode_output_path",true).put("mask_in_history",true).toString(2));
   }else if(mode.equals("restore")){
    h=c.open(source.toString());check(Math.abs(value(h,"exposure")-.75)<1e-6,"XMP exposure not restored");
    check(Arrays.equals(Files.readAllBytes(out.resolve("expected.bgra")),preview(h)),"XMP restored different pixels");
    check(c.listModules(h).contains("mask."),"mask not restored");
    Files.writeString(out.resolve("restore-result.json"),new JSONObject().put("native_xmp_roundtrip_pixel_exact",true).put("cross_process",true).put("mask_restored",true).put("exposure",value(h,"exposure")).toString(2));
   }else if(mode.equals("handoff")){
    h=c.open(source.toString());byte[] expected=preview(h);c.setParameter(h,"exposure","exposure",1.25);
    c.cancel(h);long next=c.open(source.toString());c.close(h);h=next;
    check(Math.abs(value(h,"exposure")-.75)<1e-6,"sidecar was not reloaded while keeping runtime alive");
    check(Arrays.equals(expected,preview(h)),"runtime handoff restored different pixels");
    Files.writeString(out.resolve("handoff-result.json"),new JSONObject().put("keepalive_sidecar_handoff_pixel_exact",true).toString(2));
   }else if(mode.equals("style-handoff")||mode.equals("style-overwrite-handoff")){
    h=c.open(source.toString());c.setParameter(h,"exposure","exposure",1.25);
    Path style;try(var files=Files.list(out.resolve("styles"))){style=files.filter(p->p.toString().endsWith(".dtstyle")).findFirst().orElseThrow();}
    d.writeStyledSidecar(source.toString(),style.toString(),"Native Style",source+".xmp",mode.equals("style-overwrite-handoff"));
    c.cancel(h);long next=c.open(source.toString());c.close(h);h=next;
    check(Math.abs(value(h,"exposure")-.75)<1e-6,"style handoff did not restore exposure");
    check(Arrays.equals(Files.readAllBytes(out.resolve("styled.bgra")),preview(h)),"style handoff pixels differ from independently reopened style");
    Files.writeString(out.resolve(mode+"-result.json"),new JSONObject().put("native_style_handoff_pixel_exact",true).put("overwrite",mode.equals("style-overwrite-handoff")).toString(2));
   }else if(mode.equals("failed-style")){
    h=c.open(source.toString());c.setParameter(h,"exposure","exposure",1.25);d.writeSidecar(source.toString(),source+".xmp");byte[] expected=preview(h);
    Path style;try(var files=Files.list(out.resolve("styles"))){style=files.filter(p->p.toString().endsWith(".dtstyle")).findFirst().orElseThrow();}
    try{d.writeStyledSidecar(source.toString(),style.toString(),"Native Style","/workspace/darktable-android/read-only-must-not-create.xmp",false);throw new AssertionError("failed output was accepted");}
    catch(Throwable error){check(error instanceof java.io.IOException,"unexpected style failure: "+error);}
    c.cancel(h);long next=c.open(source.toString());c.close(h);h=next;
    check(Math.abs(value(h,"exposure")-1.25)<1e-6,"style failure changed saved exposure");
    check(Arrays.equals(expected,preview(h)),"style failure did not restore saved pixels");
    Files.writeString(out.resolve("failed-style-result.json"),new JSONObject().put("failed_style_recovery_pixel_exact",true).toString(2));
   }else if(mode.equals("export-coupling")){
    int[] settings=new int[]{512,512,95,1,-1,-1,-1,-1,0,1,0,1};
    h=c.open(source.toString());c.setParameter(h,"exposure","exposure",.65);d.writeSidecar(source.toString(),source+".xmp");
    byte[] expected=preview(h);c.exportWithSettings(h,out.resolve("changed-before-handoff.png").toString(),"png",settings);
    c.cancel(h);long next=c.open(source.toString());c.close(h);h=next;
    check(Arrays.equals(expected,preview(h)),"XMP handoff preview changed");
    c.exportWithSettings(h,out.resolve("changed-after-handoff.png").toString(),"png",settings);
    Path style;try(var files=Files.list(out.resolve("styles"))){style=files.filter(p->p.toString().endsWith(".dtstyle")).findFirst().orElseThrow();}
    d.writeStyledSidecar(source.toString(),style.toString(),"Native Style",source+".xmp",false);
    c.cancel(h);next=c.open(source.toString());c.close(h);h=next;byte[] styled=preview(h);
    c.exportWithSettings(h,out.resolve("style-after-handoff.png").toString(),"png",settings);
    Path refSource=out.resolve("independent."+source.toString().replaceAll("^.*\\.",""));
    Files.copy(Path.of(args[0]),refSource,StandardCopyOption.REPLACE_EXISTING);long ref=c.open(refSource.toString());
    try{
     d.writeStyledSidecar(refSource.toString(),style.toString(),"Native Style",refSource+".xmp",false);
     c.cancel(ref);long replacement=c.open(refSource.toString());c.close(ref);ref=replacement;
     check(Arrays.equals(styled,preview(ref)),"style handoff preview differs from independent style");
     c.exportWithSettings(ref,out.resolve("style-independent.png").toString(),"png",settings);
    }finally{c.close(ref);}
    Files.writeString(out.resolve("export-coupling-result.json"),new JSONObject().put("preview_handoff_pixel_exact",true).put("native_exports_created",4).toString(2));
   }else if(mode.equals("style")){
    Path second=out.resolve("styled."+source.toString().replaceAll("^.*\\.",""));Files.copy(Path.of(args[0]),second,StandardCopyOption.REPLACE_EXISTING);h=c.open(second.toString());
    Path style;try(var files=Files.list(out.resolve("styles"))){style=files.filter(p->p.toString().endsWith(".dtstyle")).findFirst().orElseThrow();}
    d.writeStyledSidecar(second.toString(),style.toString(),"Native Style",second+".xmp",false);
    check(Files.size(Path.of(second+".xmp"))>100,"styled XMP not written");
   }else{
    Path second=out.resolve("styled."+source.toString().replaceAll("^.*\\.",""));h=c.open(second.toString());
    check(Math.abs(value(h,"exposure")-.75)<1e-6,"native style exposure not restored");
    Files.write(out.resolve("styled.bgra"),preview(h));
    Files.writeString(out.resolve("style-result.json"),new JSONObject().put("original_dtstyle_import_and_apply",true).put("cross_process",true).put("exposure",value(h,"exposure")).toString(2));
   }
   System.out.println("PASS "+mode+" "+source.getFileName());
  }finally{if(h!=0)c.close(h);}
 }
}
