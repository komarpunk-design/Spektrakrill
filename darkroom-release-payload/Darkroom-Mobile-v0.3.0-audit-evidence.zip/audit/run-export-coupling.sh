set -eu
/jdk/bin/javac -encoding UTF-8 -cp /audit/classes:/stdlib.jar:/json.jar -d /work/desktop-jni /audit/DesktopInteropProbe.java
export OMP_NUM_THREADS=2
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
for entry in 'rgb:/workspace/darktable-android/data/style/image-1.jpg' 'nef:/raws/2249.NEF' 'raf:/raws/2783.RAF'; do
 label=${entry%%:*}; source=${entry#*:}
 /jdk/bin/java -Xint -Djava.library.path=/work/desktop-jni:/work/jni -cp /work/desktop-jni:/audit/classes:/stdlib.jar:/json.jar DesktopInteropProbe "$source" "/audit/qualified-$label" export-coupling > "/audit/$label-export-coupling.log" 2>&1
 printf 'PASS export coupling %s\n' "$label"
done
