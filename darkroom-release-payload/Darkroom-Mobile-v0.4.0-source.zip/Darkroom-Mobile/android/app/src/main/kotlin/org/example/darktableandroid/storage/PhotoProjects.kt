/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import java.io.File
import java.io.StringReader
import java.nio.charset.CodingErrorAction
import java.nio.charset.StandardCharsets
import java.util.UUID
import javax.xml.parsers.DocumentBuilderFactory
import org.json.JSONObject
import org.xml.sax.InputSource
import org.xml.sax.SAXException
import org.xml.sax.helpers.DefaultHandler

internal data class PhotoProject(val id: String, val name: String, val sourceUri: String,
    val updated: Long, val selectedModule: String?, val directory: File, val source: File) {
    val sidecar get() = File(source.absolutePath + ".xmp")
    val thumbnail get() = directory.resolve("thumbnail.jpg")
    val assets get() = directory.resolve("assets")
}

internal data class ProjectSnapshot(val id: String, val name: String, val created: Long, val sidecar: File)

/** Originals, XMP and imported assets live in filesDir, never an evictable cache.
 * Each project owns an independent source path; editing one copy cannot update another. */
internal class PhotoProjects(private val root: File) {
    fun list(): List<PhotoProject> = root.listFiles().orEmpty().mapNotNull { directory ->
        runCatching { read(directory.name) }.getOrNull()
    }.sortedByDescending { it.updated }

    fun read(id: String): PhotoProject {
        val directory = directory(id)
        val json = JSONObject(directory.resolve("project.json").readText())
        require(json.getInt("version") == 1 && json.getString("id") == id)
        val sourceName = json.getString("source")
        require(sourceName.matches(Regex("source\\.[a-z0-9]{1,10}")))
        val source = directory.resolve(sourceName)
        check(source.isFile && source.length() > 0) { "The project's original is missing" }
        return PhotoProject(id, json.getString("name"), json.getString("uri"), json.getLong("updated"),
            json.optString("selected").takeIf { it.isNotBlank() }, directory, source)
    }

    fun create(original: File, sourceUri: String, name: String): PhotoProject {
        val id = UUID.randomUUID().toString()
        val directory = directory(id)
        check(directory.mkdirs()) { "Unable to create the photo project" }
        try {
            val source = directory.resolve("source.${safeExtension(original.name)}")
            original.inputStream().use { input -> source.outputStream().buffered().use { input.copyTo(it) } }
            check(source.length() == original.length() && source.length() > 0) { "The original was not copied completely" }
            val project = PhotoProject(id, name.take(200).ifBlank { original.name }, sourceUri,
                System.currentTimeMillis(), null, directory, source)
            update(project, null)
            return project
        } catch(failure: Throwable) {
            directory.deleteRecursively()
            throw failure
        }
    }

    fun update(project: PhotoProject, selected: String?): PhotoProject {
        val next = project.copy(updated = System.currentTimeMillis(), selectedModule = selected)
        val json = JSONObject().put("version", 1).put("id", next.id).put("name", next.name)
            .put("uri", next.sourceUri).put("source", next.source.name).put("updated", next.updated)
            .put("selected", selected ?: "")
        atomicWrite(next.directory.resolve("project.json"), json.toString().toByteArray(Charsets.UTF_8))
        return next
    }

    fun snapshot(project: PhotoProject, name: String): ProjectSnapshot {
        check(project.sidecar.isFile) { "Save the current processing before making a snapshot" }
        val id = UUID.randomUUID().toString()
        val directory = project.directory.resolve("snapshots").apply { check(isDirectory || mkdirs()) }
        val created = System.currentTimeMillis()
        val file = directory.resolve("$id.xmp")
        atomicWrite(file, project.sidecar.readBytes())
        try {
            atomicWrite(directory.resolve("$id.json"), JSONObject().put("name", name.take(200))
                .put("created", created).toString().toByteArray())
        } catch(failure: Throwable) { file.delete(); throw failure }
        return ProjectSnapshot(id, name.take(200), created, file)
    }

    fun snapshots(project: PhotoProject): List<ProjectSnapshot> =
        project.directory.resolve("snapshots").listFiles().orEmpty().filter { it.extension == "json" }.mapNotNull { file ->
            runCatching {
                UUID.fromString(file.nameWithoutExtension)
                val json = JSONObject(file.readText())
                val xmp = File(file.path.removeSuffix("json") + "xmp")
                check(xmp.isFile && xmp.length() > 0)
                ProjectSnapshot(file.nameWithoutExtension, json.getString("name"), json.getLong("created"), xmp)
            }.getOrNull()
        }.sortedByDescending { it.created }

    private fun directory(id: String): File {
        require(UUID.fromString(id).toString() == id) { "Invalid photo project" }
        return root.resolve(id)
    }
}

internal fun atomicWrite(target: File, bytes: ByteArray) {
    check(target.parentFile!!.isDirectory || target.parentFile!!.mkdirs())
    val incoming = File.createTempFile(".saving-", ".part", target.parentFile)
    try {
        incoming.outputStream().use { output -> output.write(bytes); output.fd.sync() }
        check(incoming.renameTo(target)) { "Unable to commit the saved file" }
    } finally { incoming.delete() }
}

/** Accept darktable XMP, not arbitrary XML with external entities. */
internal fun checkedProcessingXml(bytes: ByteArray): org.w3c.dom.Document {
    require(bytes.isNotEmpty() && bytes.size <= 16 * 1024 * 1024) { "Choose a darktable XMP up to 16 MiB" }
    val text = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(bytes)).toString()
    require('\u0000' !in text && !Regex("<!\\s*(DOCTYPE|ENTITY)", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
        "XMP with DTD or external entities is not supported"
    }
    val builder = DocumentBuilderFactory.newInstance().apply {
        isNamespaceAware = true
        isExpandEntityReferences = false
    }.newDocumentBuilder()
    builder.setEntityResolver { _, _ -> throw SAXException("External entities are forbidden") }
    builder.setErrorHandler(object : DefaultHandler() {
        override fun error(e: org.xml.sax.SAXParseException) { throw e }
        override fun fatalError(e: org.xml.sax.SAXParseException) { throw e }
    })
    return builder.parse(InputSource(StringReader(text)))
}

internal fun validatedDarktableXmp(bytes: ByteArray): ByteArray {
    val document = checkedProcessingXml(bytes)
    require(document.getElementsByTagNameNS("http://darktable.sf.net/", "history").length > 0) {
        "The file contains no darktable processing history"
    }
    return bytes.copyOf()
}
