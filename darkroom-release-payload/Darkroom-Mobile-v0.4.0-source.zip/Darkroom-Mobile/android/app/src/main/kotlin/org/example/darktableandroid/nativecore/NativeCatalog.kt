/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.nativecore

import java.io.File
import org.example.darktableandroid.storage.catalogMarks

internal object NativeCatalog {
    /** The upstream XMP importer splits a tag containing a comma. Restore the
     * exact RDF list through public tag APIs before any new checkpoint/export. */
    fun restore(source: String, sidecar: File) {
        if(!sidecar.isFile) return
        val marks = catalogMarks(sidecar.readBytes())
        NativeDesktop.setCatalogMarks(source, marks.rating, marks.colors, marks.tags.toTypedArray())
    }
}
