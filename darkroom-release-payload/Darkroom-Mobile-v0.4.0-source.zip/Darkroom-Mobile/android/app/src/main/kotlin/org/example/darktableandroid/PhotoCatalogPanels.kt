/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.example.darktableandroid.storage.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun DesktopCatalog(photos: List<CatalogPhoto>, canExport: Boolean, onDismiss: () -> Unit,
    onOpen: (String) -> Unit, onImport: () -> Unit, onExport: (List<String>) -> Unit, notice: String? = null) {
    var search by rememberSaveable { mutableStateOf("") }
    var stars by rememberSaveable { mutableIntStateOf(0) }
    var rejected by rememberSaveable { mutableStateOf(false) }
    var color by rememberSaveable { mutableIntStateOf(-1) }
    var sort by rememberSaveable { mutableStateOf(CatalogSort.RECENT.name) }
    var selection by rememberSaveable { mutableStateOf(listOf<String>()) }
    var sortOpen by remember { mutableStateOf(false) }
    val filtered = remember(photos, search, stars, rejected, color, sort) {
        CatalogQuery(search, stars, rejected, color.takeIf { it >= 0 }, CatalogSort.valueOf(sort)).select(photos)
    }
    val existingSelection = selection.filter { id -> photos.any { it.project.id == id } }
    val colors = listOf(R.string.catalog_red, R.string.catalog_yellow, R.string.catalog_green,
        R.string.catalog_blue, R.string.catalog_purple)
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.94f).padding(horizontal = 16.dp).testTag("desktop_catalog")) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.catalog_title), Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                TextButton(onImport, Modifier.testTag("catalog_import")) { Text(stringResource(R.string.catalog_import)) }
            }
            notice?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            OutlinedTextField(search, { search = it }, singleLine = true,
                label = { Text(stringResource(R.string.catalog_search)) },
                modifier = Modifier.fillMaxWidth().testTag("catalog_search"))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(rejected, { rejected = !rejected }, label = { Text(stringResource(R.string.catalog_rejected)) })
                for(value in 1..5) FilterChip(stars == value, { stars = if(stars == value) 0 else value; rejected = false },
                    label = { Text("$value★+") }, modifier = Modifier.testTag("catalog_stars_$value"))
                Box {
                    AssistChip({ sortOpen = true }, label = { Text(stringResource(when(CatalogSort.valueOf(sort)) {
                        CatalogSort.RECENT -> R.string.catalog_recent
                        CatalogSort.NAME -> R.string.catalog_name
                        CatalogSort.RATING -> R.string.catalog_rating
                    })) })
                    DropdownMenu(sortOpen, { sortOpen = false }) {
                        listOf(CatalogSort.RECENT to R.string.catalog_recent, CatalogSort.NAME to R.string.catalog_name,
                            CatalogSort.RATING to R.string.catalog_rating).forEach { (value, label) ->
                            DropdownMenuItem({ Text(stringResource(label)) }, { sort = value.name; sortOpen = false })
                        }
                    }
                }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                colors.forEachIndexed { index, label -> FilterChip(color == index,
                    { color = if(color == index) -1 else index }, label = { Text(stringResource(label)) }) }
            }
            Text(stringResource(R.string.catalog_count, filtered.size, existingSelection.size))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton({ selection = (selection + filtered.map { it.project.id }).distinct() }) {
                    Text(stringResource(R.string.catalog_select_visible))
                }
                if(selection.isNotEmpty()) TextButton({ selection = emptyList() }) { Text(stringResource(R.string.catalog_clear)) }
            }
            LazyColumn(Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if(filtered.isEmpty()) item { Text(stringResource(R.string.catalog_empty), Modifier.padding(16.dp)) }
                items(filtered, key = { it.project.id }) { photo ->
                    val project = photo.project
                    val thumbnail by produceState<android.graphics.Bitmap?>(null, project.id, project.updated) {
                        value = withContext(Dispatchers.IO) { android.graphics.BitmapFactory.decodeFile(project.thumbnail.path) }
                    }
                    Surface(onClick = { onOpen(project.id) }, color = MaterialTheme.colorScheme.surfaceContainer,
                        shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth().testTag("catalog_photo_${project.id}")) {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Checkbox(project.id in selection, { selected -> selection = if(selected) selection + project.id else selection - project.id },
                                Modifier.testTag("catalog_select_${project.id}"))
                            thumbnail?.let { Image(it.asImageBitmap(), null, Modifier.size(48.dp)) }
                            Column(Modifier.weight(1f)) {
                                Text(project.name, style = MaterialTheme.typography.titleSmall)
                                photo.marks?.let { marks ->
                                    Text(if(marks.rating == -1) stringResource(R.string.catalog_rejected) else "${marks.rating} ★",
                                        style = MaterialTheme.typography.bodySmall)
                                    if(marks.colors != 0) Text(colors.mapIndexedNotNull { i, label ->
                                        if(marks.colors and (1 shl i) != 0) stringResource(label) else null
                                    }.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                                    if(marks.tags.isNotEmpty()) Text(marks.tags.joinToString(" · "), maxLines = 2,
                                        style = MaterialTheme.typography.bodySmall)
                                }
                                photo.error?.let { Text(stringResource(R.string.catalog_unreadable), color = MaterialTheme.colorScheme.error) }
                                if(photo.marks == null && photo.error == null) Text(stringResource(R.string.catalog_not_opened),
                                    style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            if(!canExport) Text(stringResource(R.string.catalog_open_for_export), style = MaterialTheme.typography.bodySmall)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button({ onExport(existingSelection) }, enabled = canExport && existingSelection.isNotEmpty(),
                    modifier = Modifier.weight(1f).testTag("catalog_batch_export")) { Text(stringResource(R.string.catalog_export_selected)) }
                TextButton(onDismiss) { Text(stringResource(R.string.done)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun CatalogMarksDialog(initial: CatalogMarks, onDismiss: () -> Unit, onApply: (CatalogMarks) -> Unit) {
    var rating by rememberSaveable { mutableIntStateOf(initial.rating) }
    var colors by rememberSaveable { mutableIntStateOf(initial.colors) }
    var tags by rememberSaveable { mutableStateOf(initial.tags.joinToString("\n")) }
    val parsed = remember(rating, colors, tags) { runCatching {
        CatalogMarks(rating, colors, if(tags == initial.tags.joinToString("\n")) initial.tags
            else tags.lines().map(String::trim).filter(String::isNotEmpty).distinct())
    } }
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Text(stringResource(R.string.catalog_marks), style = MaterialTheme.typography.titleLarge)
            Column(Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                Text(stringResource(R.string.catalog_marks_hint))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for(value in 0..5) FilterChip(rating == value, { rating = value }, label = { Text("$value★") },
                        modifier = Modifier.testTag("mark_rating_$value"))
                    FilterChip(rating == -1, { rating = -1 }, label = { Text(stringResource(R.string.catalog_rejected)) })
                }
                listOf(R.string.catalog_red, R.string.catalog_yellow, R.string.catalog_green,
                    R.string.catalog_blue, R.string.catalog_purple).forEachIndexed { i, label ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(colors and (1 shl i) != 0, { colors = colors xor (1 shl i) })
                        Text(stringResource(label))
                    }
                }
                OutlinedTextField(tags, { tags = it }, label = { Text(stringResource(R.string.catalog_tags)) },
                    modifier = Modifier.fillMaxWidth().testTag("catalog_tags_input"), isError = parsed.isFailure)
                if(parsed.isFailure) Text(stringResource(R.string.catalog_tags_invalid), color = MaterialTheme.colorScheme.error)
            }
            Row {
                Button({ onApply(parsed.getOrThrow()) }, enabled = parsed.isSuccess) { Text(stringResource(R.string.apply)) }
                TextButton(onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun BatchExportPanel(jobs: List<BatchExport>, busy: Boolean, onDismiss: () -> Unit,
    onStart: () -> Unit, onStop: () -> Unit, onRetry: (String) -> Unit, canStart: Boolean = true) {
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.94f).padding(horizontal = 16.dp).testTag("batch_export_panel")) {
            Text(stringResource(R.string.catalog_queue), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.catalog_queue_hint), style = MaterialTheme.typography.bodySmall)
            if(!canStart) Text(stringResource(R.string.catalog_open_for_export), style = MaterialTheme.typography.bodySmall)
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                if(jobs.isEmpty()) item { Text(stringResource(R.string.catalog_queue_empty), Modifier.padding(16.dp)) }
                items(jobs, key = { it.id }) { job ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).testTag("batch_${job.id}")) {
                        Text(job.name, style = MaterialTheme.typography.titleSmall)
                        Text(stringResource(when(job.status) {
                            BatchStatus.PENDING -> R.string.catalog_pending
                            BatchStatus.RUNNING -> R.string.catalog_running
                            BatchStatus.DONE -> R.string.catalog_completed
                            BatchStatus.FAILED -> R.string.catalog_failed
                            BatchStatus.INTERRUPTED -> R.string.catalog_interrupted
                            BatchStatus.CANCELLED -> R.string.catalog_cancelled
                        }) + " · " + job.format)
                        if(job.status == BatchStatus.RUNNING) LinearProgressIndicator(Modifier.fillMaxWidth())
                        job.error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                        if(job.status in setOf(BatchStatus.FAILED, BatchStatus.INTERRUPTED, BatchStatus.CANCELLED))
                            TextButton({ onRetry(job.id) }, enabled = !busy) { Text(stringResource(R.string.catalog_retry)) }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if(busy) OutlinedButton(onStop) { Text(stringResource(R.string.catalog_stop)) }
                else Button(onStart, enabled = canStart && jobs.any { it.status == BatchStatus.PENDING }) { Text(stringResource(R.string.catalog_start)) }
                Spacer(Modifier.weight(1f))
                TextButton(onDismiss) { Text(stringResource(R.string.done)) }
            }
        }
    }
}
