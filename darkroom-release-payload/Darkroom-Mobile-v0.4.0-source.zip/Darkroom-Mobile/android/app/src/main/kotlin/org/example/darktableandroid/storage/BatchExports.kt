/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import java.io.File
import java.util.UUID
import org.json.JSONObject
import org.json.JSONArray
import org.example.darktableandroid.nativecore.ExportSettings

internal enum class BatchStatus { PENDING, RUNNING, DONE, FAILED, INTERRUPTED, CANCELLED }
internal data class BatchExport(val id: String, val projectId: String, val name: String,
    val format: String, val extension: String, val mime: String, val settings: ExportSettings,
    val extended: Boolean, val tree: String, val created: Long, val status: BatchStatus = BatchStatus.PENDING,
    val result: String? = null, val error: String? = null)

/** Immutable native settings per item; queue state is durable, processing is sequential. */
internal class BatchExports(private val root: File) {
    fun list(): List<BatchExport> = root.listFiles().orEmpty().filter { it.isDirectory }.mapNotNull { dir ->
        runCatching { read(dir.name) }.getOrNull()
    }.sortedWith(compareBy<BatchExport> { it.created }.thenBy { it.id })

    fun enqueue(project: PhotoProject, format: String, extension: String, mime: String,
                settings: ExportSettings, extended: Boolean, tree: String): BatchExport {
        require(format.matches(Regex("[a-zA-Z0-9_]+")) && extension.matches(Regex("[a-zA-Z0-9]{1,12}")))
        val history = if(project.sidecar.isFile) validatedDarktableXmp(project.sidecar.readBytes()) else null
        val job = BatchExport(UUID.randomUUID().toString(), project.id, project.name, format,
            extension, mime, settings.copy(), extended, tree, System.currentTimeMillis())
        val directory = directory(job.id)
        check(directory.mkdirs())
        try {
            if(history != null) atomicWrite(directory.resolve("processing.xmp"), history)
            else atomicWrite(directory.resolve("camera-defaults"), byteArrayOf(1))
            save(job)
        }
        catch(failure: Throwable) { directory.deleteRecursively(); throw failure }
        return job
    }

    fun history(job: BatchExport): File? {
        val dir = directory(job.id)
        val file = dir.resolve("processing.xmp")
        check(file.isFile || dir.resolve("camera-defaults").isFile) { "Queued processing is missing" }
        return file.takeIf { it.isFile }
    }

    fun read(id: String): BatchExport {
        val value = JSONObject(directory(id).resolve("job.json").readText())
        require(value.getInt("version") == 1 && value.getString("id") == id)
        val array = value.getJSONArray("settings")
        val settings = checkNotNull(ExportSettings.fromNativeArray(IntArray(array.length()) { array.getInt(it) }))
        return BatchExport(id, value.getString("project"), value.getString("name"), value.getString("format"),
            value.getString("extension"), value.getString("mime"), settings, value.getBoolean("extended"),
            value.getString("tree"), value.getLong("created"), BatchStatus.valueOf(value.getString("status")),
            value.optString("result").takeIf { it.isNotBlank() }, value.optString("error").takeIf { it.isNotBlank() })
    }

    fun save(job: BatchExport) {
        val json = JSONObject().put("version", 1).put("id", job.id).put("project", job.projectId)
            .put("name", job.name).put("format", job.format).put("extension", job.extension).put("mime", job.mime)
            .put("settings", JSONArray(job.settings.toNativeArray())).put("extended", job.extended)
            .put("tree", job.tree).put("created", job.created).put("status", job.status.name)
            .put("result", job.result ?: "").put("error", job.error ?: "")
        atomicWrite(directory(job.id).resolve("job.json"), json.toString().toByteArray())
    }

    fun recoverInterrupted() = list().filter { it.status == BatchStatus.RUNNING }.forEach {
        save(it.copy(status = BatchStatus.INTERRUPTED, error = "Process stopped before export completion"))
    }

    fun retry(id: String) {
        val job = read(id)
        if(job.status == BatchStatus.PENDING) return
        require(job.status in setOf(BatchStatus.FAILED, BatchStatus.INTERRUPTED, BatchStatus.CANCELLED))
        save(job.copy(status = BatchStatus.PENDING, result = null, error = null))
    }

    /** Failure of one image does not discard successful files or prevent the next image. */
    fun runPending(cancelled: () -> Boolean, changed: () -> Unit, process: (BatchExport) -> String) {
        for(job in list().filter { it.status == BatchStatus.PENDING }) {
            if(cancelled()) break
            save(job.copy(status = BatchStatus.RUNNING)); changed()
            try {
                val result = process(job)
                // A fully committed, verified file is successful even if Stop arrived at that instant.
                save(job.copy(status = BatchStatus.DONE, result = result))
            } catch(failure: Exception) {
                save(job.copy(status = if(cancelled()) BatchStatus.CANCELLED else BatchStatus.FAILED,
                    error = failure.message ?: failure.javaClass.simpleName))
            } finally { changed() }
        }
    }

    private fun directory(id: String): File {
        require(UUID.fromString(id).toString() == id)
        return root.resolve(id)
    }
}
