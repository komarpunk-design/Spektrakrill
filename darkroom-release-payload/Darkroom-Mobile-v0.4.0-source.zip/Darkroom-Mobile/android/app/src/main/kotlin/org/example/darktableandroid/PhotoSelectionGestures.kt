/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope

/** reject movement and multiple fingers before dispatching a photo-coordinate edit */
internal suspend fun PointerInputScope.detectPhotoSelectionTaps(onTap: (Offset) -> Unit) {
    awaitEachGesture {
        val down = awaitFirstDown()
        down.consume()
        while(true) {
            val event = awaitPointerEvent(PointerEventPass.Main)
            val change = event.changes.singleOrNull()?.takeIf { it.id == down.id } ?: break
            val position = change.position
            if(change.isConsumed || !position.x.isFinite() || !position.y.isFinite() ||
                position.x < 0f || position.y < 0f || position.x >= size.width || position.y >= size.height ||
                (position - down.position).getDistance() > viewConfiguration.touchSlop) break
            if(!change.pressed) {
                change.consume()
                onTap(position)
                break
            }
            // standalone photo overlays have no scrolling parent to consume drags
            if(awaitPointerEvent(PointerEventPass.Final).changes.any { it.isConsumed }) break
        }
    }
}
