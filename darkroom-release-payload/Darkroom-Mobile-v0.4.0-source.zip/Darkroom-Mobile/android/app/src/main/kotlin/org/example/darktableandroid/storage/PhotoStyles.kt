/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import java.io.File
import java.security.MessageDigest

internal data class PhotoStyle(val id: String, val name: String, val description: String,
    val operations: Set<String>, val file: File, val origin: StyleOrigin = StyleOrigin.PERSONAL,
    val requiresDevelopmentEngine: Boolean = false)

internal enum class StyleOrigin { PERSONAL, EXAMPLE, CAMERA }

internal class PhotoStyles(private val root: File, private val bundled: File? = null) {
    private val bundledStyles by lazy {
        bundled?.walkTopDown()?.filter { it.isFile && it.extension == "dtstyle" }?.mapNotNull { file ->
            runCatching {
                val origin = if(file.name.startsWith("darktable_")) StyleOrigin.CAMERA else StyleOrigin.EXAMPLE
                readStyle(file.readBytes(), file).let { it.copy(id = "bundled-${it.id}", origin = origin) }
            }.getOrNull()
        }?.toList().orEmpty()
    }

    fun list(): List<PhotoStyle> = (root.listFiles().orEmpty().filter { it.extension == "dtstyle" }
        .mapNotNull { file -> runCatching { readStyle(file.readBytes(), file) }.getOrNull() }
        + bundledStyles).sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })

    fun retain(bytes: ByteArray): PhotoStyle {
        val id = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val file = root.resolve("$id.dtstyle")
        val style = readStyle(bytes, file)
        if(!file.exists()) atomicWrite(file, bytes)
        return style
    }

    private fun readStyle(bytes: ByteArray, file: File): PhotoStyle {
        val document = checkedProcessingXml(bytes)
        require(document.documentElement.tagName == "darktable_style") { "Choose an original darktable .dtstyle file" }
        val info = document.getElementsByTagName("info").item(0) as? org.w3c.dom.Element
        val name = info?.getElementsByTagName("name")?.item(0)?.textContent?.trim().orEmpty()
        require(name.isNotEmpty() && name.toByteArray(Charsets.UTF_8).size <= 4096) { "The style has no usable name" }
        val plugins = document.getElementsByTagName("plugin")
        require(plugins.length in 1..2048) { "The style contains no processing tools" }
        val operations = (0 until plugins.length).map { index ->
            val plugin = plugins.item(index) as org.w3c.dom.Element
            val operation = plugin.getElementsByTagName("operation").item(0)?.textContent.orEmpty()
            require(operation.matches(Regex("[a-zA-Z0-9_]{1,64}"))) { "The style contains an invalid tool identity" }
            operation
        }.toSet()
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val blendVersions = document.getElementsByTagName("blendop_version")
        val modernBlend = (0 until blendVersions.length).any {
            (blendVersions.item(it).textContent.trim().toIntOrNull() ?: 0) >= 15
        }
        return PhotoStyle(digest, name,
            info?.getElementsByTagName("description")?.item(0)?.textContent.orEmpty(), operations, file,
            requiresDevelopmentEngine = modernBlend)
    }
}
