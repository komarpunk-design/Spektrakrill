/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.example.darktableandroid.nativecore.EditorModule
import org.example.darktableandroid.nativecore.MaskPhotoPoint

/** A persistent editor: parameter scrolling has no dismiss or navigation gesture. */
@Composable
internal fun EditorWorkspace(
    state: EditorState,
    runtime: RuntimeAvailability,
    onOpen: () -> Unit,
    onExport: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onCancel: () -> Unit,
    onRetry: (Uri) -> Unit,
    onSelectModule: (String) -> Unit,
    onEnabled: (String, Boolean) -> Unit,
    onRefreshPreview: () -> Unit = {},
    toneSample: ToneEqualizerSample? = null,
    onToneSample: (String, Float, Float) -> Unit = { _, _, _ -> },
    onToneAdjust: (ToneEqualizerSample, Double, Long, Boolean) -> Unit = { _, _, _, _ -> },
    maskPhotoSelection: MaskPhotoSelection? = null,
    onLoadMaskPhoto: (String) -> Unit = {},
    onPlaceMaskPhoto: (MaskPhotoTarget, Float, Float) -> Unit = { _, _, _ -> },
    workspaceActions: @Composable () -> Unit = {},
    showHistogram: Boolean = false,
    moduleContent: @Composable (EditorModule, String) -> Unit,
) {
    val ready = when(state) {
        is EditorState.Ready -> state
        is EditorState.Working -> state.previous
        else -> null
    }
    val busy = state is EditorState.Working
    val toneUpdating = state is EditorState.Working && state.stage == EditorState.Stage.TONE_ADJUSTING
    val keyboardVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val workspaceState = rememberSaveableStateHolder()
    var workspaceSession by rememberSaveable { mutableStateOf<Long?>(null) }
    var tabName by rememberSaveable { mutableStateOf(WorkspaceTab.ADJUSTMENTS.name) }
    var toolSearchVisible by rememberSaveable(ready?.sessionId) { mutableStateOf(false) }
    var adjustOperation by rememberSaveable(ready?.sessionId) { mutableStateOf("") }
    var detailOperation by rememberSaveable(ready?.sessionId) { mutableStateOf("") }
    var geometryOperation by rememberSaveable(ready?.sessionId) { mutableStateOf("") }
    var fullPreview by rememberSaveable(ready?.sessionId) { mutableStateOf(false) }
    BackHandler(enabled = fullPreview) { fullPreview = false }
    val tab = WorkspaceTab.entries.firstOrNull { it.name == tabName } ?: WorkspaceTab.ADJUSTMENTS
    fun rememberedOperation(category: WorkspaceTab): String = when(category) {
        WorkspaceTab.ADJUSTMENTS -> adjustOperation
        WorkspaceTab.DETAIL -> detailOperation
        WorkspaceTab.GEOMETRY -> geometryOperation
        WorkspaceTab.SETTINGS -> ""
    }
    fun rememberOperation(operation: String) {
        when(workspaceTabForOperation(operation)) {
            WorkspaceTab.ADJUSTMENTS -> adjustOperation = operation
            WorkspaceTab.DETAIL -> detailOperation = operation
            WorkspaceTab.GEOMETRY -> geometryOperation = operation
            WorkspaceTab.SETTINGS -> Unit
        }
    }
    val currentInCategory = ready?.selectedModule?.takeIf { workspaceTabForOperation(it) == tab }
    val selectedTool = ready?.modules?.preferredWorkspaceModule(tab, currentInCategory ?: rememberedOperation(tab))
    fun selectTool(operation: String) {
        if(ready?.modules?.any { it.operation == operation } != true) return
        rememberOperation(operation)
        if(!busy) onSelectModule(operation)
    }
    fun selectTab(category: WorkspaceTab) {
        selectedTool?.let { rememberOperation(it.operation) }
        focus.clearFocus()
        keyboard?.hide()
        toolSearchVisible = false
        fullPreview = false
        tabName = category.name
        ready?.modules?.preferredWorkspaceModule(category, rememberedOperation(category))?.let { target ->
            rememberOperation(target.operation)
            // Forward every navigation intent. The collected Ready snapshot may
            // still describe an earlier selection when tabs are tapped rapidly.
            if(!busy) onSelectModule(target.operation)
        }
    }
    LaunchedEffect(ready?.sessionId, ready?.selectedModule) {
        ready?.selectedModule?.let(::rememberOperation)
    }
    // Reconcile delayed native publications and navigation requested while busy.
    LaunchedEffect(ready?.sessionId, tab, selectedTool?.operation, ready?.selectedModule, busy) {
        if(!busy && selectedTool != null && selectedTool.operation != ready?.selectedModule)
            onSelectModule(selectedTool.operation)
    }
    val toneModule = selectedTool?.takeIf { it.operation.substringBefore('@') == "toneequal" }
    var toneImageMode by rememberSaveable(ready?.sessionId, ready?.selectedModule, tabName) { mutableStateOf(false) }
    var tonePoint by remember(ready?.sessionId, ready?.selectedModule) { mutableStateOf<ToneEqualizerPoint?>(null) }
    val maskModule = selectedTool?.takeIf { module -> module.parameters.any { maskControlAddress(it.name) != null } }
    var maskImageMode by rememberSaveable(ready?.sessionId, ready?.selectedModule, tabName) { mutableStateOf(false) }
    var maskFormId by rememberSaveable(ready?.sessionId, ready?.selectedModule, tabName) { mutableStateOf<Int?>(null) }
    var maskSource by rememberSaveable(ready?.sessionId, ready?.selectedModule, tabName) { mutableStateOf(false) }
    var maskLoaded by remember(ready?.sessionId, ready?.selectedModule, tabName) { mutableStateOf(false) }
    val maskAvailable = maskModule?.enabled == true && ready?.previewCurrent == true &&
        ready.selectedModule == maskModule.operation &&
        workspaceTabForOperation(maskModule.operation) == tab
    val currentMaskSelection = maskPhotoSelection?.takeIf { selection ->
        ready != null && selection.sessionId == ready.sessionId && selection.module == maskModule?.operation &&
            selection.preview === ready.preview
    }
    val maskForms = currentMaskSelection?.points?.forms.orEmpty()
    val maskForm = maskForms.singleOrNull { it.id == maskFormId } ?: maskForms.firstOrNull()
    val maskUsesSource = maskForm?.let { it.center == null || (maskSource && it.source != null) } ?: false
    val maskActive = maskAvailable && maskImageMode
    val maskTarget = if(maskActive && currentMaskSelection != null && maskForm != null)
        MaskPhotoTarget(currentMaskSelection.sessionId, currentMaskSelection.module, currentMaskSelection.preview,
            maskForm.id, maskUsesSource) else null
    val maskPoint = maskForm?.let { if(maskUsesSource) it.source else it.center }
    val toneAvailable = tab == WorkspaceTab.ADJUSTMENTS && toneModule?.enabled == true && ready?.previewCurrent == true &&
        ready.selectedModule == toneModule.operation
    val toneActive = toneAvailable && toneImageMode
    val currentSample = toneSample?.takeIf { sample ->
        ready != null && sample.sessionId == ready.sessionId && sample.module == toneModule?.operation &&
            sample.preview === ready.preview && sample.x.isFinite() && sample.y.isFinite() &&
            sample.x >= 0f && sample.x < 1f && sample.y >= 0f && sample.y < 1f &&
            sample.exposure.isFinite() && sample.selectedExposure.isFinite() &&
            (sample.pendingExposure == null || sample.pendingExposure.isFinite())
    }
    val selectedSample = currentSample?.takeIf { sample -> tonePoint?.let { it.x == sample.x && it.y == sample.y } == true }
    fun sampleTone(point: ToneEqualizerPoint) {
        if(toneActive && !busy && toneModule != null) {
            tonePoint = point
            onToneSample(toneModule.operation, point.x, point.y)
        }
    }
    LaunchedEffect(toneAvailable) {
        if(!toneAvailable) { toneImageMode = false; tonePoint = null }
    }
    LaunchedEffect(maskAvailable, maskImageMode, currentMaskSelection, busy) {
        if(!maskAvailable || !maskImageMode) {
            maskImageMode = false
            maskLoaded = false
            maskFormId = null
            maskSource = false
        } else if(currentMaskSelection != null) {
            maskLoaded = true
            maskFormId = maskForm?.id
            maskSource = maskUsesSource
        } else if(maskLoaded && !busy) {
            // Generic edits, Undo and image changes revoke the projection lease.
            maskImageMode = false
            maskLoaded = false
            maskFormId = null
            maskSource = false
        }
    }
    LaunchedEffect(ready?.preview) {
        // A tone-only adjustment may return the same selection bound to a new
        // preview. Other edits invalidate its image geometry and input mask.
        if(currentSample == null) tonePoint = null
    }
    LaunchedEffect(ready?.sessionId) {
        if(ready != null && workspaceSession != ready.sessionId) {
            workspaceSession = ready.sessionId
            tabName = WorkspaceTab.ADJUSTMENTS.name
        }
    }
    var previewFraction by rememberSaveable { mutableStateOf(.55f) }
    Scaffold(modifier = Modifier.fillMaxSize().imePadding(), topBar = {
            WorkspaceToolbar(ready, runtime, busy, onOpen, onUndo, onRedo, onExport, workspaceActions)
    }, bottomBar = {
        NavigationBar(containerColor = LocalEditorChromeColors.current.toolbar, tonalElevation = 0.dp) {
            val selectedColor = MaterialTheme.colorScheme.onSurface
            WorkspaceTab.entries.forEach { item ->
                NavigationBarItem(selected = tab == item, onClick = { selectTab(item) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = selectedColor, selectedTextColor = selectedColor,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        indicatorColor = LocalEditorChromeColors.current.selection),
                    icon = { Icon(painterResource(item.iconResource()), null) },
                    label = { Text(stringResource(item.labelResource()), maxLines = 2, overflow = TextOverflow.Ellipsis) })
            }
        }
    }) { padding ->
        BoxWithConstraints(Modifier.fillMaxSize().padding(padding)) {
            val wide = maxWidth >= 600.dp && maxWidth > maxHeight
            val density = LocalDensity.current
            val availableWidth = (maxWidth.value - 24f).coerceAtLeast(1f)
            val range = if(wide) (240f / availableWidth).coerceAtLeast(.30f)..(1f - 280f / availableWidth).coerceAtMost(.72f) else .30f.. .72f
            val fraction = if(keyboardVisible && !wide) .25f else inspectorPreviewFraction(previewFraction).coerceIn(range)
            val extent = with(density) { (if(wide) maxWidth else maxHeight).toPx() - 24.dp.toPx() }
            val preview: @Composable (Modifier) -> Unit = { modifier ->
                WorkspacePreview(state, runtime, ready, busy, onCancel, onRefreshPreview,
                    modifier.testTag("editor_preview_pane"), toneActive, tonePoint, ::sampleTone,
                    maskActive, maskTarget, maskPoint, onPlaceMaskPhoto, fullPreview, { fullPreview = !fullPreview }, showHistogram)
            }
            val tools: @Composable (Modifier) -> Unit = { modifier ->
                Box(modifier.background(LocalEditorChromeColors.current.panel).testTag("editor_tools_pane")) {
                    if(tab == WorkspaceTab.SETTINGS) WorkspaceAppInfo(runtime)
                    else if(ready != null) workspaceState.SaveableStateProvider("image-${ready.sessionId}") {
                        WorkspaceTools(ready, tab, busy, selectedTool, ::selectTool, onEnabled,
                            searchVisible = toolSearchVisible, onSearchVisible = { toolSearchVisible = it },
                            onSelectTab = { tabName = it.name }, beforeControls = { selected ->
                            if(selected.operation == toneModule?.operation) {
                                ToneEqualizerTouchEditor((!busy || toneUpdating) && toneAvailable, toneActive, selectedSample,
                                    onImageMode = { active ->
                                        toneImageMode = active; tonePoint = null
                                        if(active) { maskImageMode = false; maskLoaded = false }
                                    },
                                    onSelectCentre = { sampleTone(ToneEqualizerPoint(.5f, .5f)) },
                                    onAdjust = onToneAdjust, selectionEnabled = !busy && toneAvailable)
                                HorizontalDivider()
                            }
                            if(selected.operation == maskModule?.operation) {
                                MaskPhotoEditor(!busy && maskAvailable, maskActive, currentMaskSelection?.points,
                                    maskForm?.id, maskUsesSource, onImageMode = { active ->
                                        maskImageMode = active
                                        maskLoaded = false
                                        maskFormId = null
                                        maskSource = false
                                        if(active) {
                                            toneImageMode = false; tonePoint = null
                                            onLoadMaskPhoto(selected.operation)
                                        }
                                    }, onForm = { id -> maskFormId = id; maskSource = false },
                                    onSource = { maskSource = it })
                                HorizontalDivider()
                            }
                        }, moduleContent = moduleContent)
                    }
                }
            }
            when {
                tab == WorkspaceTab.SETTINGS -> tools(Modifier.fillMaxSize())
                ready == null -> WorkspaceWelcome(state, runtime, onOpen, onRetry, onCancel)
                fullPreview -> preview(Modifier.fillMaxSize())
                wide -> Row(Modifier.fillMaxSize()) {
                    preview(Modifier.fillMaxHeight().weight(fraction))
                    InspectorResizeHandle(true, fraction, extent, range) { previewFraction = it }
                    tools(Modifier.fillMaxHeight().weight(1f - fraction))
                }
                else -> Column(Modifier.fillMaxSize()) {
                    preview(Modifier.fillMaxWidth().weight(fraction))
                    if(!keyboardVisible) InspectorResizeHandle(false, fraction, extent) { previewFraction = it }
                    tools(Modifier.fillMaxWidth().weight(1f - fraction))
                }
            }
        }
    }
}

@Composable
private fun WorkspacePreview(
    state: EditorState, runtime: RuntimeAvailability, ready: EditorState.Ready?, busy: Boolean,
    onCancel: () -> Unit, onRefreshPreview: () -> Unit, modifier: Modifier,
    toneActive: Boolean,
    tonePoint: ToneEqualizerPoint?,
    onTonePoint: (ToneEqualizerPoint) -> Unit,
    maskActive: Boolean,
    maskTarget: MaskPhotoTarget?,
    maskPoint: MaskPhotoPoint?,
    onPlaceMaskPhoto: (MaskPhotoTarget, Float, Float) -> Unit,
    fullscreen: Boolean, onFullscreen: () -> Unit, showHistogram: Boolean,
) {
    BoxWithConstraints(modifier.background(LocalEditorChromeColors.current.preview)) {
        val histogramFits = maxHeight >= 220.dp
        var showingReference by rememberSaveable(ready?.sessionId) { mutableStateOf(false) }
        LaunchedEffect(toneActive, maskActive) { if(toneActive || maskActive) showingReference = false }
        ready?.let {
            val displayed = if(showingReference) it.comparison ?: it.preview else it.preview
            Column(Modifier.fillMaxSize().padding(8.dp)) {
                Box(Modifier.fillMaxWidth().weight(1f)) {
                    WorkspacePhotoViewport(it.sessionId, displayed.width, displayed.height, !toneActive && !maskActive) {
                        Image(displayed.asImageBitmap(), stringResource(R.string.preview_description),
                            Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    }
                    if(toneActive) ToneEqualizerPhotoTarget(it.preview.width, it.preview.height, !busy, tonePoint, onTonePoint)
                    if(maskActive) MaskPhotoTargetOverlay(it.preview.width, it.preview.height, !busy,
                        maskTarget, maskPoint, onPlaceMaskPhoto)
                    if(it.comparison != null && !toneActive && !maskActive) FilledTonalButton(
                        { showingReference = !showingReference }, enabled = !busy,
                        modifier = Modifier.align(Alignment.TopEnd).testTag("preview_compare")) {
                        Text(stringResource(if(showingReference) R.string.desktop_compare_reference else
                            R.string.desktop_compare_current))
                    }
        IconButton(onClick = onFullscreen, modifier = Modifier.align(Alignment.BottomStart)
            .padding(8.dp).background(MaterialTheme.colorScheme.surface.copy(alpha = .9f), MaterialTheme.shapes.medium)
            .testTag("editor_full_preview")) {
            Icon(painterResource(if(fullscreen) R.drawable.workspace_ic_close else R.drawable.studio_ic_fullscreen),
                stringResource(if(fullscreen) R.string.studio_show_tools else R.string.studio_full_preview))
        }
                }
                if(showHistogram) {
                    if(histogramFits) PreviewHistogramPanel(displayed)
                    else TextButton(onFullscreen) { Text(stringResource(R.string.desktop_expand_histogram)) }
                }
            }
        }
        if(state is EditorState.Working) Surface(Modifier.align(Alignment.TopCenter).fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)) {
            Column {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(state.stage.workspaceLabelResource()), Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if(state.stage != EditorState.Stage.TONE_ADJUSTING)
                        TextButton(onClick = onCancel, enabled = state.stage != EditorState.Stage.CANCELLING) {
                            Text(stringResource(R.string.cancel))
                        }
                }
            }
        } else if(ready != null && !ready.previewCurrent) {
            Surface(Modifier.align(Alignment.TopCenter).fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)) {
                Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Text(stringResource(R.string.tone_touch_stale_preview), style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error)
                    ready.notice?.let { notice ->
                        Text(notice, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    TextButton(onClick = onRefreshPreview, enabled = !busy,
                        modifier = Modifier.heightIn(min = 48.dp).testTag("editor_retry_preview")) {
                        Text(stringResource(R.string.tone_touch_retry_preview))
                    }
                }
            }
        } else ready?.notice?.let { notice ->
            Surface(Modifier.align(Alignment.TopCenter).fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)) {
                Text(notice, Modifier.padding(8.dp), style = MaterialTheme.typography.bodySmall,
                    maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
        }

    }
}

@Composable
private fun WorkspaceTools(
    ready: EditorState.Ready, tab: WorkspaceTab, busy: Boolean,
    selected: EditorModule?,
    onSelectModule: (String) -> Unit, onEnabled: (String, Boolean) -> Unit,
    searchVisible: Boolean, onSearchVisible: (Boolean) -> Unit,
    onSelectTab: (WorkspaceTab) -> Unit,
    beforeControls: @Composable (EditorModule) -> Unit,
    moduleContent: @Composable (EditorModule, String) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var enabledOnly by rememberSaveable { mutableStateOf(false) }
    // Search is navigation, not an edit or a filter on the selected tool. Keep
    // normal category selection independent from the query until a result is tapped.
    val shown = ready.modules.workspaceModules(tab)
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val searchFocus = remember { FocusRequester() }
    fun closeSearch() {
        onSearchVisible(false)
        query = ""
        enabledOnly = false
        focus.clearFocus()
        keyboard?.hide()
    }
    BackHandler(enabled = searchVisible) { closeSearch() }
    LaunchedEffect(searchVisible) {
        if(searchVisible) searchFocus.requestFocus()
        else {
            query = ""
            enabledOnly = false
        }
    }
    val savedControls = rememberSaveableStateHolder()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().background(LocalEditorChromeColors.current.toolbar)
            .padding(start = 12.dp, end = 4.dp, top = 6.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            var expanded by rememberSaveable(tab) { mutableStateOf(false) }
            Box(Modifier.weight(1f)) {
                val chooseDescription = stringResource(R.string.workspace_choose_tool)
                OutlinedButton(shape = MaterialTheme.shapes.small,
                    onClick = { expanded = true }, enabled = !busy && shown.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().testTag("editor_tool_picker")
                        .semantics { contentDescription = chooseDescription }) {
                    Text(selected?.name ?: stringResource(R.string.workspace_no_tools), Modifier.weight(1f),
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Icon(painterResource(R.drawable.workspace_ic_expand), null)
                }
                if(expanded) WorkspaceToolCatalog(shown, selected?.operation, busy,
                    onDismiss = { expanded = false }, onSelect = { operation ->
                        expanded = false
                        closeSearch()
                        onSelectModule(operation)
                    })
            }

            selected?.let { module ->
                val description = stringResource(R.string.workspace_tool_toggle, module.name)
                val status = stringResource(if(module.enabled) R.string.workspace_enabled else R.string.workspace_disabled)
                Switch(checked = module.enabled, onCheckedChange = { onEnabled(module.operation, it) },
                    enabled = !busy && module.canDisable,
                    modifier = Modifier.testTag("editor_tool_switch").semantics {
                        contentDescription = description
                        stateDescription = status
                    })
            }
            IconButton(onClick = {
                if(searchVisible) closeSearch() else onSearchVisible(true)
            }, modifier = Modifier.testTag("editor_tool_search_button")) {
                Icon(painterResource(if(searchVisible) R.drawable.workspace_ic_close else R.drawable.workspace_ic_search),
                    stringResource(if(searchVisible) R.string.workspace_close_search else R.string.tools_search))
            }
        }
        if(searchVisible) Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = query, onValueChange = { query = it },
                modifier = Modifier.weight(1f).focusRequester(searchFocus).testTag("editor_tool_search_input"), singleLine = true,
                label = { Text(stringResource(R.string.tools_search)) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { keyboard?.hide() }))
            FilterChip(selected = enabledOnly, onClick = { enabledOnly = !enabledOnly },
                modifier = Modifier.testTag("editor_tool_search_enabled"),
                label = { Text(stringResource(R.string.tools_enabled)) })
        }
        if(!searchVisible) selected?.takeIf { !it.enabled }?.let {
            Text(stringResource(R.string.workspace_disabled_hint), Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                style = MaterialTheme.typography.bodySmall)
        }
        HorizontalDivider(Modifier.padding(top = 4.dp))
        if(searchVisible) {
            WorkspaceToolSearchResults(filterEditingTools(ready.modules, query, enabledOnly), busy) { module ->
                closeSearch()
                onSelectTab(module.workspaceTab())
                onSelectModule(module.operation)
            }
        } else if(selected == null) {
            Text(stringResource(R.string.tools_no_matches), Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
        } else savedControls.SaveableStateProvider(selected.operation) {
            // Save drafts by native identity, but recreate the tool's composition
            // and rendering nodes instead of reusing another tool's subtree.
            key(ready.sessionId, selected.operation) {
                Column(Modifier.fillMaxSize().testTag("editor_parameter_scroll")
                    .verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp)) {
                    beforeControls(selected)
                    moduleContent(selected, "")
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun WorkspaceToolSearchResults(results: List<EditorModule>, busy: Boolean, onSelect: (EditorModule) -> Unit) {
    Text(stringResource(R.string.workspace_search_results, results.size),
        Modifier.padding(horizontal = 12.dp, vertical = 6.dp).testTag("editor_tool_search_count"),
        style = MaterialTheme.typography.labelMedium)
    if(results.isEmpty()) {
        Text(stringResource(R.string.tools_no_matches), Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
    } else LazyColumn(Modifier.fillMaxSize().testTag("editor_tool_search_results")) {
        items(results, key = { it.operation }) { module ->
            ListItem(modifier = Modifier.fillMaxWidth()
                .testTag("editor_tool_search_result_${module.operation}")
                .clickable(enabled = !busy) { onSelect(module) },
                headlineContent = { Text(module.name) },
                supportingContent = {
                    Text(stringResource(R.string.workspace_search_result_detail,
                        stringResource(module.workspaceTab().labelResource()), module.operation))
                },
                trailingContent = {
                    Text(stringResource(if(module.enabled) R.string.workspace_enabled else R.string.workspace_disabled),
                        style = MaterialTheme.typography.labelSmall)
                })
            HorizontalDivider()
        }
    }
}

@Composable
private fun WorkspaceAppInfo(runtime: RuntimeAvailability) {
    val uriHandler = LocalUriHandler.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AppLanguageMenu()
        HorizontalDivider()
        AppThemeMenu()
        HorizontalDivider()
        Text(stringResource(R.string.about), style = MaterialTheme.typography.titleMedium)
        Text(stringResource(R.string.unofficial_notice), style = MaterialTheme.typography.bodyMedium)
        HorizontalDivider()
        Text(stringResource(R.string.workspace_license_title), style = MaterialTheme.typography.titleSmall)
        SelectionContainer { Text("GPL-3.0-or-later", style = MaterialTheme.typography.bodyMedium) }
        TextButton(onClick = { uriHandler.openUri("https://github.com/darktable-org/darktable") }) {
            Text(stringResource(R.string.workspace_upstream))
        }
        SelectionContainer {
            Text(stringResource(R.string.workspace_upstream_commit, "1c4eaea9df6dbe8336449ca297acbb0120d8e968"),
                style = MaterialTheme.typography.bodySmall)
        }
        Text(stringResource(if(runtime.available) R.string.workspace_runtime_ready else R.string.workspace_runtime_missing),
            style = MaterialTheme.typography.bodySmall)
    }
}

private fun WorkspaceTab.labelResource(): Int = when(this) {
    WorkspaceTab.ADJUSTMENTS -> R.string.workspace_tab_adjustments
    WorkspaceTab.DETAIL -> R.string.workspace_tab_detail
    WorkspaceTab.GEOMETRY -> R.string.workspace_tab_geometry
    WorkspaceTab.SETTINGS -> R.string.workspace_tab_settings
}

private fun WorkspaceTab.iconResource(): Int = when(this) {
    WorkspaceTab.ADJUSTMENTS -> R.drawable.workspace_ic_adjust
    WorkspaceTab.DETAIL -> R.drawable.workspace_ic_detail
    WorkspaceTab.GEOMETRY -> R.drawable.workspace_ic_geometry
    WorkspaceTab.SETTINGS -> R.drawable.workspace_ic_info
}

private fun EditorState.Stage.workspaceLabelResource(): Int = when(this) {
    EditorState.Stage.COPYING -> R.string.stage_copying
    EditorState.Stage.DECODING -> R.string.stage_decoding
    EditorState.Stage.RENDERING -> R.string.stage_rendering
    EditorState.Stage.EDITING -> R.string.stage_editing
    EditorState.Stage.TONE_ADJUSTING -> R.string.tone_touch_updating
    EditorState.Stage.MASK_LOADING -> R.string.mask_photo_preparing
    EditorState.Stage.SAMPLING -> R.string.tone_touch_sampling
    EditorState.Stage.EXPORTING -> R.string.stage_exporting
    EditorState.Stage.CANCELLING -> R.string.stage_cancelling
}
