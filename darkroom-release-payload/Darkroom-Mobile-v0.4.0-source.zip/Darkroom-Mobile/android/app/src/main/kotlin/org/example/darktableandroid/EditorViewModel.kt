/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.provider.DocumentsContract
import androidx.lifecycle.AndroidViewModel
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.example.darktableandroid.nativecore.EditorModule
import org.example.darktableandroid.nativecore.EditHistory
import org.example.darktableandroid.nativecore.CurvePoint
import org.example.darktableandroid.nativecore.CropRect
import org.example.darktableandroid.nativecore.curveCoordinates
import org.example.darktableandroid.nativecore.ExportFormat
import org.example.darktableandroid.nativecore.ExportSettings
import org.example.darktableandroid.nativecore.NativeCore
import org.example.darktableandroid.nativecore.NativeDesktop
import org.example.darktableandroid.nativecore.NativeCatalog
import org.example.darktableandroid.storage.PhotoStyles
import org.example.darktableandroid.storage.PhotoStyle
import org.example.darktableandroid.storage.PhotoProjects
import org.example.darktableandroid.storage.PhotoProject
import org.example.darktableandroid.storage.ProjectSnapshot
import org.example.darktableandroid.storage.atomicWrite
import org.example.darktableandroid.storage.validatedDarktableXmp
import org.example.darktableandroid.nativecore.RuntimeAssets
import org.example.darktableandroid.nativecore.parseExportFormats
import org.example.darktableandroid.nativecore.parseEditHistory
import org.example.darktableandroid.nativecore.parseModules
import org.example.darktableandroid.nativecore.instanceSource
import org.example.darktableandroid.nativecore.retainModuleSelection
import org.example.darktableandroid.nativecore.previewArgbPixels
import org.example.darktableandroid.nativecore.accepts
import org.example.darktableandroid.nativecore.textParameterForWrite
import org.example.darktableandroid.nativecore.MaskPhotoPoints
import org.example.darktableandroid.nativecore.parseMaskPhotoPoints
import org.example.darktableandroid.storage.UriCache
import org.example.darktableandroid.storage.ToolAssetCache
import org.example.darktableandroid.storage.CatalogPhoto
import org.example.darktableandroid.storage.CatalogMarks
import org.example.darktableandroid.storage.CatalogIndex
import org.example.darktableandroid.storage.catalogPhoto
import org.example.darktableandroid.storage.BatchExports
import org.example.darktableandroid.storage.BatchExport

sealed interface EditorState {
    data object Empty : EditorState
    data class Working(val stage: Stage, val previous: Ready? = null) : EditorState
    data class Ready(
        val source: Uri,
        val sessionId: Long,
        val preview: Bitmap,
        val modules: List<EditorModule>,
        val exportFormats: List<ExportFormat>,
        val notice: String? = null,
        val history: EditHistory? = null,
        val selectedModule: String? = null,
        val toneSample: ToneEqualizerSample? = null,
        val previewCurrent: Boolean = true,
        val maskPhotoSelection: MaskPhotoSelection? = null,
        val projectId: String? = null,
        val comparison: Bitmap? = null,
    ) : EditorState
    data class Failed(val source: Uri?, val message: String) : EditorState
    enum class Stage { COPYING, DECODING, RENDERING, SAMPLING, MASK_LOADING, TONE_ADJUSTING, EDITING, EXPORTING, CANCELLING }
}

data class RuntimeAvailability(val checking: Boolean = true, val available: Boolean = false, val message: String? = null)

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val mutableState = MutableStateFlow<EditorState>(EditorState.Empty)
    val state: StateFlow<EditorState> = mutableState.asStateFlow()
    private val mutableRuntime = MutableStateFlow(RuntimeAvailability())
    val runtime: StateFlow<RuntimeAvailability> = mutableRuntime.asStateFlow()
    // A separate owner scope lets cleanup finish after Android clears the ViewModel.
    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val nativeDispatcher = Dispatchers.IO.limitedParallelism(1)
    private var work: Job? = null
    private var session: NativeSession? = null
    private var pendingSource: Uri? = null
    private var lastProject: PhotoProject? = null
    private val generation = AtomicLong(UUID.randomUUID().mostSignificantBits and Long.MAX_VALUE)
    private val toneSelections = AtomicLong()
    private val toneTargets = ToneAdjustmentQueue()
    private var toneWorker: Job? = null
    private val projectStore = PhotoProjects(File(application.filesDir, "photo-projects"))
    private val mutableProjects = MutableStateFlow<List<PhotoProject>>(emptyList())
    internal val projects = mutableProjects.asStateFlow()
    private val mutableCatalog = MutableStateFlow<List<CatalogPhoto>>(emptyList())
    private val catalogIndex = CatalogIndex()
    internal val photoCatalog = mutableCatalog.asStateFlow()
    private val mutableCatalogNotice = MutableStateFlow<String?>(null)
    internal val catalogNotice = mutableCatalogNotice.asStateFlow()
    private val batchStore = BatchExports(File(application.filesDir, "batch-exports"))
    private val mutableBatch = MutableStateFlow<List<BatchExport>>(emptyList())
    internal val batchExports = mutableBatch.asStateFlow()
    private var batchCancellation: BatchCancellation? = null
    private val mutableSnapshots = MutableStateFlow<List<ProjectSnapshot>>(emptyList())
    internal val snapshots = mutableSnapshots.asStateFlow()
    private var styleStore = PhotoStyles(File(application.filesDir, "photo-styles"))
    private val mutableStyles = MutableStateFlow<List<PhotoStyle>>(emptyList())
    internal val styles = mutableStyles.asStateFlow()

    init {
        engineScope.launch {
            val initialization = withContext(nativeDispatcher) {
                runCatching {
                    check(NativeCore.capabilities() and 1 != 0) {
                        getApplication<Application>().getString(R.string.engine_unavailable)
                    }
                    RuntimeAssets.initializeNative(getApplication())
                    NativeDesktop.ensureLoaded()
                    styleStore = PhotoStyles(File(getApplication<Application>().filesDir, "photo-styles"),
                        File(RuntimeAssets.prepare(getApplication()).dataDir, "styles"))
                    refreshProjects()
                    batchStore.recoverInterrupted()
                    File(getApplication<Application>().cacheDir, "batch-work").deleteRecursively()
                    mutableBatch.value = batchStore.list()
                    mutableStyles.value = styleStore.list()
                }
            }
            val available = initialization.isSuccess
            mutableRuntime.value = RuntimeAvailability(
                checking = false,
                available = available,
                message = initialization.exceptionOrNull()?.let(::errorMessage),
            )
            pendingSource?.let { pendingSource = null; if(available) open(it) }
        }
    }

    fun open(uri: Uri) = startOpen(uri)

    fun retry(uri: Uri) {
        val saved = lastProject?.takeIf { it.sourceUri == uri.toString() }
        if(saved != null) startOpen(uri, saved) else open(uri)
    }

    internal fun openProject(id: String) {
        val project = mutableProjects.value.singleOrNull { it.id == id } ?: return
        startOpen(Uri.parse(project.sourceUri), project)
    }

    private fun startOpen(uri: Uri, stored: PhotoProject? = null,
                          replacement: File? = null, replacementUri: Uri? = null, initialNotice: String? = null) {
        if(mutableRuntime.value.checking) { pendingSource = uri; return }
        if(!mutableRuntime.value.available) return
        lastProject = stored
        batchCancellation?.cancel()
        toneTargets.clear()
        val request = generation.incrementAndGet()
        val previousWork = work
        val previousSession = session
        session = null
        previousSession?.cancel()
        previousWork?.cancel()
        mutableState.value = EditorState.Working(EditorState.Stage.COPYING)
        work = engineScope.launch {
            var opened: NativeSession? = null
            var retained = false
            var rollback: Pair<File, ByteArray>? = null
            try {
                withContext(NonCancellable) { previousWork?.join() }
                ensureActive()
                val project = withContext(Dispatchers.IO) {
                    val current = stored?.let { projectStore.read(it.id) } ?: run {
                        val cached = UriCache(getApplication()).copyForNative(uri) { request != generation.get() }
                        projectStore.create(cached.file, uri.toString(), UriCache(getApplication()).sourceName(uri))
                    }
                    refreshProjects()
                    if(replacement != null || replacementUri != null) {
                        val bytes = if(replacement != null) replacement.readBytes() else
                            getApplication<Application>().contentResolver.openInputStream(checkNotNull(replacementUri)).use { input ->
                                checkNotNull(input) { "The document provider returned no XMP stream" }
                                // Read one byte past the limit, so oversized input is rejected rather than truncated.
                                input.takeBytes(16 * 1024 * 1024 + 1)
                            }
                        val validated = validatedDarktableXmp(bytes)
                        if(current.sidecar.exists()) {
                            rollback = current.sidecar to current.sidecar.readBytes()
                            projectStore.snapshot(current, getApplication<Application>().getString(R.string.desktop_before_restore))
                        }
                        atomicWrite(current.sidecar, validated)
                    }
                    current
                }
                ensureActive()
                if(request == generation.get()) lastProject = project
                mutableState.value = EditorState.Working(EditorState.Stage.DECODING)
                // Keep ownership of a returned handle even if cancellation happens during open.
                val active = withContext(NonCancellable) {
                    withContext(nativeDispatcher) { NativeSession(NativeCore.open(project.source.absolutePath), project) }
                }
                opened = active
                // Keep one runtime user through the handoff. Reinitializing the
                // desktop global type registry on every photo causes GLib warnings.
                nativeCleanup { previousSession?.close() }
                ensureActive()
                if(request != generation.get()) throw CancellationException()
                session = active
                mutableState.value = EditorState.Working(EditorState.Stage.RENDERING)
                val result = withContext(nativeDispatcher) {
                    val handle = active.handle()
                    NativeCatalog.restore(project.source.path, project.sidecar)
                    active.comparison = runCatching { android.graphics.BitmapFactory.decodeFile(
                        project.directory.resolve("comparison.png").path) }.getOrNull()
                    checkpoint(active, project.selectedModule)
                    val preview = render(handle)
                    saveThumbnail(active, preview)
                    EditorState.Ready(uri, request, preview, parseModules(NativeCore.listModules(handle)),
                        parseExportFormats(NativeCore.listExportFormats(handle)),
                        history = parseEditHistory(NativeCore.history(handle)), projectId = project.id,
                        selectedModule = project.selectedModule, notice = initialNotice, comparison = active.comparison)
                }
                ensureActive()
                if(request == generation.get()) {
                    retained = true
                    rollback = null
                    mutableState.value = result
                }
            } catch(_: CancellationException) {
                // The replacing request owns the screen.
            } catch(failure: Throwable) {
                if(request == generation.get()) mutableState.value = EditorState.Failed(uri, errorMessage(failure))
            } finally {
                nativeCleanup { previousSession?.close() }
                if(!retained || request != generation.get()) {
                    if(session === opened) session = null
                    nativeCleanup {
                        opened?.close()
                        rollback?.let { (file, bytes) -> atomicWrite(file, bytes) }
                    }
                }
            }
        }
    }

    fun setParameter(operation: String, parameter: String, value: Double) {
        if(!value.isFinite()) return
        edit { NativeCore.setParameter(it, operation, parameter, value) }
    }

    fun sampleToneEqualizer(operation: String, x: Float, y: Float, expectedSessionId: Long, expectedPreview: Bitmap) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(!current.previewCurrent || current.sessionId != expectedSessionId || current.preview !== expectedPreview ||
            !x.isFinite() || !y.isFinite() || x < 0f || x >= 1f || y < 0f || y >= 1f ||
            current.selectedModule != operation || operation.substringBefore('@') != "toneequal" ||
            current.modules.singleOrNull { it.operation == operation }?.enabled != true) return
        val active = session ?: return
        val request = generation.get()
        toneTargets.clear()
        mutableState.value = EditorState.Working(EditorState.Stage.SAMPLING,
            current.copy(toneSample = null, maskPhotoSelection = null))
        work = engineScope.launch {
            try {
                val (exposure, output) = withContext(nativeDispatcher) {
                    val handle = active.handle()
                    val input = NativeCore.sampleToneEqualizer(handle, operation, x.toDouble(), y.toDouble())
                    input to NativeCore.toneEqualizerOutput(handle, operation, input)
                }
                check(exposure.isFinite() && output.isFinite()) { "The selected area has no usable tone exposure" }
                if(request == generation.get()) {
                    val selection = toneSelections.incrementAndGet()
                    toneTargets.reset(selection)
                    mutableState.value = current.copy(notice = null, maskPhotoSelection = null,
                        toneSample = ToneEqualizerSample(current.sessionId, operation, current.preview, x, y, exposure,
                            selectionId = selection, selectedExposure = output))
                }
            } catch(_: CancellationException) {
            } catch(failure: Throwable) {
                if(request == generation.get()) mutableState.value = current.copy(toneSample = null, notice = errorMessage(failure))
            }
        }
    }

    private fun toneReady(): EditorState.Ready? = when(val current = mutableState.value) {
        is EditorState.Ready -> current
        is EditorState.Working -> current.previous.takeIf { current.stage == EditorState.Stage.TONE_ADJUSTING }
        else -> null
    }

    fun adjustToneEqualizer(sample: ToneEqualizerSample, target: Double, gesture: Long, finished: Boolean) {
        val current = toneReady() ?: return
        val selected = current.toneSample ?: return
        // The selection survives its own preview updates. Other image/tool/mask
        // changes revoke it, so an old gesture cannot affect another selection.
        if(!current.previewCurrent || selected.selectionId != sample.selectionId || sample.sessionId != current.sessionId ||
            current.selectedModule != sample.module || sample.module.substringBefore('@') != "toneequal" ||
            selected.module != sample.module || selected.exposure != sample.exposure ||
            current.modules.singleOrNull { it.operation == sample.module }?.enabled != true ||
            !sample.exposure.isFinite() || !target.isFinite() || target < sample.exposure - 2 || target > sample.exposure + 2 ||
            gesture <= 0) return
        val active = session ?: return
        if(!toneTargets.offer(selected.selectionId, target, gesture, finished)) return
        mutableState.value = EditorState.Working(EditorState.Stage.TONE_ADJUSTING,
            current.copy(toneSample = selected.copy(pendingExposure = toneTargets.pendingTarget), notice = null))
        if(toneWorker?.isActive == true) return
        val requestGeneration = generation.get()
        val worker = engineScope.launch {
            while(requestGeneration == generation.get()) {
                val request = toneTargets.take() ?: break
                val before = toneReady() ?: break
                val point = before.toneSample?.takeIf { it.selectionId == request.selectionId } ?: break
                var changed = false
                try {
                    val updated = withContext(nativeDispatcher) {
                        val handle = active.handle()
                        val output = NativeCore.setToneEqualizerTarget(handle, point.module, point.exposure,
                            request.target, request.gestureId)
                        changed = true
                        checkpoint(active, point.module)
                        check(output.isFinite()) { "The tone adjustment produced an invalid exposure" }
                        val modules = parseModules(NativeCore.listModules(handle))
                        val preview = render(handle)
                        before.copy(preview = preview, previewCurrent = true, modules = modules,
                            history = parseEditHistory(NativeCore.history(handle)), notice = null,
                            toneSample = point.copy(preview = preview, selectedExposure = output,
                                pendingExposure = null, feedbackRevision = request.sequence))
                    }
                    if(requestGeneration != generation.get()) break
                    if(!toneTargets.complete(request)) break
                    val ready = updated.copy(toneSample = updated.toneSample?.copy(pendingExposure = toneTargets.pendingTarget))
                    mutableState.value = if(toneTargets.hasPending)
                        EditorState.Working(EditorState.Stage.TONE_ADJUSTING, ready) else ready
                } catch(_: CancellationException) {
                    break
                } catch(failure: Throwable) {
                    if(requestGeneration == generation.get()) {
                        toneTargets.clear()
                        val recovered = withContext(nativeDispatcher) {
                            runCatching {
                                val handle = active.handle()
                                val modules = parseModules(NativeCore.listModules(handle))
                                val output = NativeCore.toneEqualizerOutput(handle, point.module, point.exposure)
                                before.copy(modules = modules, history = parseEditHistory(NativeCore.history(handle)),
                                    previewCurrent = before.previewCurrent && !changed,
                                    toneSample = point.takeUnless { changed }?.copy(selectedExposure = output,
                                        pendingExposure = null, feedbackRevision = request.sequence))
                            }.getOrElse { before.copy(history = null, toneSample = null,
                                previewCurrent = before.previewCurrent && !changed) }
                        }
                        recovered.toneSample?.let { toneTargets.reset(it.selectionId) }
                        mutableState.value = recovered.copy(notice = errorMessage(failure))
                    }
                    break
                }
            }
        }
        toneWorker = worker
        work = worker
    }

    fun setModuleEnabled(operation: String, enabled: Boolean) {
        edit { NativeCore.setModuleEnabled(it, operation, enabled) }
    }

    fun loadMaskPhoto(operation: String, expectedSessionId: Long, expectedPreview: Bitmap) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(!current.previewCurrent || current.sessionId != expectedSessionId || current.preview !== expectedPreview ||
            current.selectedModule != operation || current.modules.singleOrNull { it.operation == operation }?.enabled != true) return
        val active = session ?: return
        val request = generation.get()
        toneTargets.clear()
        mutableState.value = EditorState.Working(EditorState.Stage.MASK_LOADING,
            current.copy(toneSample = null, maskPhotoSelection = null))
        work = engineScope.launch {
            try {
                val points = withContext(nativeDispatcher) {
                    checkNotNull(parseMaskPhotoPoints(NativeCore.maskPhotoPoints(active.handle(), operation))) {
                        "The native mask positions are invalid"
                    }
                }
                if(request == generation.get()) mutableState.value = current.copy(toneSample = null, notice = null,
                    maskPhotoSelection = MaskPhotoSelection(current.sessionId, operation, current.preview, points))
            } catch(_: CancellationException) {
            } catch(failure: Throwable) {
                if(request == generation.get()) mutableState.value = current.copy(toneSample = null,
                    maskPhotoSelection = MaskPhotoSelection(current.sessionId, operation, current.preview, MaskPhotoPoints(emptyList())),
                    notice = errorMessage(failure))
            }
        }
    }

    fun placeMaskPhoto(target: MaskPhotoTarget, x: Float, y: Float) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val selection = current.maskPhotoSelection ?: return
        if(!current.previewCurrent || target.sessionId != current.sessionId || target.preview !== current.preview ||
            target.module != current.selectedModule || selection.module != target.module ||
            selection.sessionId != target.sessionId || selection.preview !== target.preview ||
            !x.isFinite() || !y.isFinite() || x < 0f || x >= 1f || y < 0f || y >= 1f ||
            current.modules.singleOrNull { it.operation == target.module }?.enabled != true) return
        val form = selection.points.forms.singleOrNull { it.id == target.formId } ?: return
        if((if(target.source) form.source else form.center) == null) return
        editWithSelection(retainMaskPhotoModule = target.module) { handle ->
            NativeCore.placeMaskPhoto(handle, target.module, target.formId, target.source, x.toDouble(), y.toDouble())
            null
        }
    }

    fun setTextParameter(operation: String, parameter: String, value: String) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val control = current.modules.singleOrNull { it.operation == operation }
            ?.textParameterForWrite(parameter, value) ?: return
        if(control.accepts(value)) edit { NativeCore.setTextParameter(it, operation, parameter, value) }
    }

    fun importToolFile(operation: String, parameter: String, uri: Uri, expectedSessionId: Long) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(current.sessionId != expectedSessionId) return
        val active = session ?: return
        val control = current.modules.singleOrNull { it.operation == operation }
            ?.textParameters?.singleOrNull { it.name == parameter && it.isFile } ?: return
        val request = generation.get()
        edit { handle ->
            val file = ToolAssetCache(getApplication()).copyForNative(uri, active.assetsDirectory, control.extensions) {
                request != generation.get()
            }
            check(request == generation.get()) { "The image changed during file import" }
            check(control.accepts(file.absolutePath)) { "The imported file path exceeds the native tool buffer" }
            NativeCore.setTextParameter(handle, operation, parameter, file.absolutePath)
        }
    }

    fun selectModule(operation: String?) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val selected = retainModuleSelection(current.modules, operation)
        if(operation != null && selected == null) return
        if(selected != current.selectedModule) toneTargets.clear()
        mutableState.value = current.copy(selectedModule = selected,
            maskPhotoSelection = current.maskPhotoSelection.takeIf { selected == current.selectedModule },
            toneSample = current.toneSample.takeIf { selected == current.selectedModule })
    }

    fun newInstance(operation: String) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(current.modules.instanceSource(operation) == null) return
        editWithSelection { NativeCore.newInstance(it, operation) }
    }

    fun setCurve(operation: String, channel: Int, interpolation: Int, nodes: List<CurvePoint>) {
        val coordinates = curveCoordinates(nodes)
        edit { NativeCore.setCurve(it, operation, channel, interpolation, coordinates) }
    }

    fun setCrop(operation: String, bounds: CropRect) {
        edit { NativeCore.setCrop(it, operation, bounds.left, bounds.top, bounds.right, bounds.bottom) }
    }

    fun setRgbCurveOptions(operation: String, mode: Int, preserveColors: Int) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val options = current.modules.firstOrNull { it.operation == operation }?.rgbCurveOptions ?: return
        if(options.accepts(mode, preserveColors)) edit { NativeCore.setRgbCurveOptions(it, operation, mode, preserveColors) }
    }

    fun setWhiteBalanceGains(operation: String, gains: FloatArray) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val balance = current.modules.firstOrNull { it.operation == operation }?.whiteBalance ?: return
        val captured = gains.copyOf()
        if(balance.acceptsGains(captured)) edit { NativeCore.setWhiteBalanceGains(it, operation, captured) }
    }

    fun setWhiteBalanceSetting(operation: String, setting: Int) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val balance = current.modules.firstOrNull { it.operation == operation }?.whiteBalance ?: return
        if(balance.acceptsSetting(setting)) edit { NativeCore.setWhiteBalanceSetting(it, operation, setting) }
    }

    fun setWhiteBalancePreset(operation: String, preset: Int, tuning: Int) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val balance = current.modules.singleOrNull { it.operation == operation }?.whiteBalance ?: return
        if(balance.acceptsPreset(preset, tuning)) edit { NativeCore.setWhiteBalancePreset(it, operation, preset, tuning) }
    }

    fun setWhiteBalanceTemperature(operation: String, kelvin: Double, tint: Double) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val temperature = current.modules.firstOrNull { it.operation == operation }?.whiteBalance?.temperature ?: return
        if(temperature.accepts(kelvin, tint)) edit { NativeCore.setWhiteBalanceTemperature(it, operation, kelvin, tint) }
    }

    fun undo() {
        if((mutableState.value as? EditorState.Ready)?.history?.canUndo != true) return
        edit { NativeCore.undo(it) }
    }

    fun redo() {
        if((mutableState.value as? EditorState.Ready)?.history?.canRedo != true) return
        edit { NativeCore.redo(it) }
    }

    internal fun moveHistory(position: Int) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val history = current.history ?: return
        if(position !in 0..history.length || position == history.position) return
        edit { handle ->
            repeat(kotlin.math.abs(position - history.position)) {
                if(position < history.position) NativeCore.undo(handle) else NativeCore.redo(handle)
            }
        }
    }

    fun refreshPreview() = editWithSelection(changesNativeState = false) { null }

    private fun edit(change: (Long) -> Unit) = editWithSelection { handle -> change(handle); null }

    private fun editWithSelection(changesNativeState: Boolean = true, retainMaskPhotoModule: String? = null,
                                  change: (Long) -> String?) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val currentSession = session ?: return
        toneTargets.clear()
        val request = generation.get()
        mutableState.value = EditorState.Working(EditorState.Stage.EDITING, current)
        work = engineScope.launch {
            var preferredSelection: String? = null
            var changed = false
            try {
                val updated = withContext(nativeDispatcher) {
                    val handle = currentSession.handle()
                    preferredSelection = change(handle)
                    changed = changesNativeState
                    // A previous edit can commit before a failed disk checkpoint.
                    // Refresh must retry saving that state before clearing its error.
                    checkpoint(currentSession, preferredSelection ?: current.selectedModule)
                    val modules = parseModules(NativeCore.listModules(handle))
                    val preview = render(handle)
                    saveThumbnail(currentSession, preview)
                    val maskSelection = retainMaskPhotoModule?.let { operation ->
                        runCatching {
                            parseMaskPhotoPoints(NativeCore.maskPhotoPoints(handle, operation))?.let { points ->
                                MaskPhotoSelection(current.sessionId, operation, preview, points)
                            }
                        }.getOrNull()
                    }
                    current.copy(preview = preview, previewCurrent = true, modules = modules,
                        comparison = currentSession.comparison, toneSample = null, maskPhotoSelection = maskSelection,
                        history = parseEditHistory(NativeCore.history(handle)), notice = null,
                        selectedModule = retainModuleSelection(modules, preferredSelection ?: current.selectedModule))
                }
                if(request == generation.get()) mutableState.value = updated
            } catch(_: CancellationException) {
            } catch(failure: Throwable) {
                if(request == generation.get()) {
                    // A native edit may have committed before preview rendering failed.
                    // Keep history controls and tool values aligned with that session.
                    val recovered = withContext(nativeDispatcher) {
                        runCatching {
                            val handle = currentSession.handle()
                            val modules = parseModules(NativeCore.listModules(handle))
                            current.copy(modules = modules, history = parseEditHistory(NativeCore.history(handle)),
                                maskPhotoSelection = current.maskPhotoSelection.takeUnless { changed },
                                toneSample = current.toneSample.takeUnless { changed },
                                previewCurrent = current.previewCurrent && !changed,
                                selectedModule = retainModuleSelection(modules, preferredSelection ?: current.selectedModule))
                        }.getOrElse { current.copy(history = null, toneSample = current.toneSample.takeUnless { changed },
                            maskPhotoSelection = current.maskPhotoSelection.takeUnless { changed },
                            previewCurrent = current.previewCurrent && !changed) }
                    }
                    if(request == generation.get()) {
                        recovered.toneSample?.let { toneTargets.reset(it.selectionId) }
                        mutableState.value = recovered.copy(notice = errorMessage(failure))
                    }
                }
            }
        }
    }

    /** target must be the new document returned by this app's ACTION_CREATE_DOCUMENT request. */
    fun export(target: Uri, format: ExportFormat, quality: Int, expectedSessionId: Long, expectedSource: Uri) =
        export(target, format, quality, null, false, expectedSessionId, expectedSource)

    /** Decode now so a caller cannot mutate settings while the export job is queued. */
    fun export(target: Uri, format: ExportFormat, settings: IntArray, expectedSessionId: Long, expectedSource: Uri) =
        export(target, format, 95, ExportSettings.fromNativeArray(settings), true, expectedSessionId, expectedSource)

    private fun export(target: Uri, format: ExportFormat, quality: Int, settings: ExportSettings?,
                       extended: Boolean, expectedSessionId: Long, expectedSource: Uri) {
        val current = mutableState.value as? EditorState.Ready
        val currentSession = session
        if(target == expectedSource || target == current?.source) {
            if(current != null) mutableState.value = current.copy(
                notice = getApplication<Application>().getString(R.string.source_overwrite))
            return
        }
        if(current == null || currentSession == null || current.sessionId != expectedSessionId || current.source != expectedSource) {
            engineScope.launch { removeNewExport(target) }
            if(current != null) mutableState.value = current.copy(
                notice = getApplication<Application>().getString(R.string.export_source_changed))
            return
        }
        val request = generation.get()
        mutableState.value = EditorState.Working(EditorState.Stage.EXPORTING, current)
        work = engineScope.launch {
            var temporary: File? = null
            var committed = false
            try {
                withContext(nativeDispatcher) {
                    // Reuse the current session's advertised encoder, not metadata reconstructed
                    // after a document-picker or activity recreation.
                    val installed = checkNotNull(current.exportFormats.firstOrNull { it.id == format.id }) {
                        "The selected export format is unavailable"
                    }
                    if(extended) check(settings != null && installed.options?.isValid(settings) == true) {
                        "The selected export settings are unavailable"
                    }
                    val extension = installed.extension.filter(Char::isLetterOrDigit).take(12).ifEmpty { "export" }
                    temporary = File.createTempFile("darktable-export-", ".$extension", getApplication<Application>().cacheDir)
                    if(extended) NativeCore.exportWithSettings(currentSession.handle(), temporary!!.absolutePath,
                        installed.id, checkNotNull(settings).toNativeArray())
                    else NativeCore.exportImage(currentSession.handle(), temporary!!.absolutePath,
                        installed.id, quality.coerceIn(0, 100))
                    ensureActive()
                    check(temporary!!.length() > 0L) { "The export encoder produced an empty file" }
                    getApplication<Application>().contentResolver.openOutputStream(target, "wt").use { output ->
                        checkNotNull(output) { "The document provider returned no output stream" }
                        temporary!!.inputStream().buffered().use { input ->
                            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                            while(true) {
                                ensureActive()
                                val count = input.read(buffer)
                                if(count < 0) break
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                    committed = true
                }
                if(request == generation.get()) mutableState.value = current.copy(
                    notice = getApplication<Application>().getString(R.string.export_complete))
            } catch(_: CancellationException) {
            } catch(failure: Throwable) {
                if(request == generation.get()) mutableState.value = current.copy(notice = errorMessage(failure))
            } finally {
                withContext(NonCancellable + Dispatchers.IO) { temporary?.delete() }
                if(!committed) removeNewExport(target)
            }
        }
    }

    private suspend fun removeNewExport(target: Uri) = withContext(NonCancellable + Dispatchers.IO) {
        // Providers can reject deletion; never attempt to delete a source or any unrelated document.
        runCatching { DocumentsContract.deleteDocument(getApplication<Application>().contentResolver, target) }
        Unit
    }

    fun cancel(showState: Boolean = true) {
        batchCancellation?.let {
            it.cancel()
            // Stop keeps the editor alive; ViewModel destruction must still
            // join the worker and release its retained native runtime user.
            if(showState) { work?.cancel(); return }
        }
        pendingSource = null
        toneTargets.clear()
        val request = generation.incrementAndGet()
        val previousWork = work
        val previousSession = session
        session = null
        previousSession?.cancel()
        previousWork?.cancel()
        if(showState) mutableState.value = EditorState.Working(EditorState.Stage.CANCELLING)
        work = engineScope.launch {
            releaseAfter(previousWork, previousSession)
            if(showState && request == generation.get()) mutableState.value = EditorState.Empty
        }
    }

    private fun saveThumbnail(active: NativeSession, bitmap: Bitmap) {
        // A thumbnail is expendable; the original and native XMP checkpoint are not.
        runCatching {
            val scale = minOf(1f, 320f / maxOf(bitmap.width, bitmap.height))
            val thumbnail = Bitmap.createScaledBitmap(bitmap,
                (bitmap.width * scale).toInt().coerceAtLeast(1),
                (bitmap.height * scale).toInt().coerceAtLeast(1), true)
            val bytes = java.io.ByteArrayOutputStream()
            check(thumbnail.compress(Bitmap.CompressFormat.JPEG, 80, bytes))
            atomicWrite(active.project.thumbnail, bytes.toByteArray())
            if(thumbnail !== bitmap) thumbnail.recycle()
        }
    }

    /** Native history is already committed before this original XMP serializer runs. */
    private fun checkpoint(active: NativeSession, selected: String?) {
        val project = active.project
        val incoming = File.createTempFile(".history-", ".xmp.part", project.directory)
        try {
            NativeDesktop.writeSidecar(project.source.absolutePath, incoming.absolutePath)
            check(incoming.length() > 0) { "The native XMP writer produced an empty sidecar" }
            java.io.RandomAccessFile(incoming, "rw").use { it.fd.sync() }
            check(incoming.renameTo(project.sidecar)) { "Unable to commit the XMP history" }
            projectStore.update(projectStore.read(project.id), selected)
            refreshProjects(project.id)
            mutableSnapshots.value = projectStore.snapshots(project)
        } finally { incoming.delete() }
    }

    @Synchronized private fun refreshProjects(invalidated: String? = null) {
        mutableProjects.value = projectStore.list()
        mutableCatalog.value = catalogIndex.refresh(mutableProjects.value, invalidated)
    }

    internal fun setCatalogMarks(marks: CatalogMarks) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val active = session ?: return
        editWithSelection(changesNativeState = false) {
            checkpoint(active, current.selectedModule)
            projectStore.snapshot(active.project, getApplication<Application>().getString(R.string.catalog_marks))
            NativeDesktop.setCatalogMarks(active.project.source.path, marks.rating, marks.colors, marks.tags.toTypedArray())
            null
        }
    }

    internal fun importPhotographs(uris: List<Uri>) {
        if(mutableState.value is EditorState.Working || !mutableRuntime.value.available || uris.isEmpty()) return
        val current = mutableState.value as? EditorState.Ready
        val request = generation.get()
        mutableState.value = EditorState.Working(EditorState.Stage.COPYING, current)
        work = engineScope.launch {
            val failures = mutableListOf<String>()
            var copied = 0
            try {
                withContext(Dispatchers.IO) {
                    val copyContext = kotlin.coroutines.coroutineContext
                    for(uri in uris.distinct()) {
                        ensureActive()
                        try {
                            val cache = UriCache(getApplication())
                            cache.retainPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            val original = cache.copyForNative(uri) { copyContext[Job]?.isActive == false }
                            projectStore.create(original.file, uri.toString(), cache.sourceName(uri))
                            copied++
                        } catch(failure: CancellationException) { throw failure }
                        catch(failure: Exception) { failures += errorMessage(failure) }
                    }
                }
            } finally {
                withContext(NonCancellable + Dispatchers.IO) { refreshProjects() }
                if(request == generation.get()) {
                    val notice = getApplication<Application>().getString(R.string.catalog_import_result, copied, failures.size) +
                        failures.firstOrNull()?.let { "\n$it" }.orEmpty()
                    mutableCatalogNotice.value = notice
                    mutableState.value = current?.copy(notice = notice) ?: EditorState.Empty
                }
            }
        }
    }

    internal fun enqueueBatch(ids: List<String>, tree: Uri, format: ExportFormat, settings: ExportSettings) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(ids.isEmpty() || batchCancellation != null) return
        val installed = current.exportFormats.singleOrNull { it.id == format.id } ?: return
        if(installed.options != null && !installed.options.isValid(settings)) return
        val request = generation.get()
        mutableState.value = EditorState.Working(EditorState.Stage.EXPORTING, current)
        work = engineScope.launch {
            try {
                withContext(nativeDispatcher) {
                    checkpoint(checkNotNull(session), current.selectedModule)
                    for(id in ids.distinct()) batchStore.enqueue(projectStore.read(id), installed.id,
                        installed.extension, installed.mimeType, settings, installed.options != null, tree.toString())
                    mutableBatch.value = batchStore.list()
                }
                ensureActive()
                if(request == generation.get()) { mutableState.value = current; runBatch() }
            } catch(_: CancellationException) {
            } catch(failure: Exception) {
                mutableBatch.value = batchStore.list()
                if(request == generation.get()) mutableState.value = current.copy(notice = errorMessage(failure))
            }
        }
    }

    internal fun retryBatch(id: String) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val request = generation.get()
        mutableState.value = EditorState.Working(EditorState.Stage.EDITING, current)
        work = engineScope.launch {
            var notice: String? = null
            try {
                withContext(nativeDispatcher) {
                    batchStore.recoverInterrupted()
                    batchStore.retry(id)
                    mutableBatch.value = batchStore.list()
                }
            } catch(_: CancellationException) {
            } catch(failure: Exception) {
                notice = errorMessage(failure)
            } finally {
                if(request == generation.get()) mutableState.value = current.copy(notice = notice)
            }
        }
    }

    internal fun runBatch() {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(batchCancellation != null || mutableBatch.value.none { it.status == org.example.darktableandroid.storage.BatchStatus.PENDING }) return
        val cancellation = BatchCancellation()
        batchCancellation = cancellation
        val request = generation.get()
        mutableState.value = EditorState.Working(EditorState.Stage.EXPORTING, current)
        work = engineScope.launch {
            var failureNotice: String? = null
            try {
                withContext(nativeDispatcher) {
                    batchStore.runPending({ cancellation.cancelled }, { mutableBatch.value = batchStore.list() }) { job ->
                        exportBatchItem(job, cancellation)
                    }
                }
            } catch(_: CancellationException) {
            } catch(failure: Exception) {
                failureNotice = errorMessage(failure)
            } finally {
                withContext(NonCancellable + Dispatchers.IO) {
                    runCatching { batchStore.recoverInterrupted() }
                    mutableBatch.value = batchStore.list().map { job ->
                        if(job.status == org.example.darktableandroid.storage.BatchStatus.RUNNING)
                            job.copy(status = org.example.darktableandroid.storage.BatchStatus.INTERRUPTED, error = failureNotice)
                        else job
                    }
                }
                batchCancellation = null
                if(request == generation.get()) mutableState.value = current.copy(notice = failureNotice)
            }
        }
    }

    private fun exportBatchItem(job: BatchExport, cancellation: BatchCancellation): String {
        val project = projectStore.read(job.projectId)
        val scratch = File(getApplication<Application>().cacheDir, "batch-work/${UUID.randomUUID()}")
        check(scratch.mkdirs())
        var handle = 0L
        try {
            check(!cancellation.cancelled) { "Export stopped" }
            val source = scratch.resolve(project.source.name)
            project.source.inputStream().use { input -> source.outputStream().use { output ->
                val buffer = ByteArray(128 * 1024)
                while(true) {
                    check(!cancellation.cancelled) { "Export stopped" }
                    val count = input.read(buffer); if(count < 0) break
                    output.write(buffer, 0, count)
                }
            } }
            batchStore.history(job)?.copyTo(File(source.path + ".xmp"))
            handle = NativeCore.open(source.path)
            cancellation.attach(handle)
            NativeCatalog.restore(source.path, File(source.path + ".xmp"))
            val installed = parseExportFormats(NativeCore.listExportFormats(handle)).single { it.id == job.format }
            val output = scratch.resolve("output.${job.extension}")
            if(job.extended) {
                check(installed.options?.isValid(job.settings) == true) { "Queued encoder settings are unavailable" }
                NativeCore.exportWithSettings(handle, output.path, job.format, job.settings.toNativeArray())
            } else NativeCore.exportImage(handle, output.path, job.format, job.settings.quality)
            check(!cancellation.cancelled && output.length() > 0) { "Export stopped or produced an empty file" }
            val resolver = getApplication<Application>().contentResolver
            val tree = Uri.parse(job.tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val stem = job.name.substringBeforeLast('.').replace(Regex("[^\\p{L}\\p{N}_-]"), "_").take(64).ifBlank { "photo" }
            val target = checkNotNull(DocumentsContract.createDocument(resolver, parent, job.mime,
                "$stem-${UUID.randomUUID()}.${job.extension}")) { "Cannot create the exported document" }
            var committed = false
            try {
                resolver.openOutputStream(target, "wt").use { destination ->
                    checkNotNull(destination)
                    output.inputStream().use { input ->
                        val buffer = ByteArray(128 * 1024)
                        while(true) {
                            check(!cancellation.cancelled) { "Export stopped" }
                            val count = input.read(buffer); if(count < 0) break
                            destination.write(buffer, 0, count)
                        }
                    }
                }
                fun digest(input: java.io.InputStream): ByteArray = input.use {
                    val sha = java.security.MessageDigest.getInstance("SHA-256")
                    val buffer = ByteArray(128 * 1024)
                    while(true) {
                        check(!cancellation.cancelled) { "Export stopped" }
                        val count = it.read(buffer); if(count < 0) break
                        sha.update(buffer, 0, count)
                    }
                    sha.digest()
                }
                val verified = digest(checkNotNull(resolver.openInputStream(target)))
                check(verified.contentEquals(digest(output.inputStream()))) { "The document provider saved an incomplete file" }
                committed = true
                return target.toString()
            } finally { if(!committed) runCatching { DocumentsContract.deleteDocument(resolver, target) } }
        } finally {
            cancellation.detach()
            if(handle != 0L) NativeCore.close(handle)
            scratch.deleteRecursively()
        }
    }

    internal fun pinComparison() {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(!current.previewCurrent) return
        val active = session ?: return
        editWithSelection(changesNativeState = false) {
            val output = java.io.ByteArrayOutputStream()
            check(current.preview.compress(Bitmap.CompressFormat.PNG, 100, output))
            atomicWrite(active.project.directory.resolve("comparison.png"), output.toByteArray())
            active.comparison = current.preview
            null
        }
    }

    internal fun saveSnapshot(name: String) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val active = session ?: return
        editWithSelection(changesNativeState = false) {
            checkpoint(active, current.selectedModule)
            projectStore.snapshot(active.project, name.ifBlank {
                getApplication<Application>().getString(R.string.desktop_snapshot_default)
            })
            mutableSnapshots.value = projectStore.snapshots(active.project)
            null
        }
    }

    internal fun restoreSnapshot(id: String) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val active = session ?: return
        val snapshot = mutableSnapshots.value.singleOrNull { it.id == id } ?: return
        startOpen(current.source, active.project, replacement = snapshot.sidecar)
    }

    internal fun importXmp(uri: Uri, expectedSessionId: Long) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(current.sessionId != expectedSessionId) return
        val active = session ?: return
        startOpen(current.source, active.project, replacementUri = uri)
    }

    internal fun importStyle(uri: Uri, expectedSessionId: Long) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(current.sessionId != expectedSessionId) return
        editWithSelection(changesNativeState = false) {
            val bytes = getApplication<Application>().contentResolver.openInputStream(uri).use { input ->
                checkNotNull(input).takeBytes(16 * 1024 * 1024 + 1)
            }
            styleStore.retain(bytes)
            mutableStyles.value = styleStore.list()
            null
        }
    }

    internal fun saveStyle(name: String) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val active = session ?: return
        val title = name.trim().ifBlank { getApplication<Application>().getString(R.string.desktop_style_default) }
        if(title.toByteArray(Charsets.UTF_8).size > 160) return
        editWithSelection(changesNativeState = false) {
            checkpoint(active, current.selectedModule)
            val directory = File(getApplication<Application>().cacheDir, "style-${UUID.randomUUID()}")
            check(directory.mkdirs())
            try {
                NativeDesktop.exportStyle(active.project.source.path, directory.path, title)
                val file = directory.listFiles().orEmpty().single { it.extension == "dtstyle" }
                styleStore.retain(file.readBytes())
                mutableStyles.value = styleStore.list()
            } finally { directory.deleteRecursively() }
            null
        }
    }

    internal fun applyStyle(id: String, overwrite: Boolean) {
        val current = mutableState.value as? EditorState.Ready ?: return
        val active = session ?: return
        val style = mutableStyles.value.singleOrNull { it.id == id } ?: return
        val missing = style.operations - current.modules.map { it.operation.substringBefore('@') }.toSet() - "mask_manager"
        if(missing.isNotEmpty()) {
            mutableState.value = current.copy(notice = getApplication<Application>().getString(
                R.string.desktop_style_missing, missing.sorted().joinToString()))
            return
        }
        val request = generation.get()
        toneTargets.clear()
        mutableState.value = EditorState.Working(EditorState.Stage.EDITING, current)
        work = engineScope.launch {
            var failure: String? = null
            withContext(NonCancellable + nativeDispatcher) {
                var incoming: File? = null
                try {
                    val target = File.createTempFile(".style-", ".xmp", active.project.directory)
                    incoming = target
                    checkpoint(active, current.selectedModule)
                    projectStore.snapshot(active.project, getApplication<Application>().getString(R.string.desktop_before_style))
                    NativeDesktop.writeStyledSidecar(active.project.source.path, style.file.path, style.name,
                        target.path, overwrite)
                    val xmp = validatedDarktableXmp(target.readBytes())
                    if(request == generation.get()) atomicWrite(active.project.sidecar, xmp)
                } catch(error: Throwable) { failure = errorMessage(error) }
                finally {
                    incoming?.delete()
                    // The style API updates the original database. The replacement
                    // context reloads the saved XMP before retiring this context.
                    // No user-visible render uses the old context after this point.
                }
            }
            if(request == generation.get()) startOpen(current.source, active.project, initialNotice = failure)
        }
    }

    internal fun exportStoredStyle(id: String, target: Uri, expectedSessionId: Long) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(current.sessionId != expectedSessionId || target == current.source) return
        val style = mutableStyles.value.singleOrNull { it.id == id } ?: return
        val request = generation.get()
        mutableState.value = EditorState.Working(EditorState.Stage.EXPORTING, current)
        work = engineScope.launch {
            var committed = false
            try {
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openOutputStream(target, "wt").use { output ->
                        checkNotNull(output) { "The document provider returned no output stream" }
                        style.file.inputStream().use { it.copyTo(output) }
                    }
                    committed = true
                }
                if(request == generation.get()) mutableState.value = current.copy(
                    notice = getApplication<Application>().getString(R.string.desktop_style_exported))
            } catch(error: Throwable) {
                if(error !is CancellationException && request == generation.get())
                    mutableState.value = current.copy(notice = errorMessage(error))
            } finally { if(!committed) removeNewExport(target) }
        }
    }

    internal fun exportXmp(target: Uri, expectedSessionId: Long) {
        val current = mutableState.value as? EditorState.Ready ?: return
        if(current.sessionId != expectedSessionId || target == current.source) return
        val active = session ?: return
        val request = generation.get()
        mutableState.value = EditorState.Working(EditorState.Stage.EXPORTING, current)
        work = engineScope.launch {
            var committed = false
            try {
                withContext(nativeDispatcher) {
                    checkpoint(active, current.selectedModule)
                    getApplication<Application>().contentResolver.openOutputStream(target, "wt").use { output ->
                        checkNotNull(output) { "The document provider returned no output stream" }
                        active.project.sidecar.inputStream().use { it.copyTo(output) }
                    }
                    committed = true
                }
                if(request == generation.get()) mutableState.value = current.copy(
                    notice = getApplication<Application>().getString(R.string.desktop_xmp_exported))
            } catch(failure: Throwable) {
                if(failure !is CancellationException && request == generation.get())
                    mutableState.value = current.copy(notice = errorMessage(failure))
            } finally { if(!committed) removeNewExport(target) }
        }
    }

    private fun render(handle: Long): Bitmap {
        val dimensions = IntArray(2)
        val rgba = NativeCore.renderPreview(handle, 2048, 2048, dimensions)
        val width = dimensions[0]
        val height = dimensions[1]
        check(width in 1..2048 && height in 1..2048 && rgba.size.toLong() == width.toLong() * height * 4) {
            "The native renderer returned invalid preview dimensions"
        }
        return Bitmap.createBitmap(previewArgbPixels(rgba), width, height, Bitmap.Config.ARGB_8888)
    }

    private suspend fun releaseAfter(previousWork: Job?, previousSession: NativeSession?) = withContext(NonCancellable) {
        previousWork?.join()
        withContext(nativeDispatcher) { previousSession?.close() }
    }

    private suspend fun nativeCleanup(block: () -> Unit) = withContext(NonCancellable) {
        withContext(nativeDispatcher) { block() }
    }

    private fun errorMessage(failure: Throwable) = failure.message ?: getApplication<Application>().getString(R.string.operation_failed)

    override fun onCleared() {
        cancel(false)
        work?.invokeOnCompletion { engineScope.cancel() }
        super.onCleared()
    }
}

/** Only the owning job uses the handle; close waits for that job to finish. */
private class NativeSession(private var pointer: Long, val project: PhotoProject) {
    val assetsDirectory get() = project.assets
    var comparison: Bitmap? = null
    init { check(pointer != 0L) { "The native engine returned an invalid session" } }
    @Synchronized fun handle(): Long = pointer.also { check(it != 0L) { "The image session is closed" } }
    @Synchronized fun cancel() { if(pointer != 0L) NativeCore.cancel(pointer) }
    @Synchronized fun close() {
        if(pointer != 0L) {
            val closing = pointer
            pointer = 0L
            NativeCore.close(closing)
        }
    }
}

private class BatchCancellation {
    @Volatile var cancelled = false
        private set
    private var handle = 0L
    @Synchronized fun attach(value: Long) { handle = value; if(cancelled) NativeCore.cancel(value) }
    @Synchronized fun detach() { handle = 0L }
    @Synchronized fun cancel() { cancelled = true; if(handle != 0L) NativeCore.cancel(handle) }
}

private fun java.io.InputStream.takeBytes(limit: Int): ByteArray {
    val output = java.io.ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    while(output.size() < limit) {
        val count = read(buffer, 0, minOf(buffer.size, limit - output.size()))
        if(count < 0) break
        output.write(buffer, 0, count)
    }
    return output.toByteArray()
}
