/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.ln

internal data class PreviewHistogram(val red: IntArray, val green: IntArray, val blue: IntArray,
    val pixels: Int, val atBlack: Int, val atWhite: Int)

internal fun previewHistogram(pixels: IntArray): PreviewHistogram {
    val r = IntArray(256); val g = IntArray(256); val b = IntArray(256)
    var count = 0; var black = 0; var white = 0
    pixels.forEach { pixel ->
        if(pixel ushr 24 == 0) return@forEach
        val red = (pixel ushr 16) and 255; val green = (pixel ushr 8) and 255; val blue = pixel and 255
        r[red]++; g[green]++; b[blue]++; count++
        if(red == 0 || green == 0 || blue == 0) black++
        if(red == 255 || green == 255 || blue == 255) white++
    }
    return PreviewHistogram(r, g, b, count, black, white)
}

@Composable
internal fun PreviewHistogramPanel(bitmap: Bitmap) {
    val histogram by produceState<PreviewHistogram?>(null, bitmap) {
        value = withContext(Dispatchers.Default) {
            val pixels = IntArray(bitmap.width * bitmap.height)
            bitmap.getPixels(pixels, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
            previewHistogram(pixels)
        }
    }
    var logarithmic by remember { mutableStateOf(true) }
    Surface(color = MaterialTheme.colorScheme.surface.copy(alpha = .94f)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 8.dp).testTag("preview_histogram")) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(stringResource(R.string.desktop_histogram_label), Modifier.weight(1f),
                    style = MaterialTheme.typography.labelSmall)
                TextButton({ logarithmic = !logarithmic }, Modifier.heightIn(min = 40.dp)) {
                    Text(if(logarithmic) "log" else "linear", style = MaterialTheme.typography.labelSmall)
                }
            }
            Canvas(Modifier.fillMaxWidth().height(56.dp)) {
                histogram?.let { data ->
                    val maximum = maxOf(data.red.maxOrNull() ?: 0, data.green.maxOrNull() ?: 0, data.blue.maxOrNull() ?: 0)
                    if(maximum > 0) {
                        fun height(value: Int): Float = (if(logarithmic) ln(1.0 + value) / ln(1.0 + maximum)
                            else value.toDouble() / maximum).toFloat() * size.height
                        listOf(data.red to Color(0xFFFF7676), data.green to Color(0xFF78DE91),
                            data.blue to Color(0xFF83B8FF)).forEach { (bins, color) ->
                            for(index in 1..255) drawLine(color,
                                Offset((index - 1) * size.width / 255, size.height - height(bins[index - 1])),
                                Offset(index * size.width / 255, size.height - height(bins[index])), 1.4.dp.toPx())
                        }
                    }
                }
            }
            histogram?.takeIf { it.pixels > 0 }?.let {
                Text(stringResource(R.string.desktop_histogram_clipping,
                    100f * it.atBlack / it.pixels, 100f * it.atWhite / it.pixels),
                    style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
