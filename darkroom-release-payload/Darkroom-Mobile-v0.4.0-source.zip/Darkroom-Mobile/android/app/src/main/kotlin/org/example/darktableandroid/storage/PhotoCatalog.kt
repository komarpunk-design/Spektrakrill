/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import org.w3c.dom.Element

/** Catalog values use the native XMP as their only persistent authority. */
internal data class CatalogMarks(val rating: Int = 0, val colors: Int = 0, val tags: List<String> = emptyList()) {
    init {
        require(rating in -1..5 && colors in 0..31)
        require(tags.size <= 1024 * 1024 && tags.all { it.isNotBlank() && it.length <= 4096 && '\u0000' !in it &&
            !it.startsWith("darktable|") })
    }
}

internal data class CatalogPhoto(val project: PhotoProject, val marks: CatalogMarks?, val error: String? = null)
internal enum class CatalogSort { RECENT, NAME, RATING }
internal data class CatalogQuery(val text: String = "", val minimumStars: Int = 0,
    val rejectedOnly: Boolean = false, val color: Int? = null, val sort: CatalogSort = CatalogSort.RECENT) {
    fun select(photos: List<CatalogPhoto>): List<CatalogPhoto> {
        val words = text.trim().split(Regex("\\s+")).filter(String::isNotEmpty)
        val selected = photos.filter { photo ->
            val marks = photo.marks
            val search = photo.project.name + " " + marks?.tags.orEmpty().joinToString(" ")
            words.all { search.contains(it, true) } &&
                (if(rejectedOnly) marks?.rating == -1 else minimumStars == 0 || (marks?.rating ?: -1) >= minimumStars) &&
                (color == null || marks != null && marks.colors and (1 shl color) != 0)
        }
        val tie = compareBy<CatalogPhoto> { it.project.name.lowercase(java.util.Locale.ROOT) }.thenBy { it.project.id }
        return selected.sortedWith(when(sort) {
            CatalogSort.RECENT -> compareByDescending<CatalogPhoto> { it.project.updated }.then(tie)
            CatalogSort.NAME -> tie
            CatalogSort.RATING -> compareByDescending<CatalogPhoto> { it.marks?.rating ?: -2 }.then(tie)
        })
    }
}

internal fun PhotoProject.catalogPhoto(): CatalogPhoto = try {
    CatalogPhoto(this, if(!sidecar.exists()) null else catalogMarks(sidecar.readBytes()))
} catch(failure: Exception) { CatalogPhoto(this, null, failure.message ?: "Unreadable XMP") }

/** A slider edit must not reparse every sidecar in a large collection. */
internal class CatalogIndex {
    private data class Entry(val modified: Long, val length: Long, val photo: CatalogPhoto)
    private val cached = mutableMapOf<String, Entry>()
    fun refresh(projects: List<PhotoProject>, invalidated: String? = null): List<CatalogPhoto> {
        val retained = projects.map { it.id }.toSet()
        cached.keys.retainAll(retained)
        return projects.map { project ->
            val modified = project.sidecar.lastModified()
            val length = project.sidecar.length()
            val entry = cached[project.id]
            val photo = if(project.id != invalidated && entry?.modified == modified && entry.length == length)
                entry.photo.copy(project = project) else project.catalogPhoto()
            cached[project.id] = Entry(modified, length, photo)
            photo
        }
    }
}

internal fun catalogMarks(bytes: ByteArray): CatalogMarks {
    val doc = checkedProcessingXml(bytes)
    fun property(ns: String, name: String): String? {
        val nodes = doc.getElementsByTagNameNS(ns, name)
        if(nodes.length > 0) return nodes.item(0).textContent
        val descriptions = doc.getElementsByTagNameNS("http://www.w3.org/1999/02/22-rdf-syntax-ns#", "Description")
        for(i in 0 until descriptions.length) (descriptions.item(i) as Element).let {
            if(it.hasAttributeNS(ns, name)) return it.getAttributeNS(ns, name)
        }
        return null
    }
    fun items(ns: String, name: String): List<String> {
        val nodes = doc.getElementsByTagNameNS(ns, name)
        if(nodes.length == 0) return emptyList()
        val entries = (nodes.item(0) as Element).getElementsByTagNameNS("http://www.w3.org/1999/02/22-rdf-syntax-ns#", "li")
        return List(entries.length) { entries.item(it).textContent }
    }
    val rating = property("http://ns.adobe.com/xap/1.0/", "Rating")?.toInt() ?: 0
    var colors = items("http://darktable.sf.net/", "colorlabels").fold(0) { mask, text ->
        val index = text.toInt(); require(index in 0..4); mask or (1 shl index)
    }
    // The native importer gives the Adobe single-label field precedence.
    property("http://ns.adobe.com/xap/1.0/", "Label")?.let { name ->
        colors = listOf("Red", "Yellow", "Green", "Blue", "Purple").indexOf(name).let { if(it < 0) 0 else 1 shl it }
    }
    val hierarchical = items("http://ns.adobe.com/lightroom/1.0/", "hierarchicalSubject")
    val tags = (hierarchical.ifEmpty { items("http://purl.org/dc/elements/1.1/", "subject") })
        .filterNot { it.startsWith("darktable|") }.distinct()
    return CatalogMarks(rating, colors, tags)
}
