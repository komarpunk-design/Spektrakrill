/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import androidx.compose.ui.geometry.Offset
import org.junit.Assert.*
import org.junit.Test

class WorkspaceLayoutModelTest {
    @Test fun resizingKeepsBothPanesReachableAndRejectsNonfiniteState() {
        assertEquals(.30f, inspectorPreviewFraction(-5f))
        assertEquals(.72f, inspectorPreviewFraction(5f))
        assertEquals(.55f, inspectorPreviewFraction(Float.NaN))
        assertEquals(.55f, inspectorPreviewFraction(Float.POSITIVE_INFINITY))
        assertEquals(.63f, inspectorPreviewFraction(.63f))
    }

    @Test fun panningCannotMoveAFittedPhotoOutOfView() {
        assertEquals(Offset.Zero, boundedPreviewPan(Offset(500f, 200f), 1f, 400f, 400f, 600, 400))
        val zoomed = boundedPreviewPan(Offset(500f, 500f), 2f, 400f, 400f, 600, 400)
        assertEquals(200f, zoomed.x, .001f)
        assertEquals(66.6667f, zoomed.y, .001f)
        assertEquals(Offset.Zero, boundedPreviewPan(Offset(500f, 200f), 2f, 0f, 0f, 600, 400))
    }
}
