/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.example.darktableandroid.nativecore.styleName
import org.example.darktableandroid.nativecore.styleDescription

class PhotoStylesTest {
    @get:Rule val temporary = TemporaryFolder()
    private fun style(name: String = "A real style", operation: String = "exposure") = """
        <?xml version="1.0" encoding="UTF-8"?><darktable_style version="1.0">
        <info><name>$name</name><description>Native settings</description></info>
        <style><plugin><num>0</num><module>7</module><operation>$operation</operation>
        <op_params>00000000</op_params><enabled>1</enabled></plugin></style></darktable_style>
    """.trimIndent().toByteArray()

    @Test fun originalNativeStyleStructureIsCataloguedWithoutRewritingItsBytes() {
        val store = PhotoStyles(temporary.root)
        val bytes = style("Русский стиль 📷")
        val retained = store.retain(bytes)
        assertEquals("Русский стиль 📷", retained.name)
        assertEquals(setOf("exposure"), retained.operations)
        assertEquals("Native settings", retained.description)
        assertArrayEquals(bytes, retained.file.readBytes())
        assertEquals(retained.id, store.retain(bytes).id)
        assertEquals(1, PhotoStyles(temporary.root).list().size)
    }

    @Test fun sameNameVariantsRemainIndependentAndInvalidImportsDoNotEraseThem() {
        val store = PhotoStyles(temporary.root)
        val one = store.retain(style())
        val two = store.retain(style(operation = "filmicrgb"))
        assertNotEquals(one.id, two.id)
        assertEquals(2, store.list().size)
        for(bytes in listOf("<wrong/>".toByteArray(), style(operation = "../../bad"),
            "<!DOCTYPE x SYSTEM 'file:///etc/passwd'><darktable_style/>".toByteArray()))
            assertThrows(Exception::class.java) { store.retain(bytes) }
        assertEquals(2, store.list().size)
        assertArrayEquals(style(), one.file.readBytes())
    }

    @Test fun originalEngineGeneratedStyleIsAcceptedWithoutTranscodingNativeParameters() {
        val bytes = javaClass.getResourceAsStream("/desktop-native-style.dtstyle")!!.use { it.readBytes() }
        val style = PhotoStyles(temporary.root).retain(bytes)
        assertEquals("Native Style", style.name)
        assertTrue("exposure" in style.operations)
        assertArrayEquals(bytes, style.file.readBytes())
    }

    @Test fun everyBundledNativeStyleIsAvailableWithoutManualImport() {
        val bundled = java.io.File("../../data/styles")
        val expected = bundled.listFiles()!!.count { it.extension == "dtstyle" }
        assertTrue(expected > 500)
        val styles = PhotoStyles(temporary.root, bundled).list()
        assertEquals(expected, styles.size)
        assertEquals(expected, styles.map { it.id }.distinct().size)
        assertTrue(styles.none { it.requiresDevelopmentEngine })
        assertTrue(styles.any { it.origin == StyleOrigin.EXAMPLE })
        assertTrue(styles.any { it.origin == StyleOrigin.CAMERA && "Nikon" in it.name })
        assertTrue(temporary.root.listFiles()!!.isEmpty())
    }

    @Test fun nativeStyleLocalizationNeverChangesStoredIdentitiesOrUserText() {
        val catalog = org.example.darktableandroid.nativecore.GettextCatalog.empty().withOverrides(
            mapOf("effects" to "эффекты", "fog" to "туман"))
        val name = "_l10n_darktable|_l10n_examples|_l10n_effects|_l10n_fog"
        assertEquals("эффекты / туман", catalog.styleName(name))
        assertEquals("fog", catalog.styleDescription("fog"))
        assertEquals("туман", catalog.styleDescription("_l10n_fog"))
        assertEquals("Nikon / D700", catalog.styleName("_l10n_darktable|_l10n_camera styles|Nikon|D700"))
    }

    @Test fun newlyCreatedBlendFormatIsExplicitlyMarkedAsNewerThanStableDesktop() {
        val store = PhotoStyles(temporary.root)
        val native = javaClass.getResourceAsStream("/desktop-native-style.dtstyle")!!.use { it.readBytes() }
        assertTrue(store.retain(native).requiresDevelopmentEngine)
        assertFalse(store.retain(style()).requiresDevelopmentEngine)
    }
}
