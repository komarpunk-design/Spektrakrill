/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import org.junit.Assert.*
import org.junit.Test

class PreviewHistogramTest {
    @Test fun channelsAndClippingDescribeTheActualOpaquePreviewPixels() {
        val h = previewHistogram(intArrayOf(0xff000000.toInt(), 0xffffffff.toInt(), 0xffff8000.toInt(),
            0xff102030.toInt(), 0x00ffffff))
        assertEquals(4, h.pixels)
        assertEquals(2, h.atBlack)
        assertEquals(2, h.atWhite)
        assertEquals(2, h.red[255])
        assertEquals(1, h.green[128])
        assertEquals(2, h.blue[0])
        assertEquals(4, h.red.sum()); assertEquals(4, h.green.sum()); assertEquals(4, h.blue.sum())
    }
    @Test fun anEmptyOrTransparentPreviewHasNoInventedSamples() {
        for(pixels in listOf(intArrayOf(), intArrayOf(0x00ffffff, 0x00000000))) {
            val h = previewHistogram(pixels)
            assertEquals(0, h.pixels); assertEquals(0, h.atBlack); assertEquals(0, h.atWhite)
            assertEquals(0, h.red.sum() + h.green.sum() + h.blue.sum())
        }
    }
}
