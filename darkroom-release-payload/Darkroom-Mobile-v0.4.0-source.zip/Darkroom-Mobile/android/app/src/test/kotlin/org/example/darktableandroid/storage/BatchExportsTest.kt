/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import org.example.darktableandroid.nativecore.ExportSettings
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class BatchExportsTest {
    @get:Rule val temporary = TemporaryFolder()
    private fun store() = BatchExports(temporary.root.resolve("queue"))
    private fun photo(name: String = "photo") = PhotoProjects(temporary.root.resolve("projects"))
        .create(temporary.newFile("$name.nef").apply { writeText("camera original") }, "content://$name", "$name.NEF")
    private fun enqueue(photo: PhotoProject = photo()) = store().enqueue(photo, "png", "png", "image/png",
        ExportSettings(maxWidth = 800, maxHeight = 600, pixelFormat = 1), true, "content://tree")

    @Test fun queuedNativeHistoryAndEncoderSettingsAreIndependentOfLaterEditsAndRestart() {
        val photo = photo()
        val bytes = javaClass.getResourceAsStream("/desktop-native-sidecar.xmp")!!.readBytes()
        atomicWrite(photo.sidecar, bytes)
        val job = enqueue(photo)
        atomicWrite(photo.sidecar, bytes.toString(Charsets.UTF_8).replace("0.75", "1.25").toByteArray())
        val reopened = store().read(job.id)
        assertEquals(job, reopened)
        assertEquals(800, reopened.settings.maxWidth)
        assertEquals(1, reopened.settings.pixelFormat)
        assertArrayEquals(bytes, store().history(reopened)!!.readBytes())
    }

    @Test fun unopenedPhotoUsesExplicitCameraDefaultsEvenIfEditedAfterEnqueue() {
        val photo = photo()
        val job = enqueue(photo)
        photo.sidecar.writeBytes(javaClass.getResourceAsStream("/desktop-native-sidecar.xmp")!!.readBytes())
        assertNull(store().history(job))
        assertEquals("camera original", photo.source.readText())
    }

    @Test fun failedImageDoesNotPreventFollowingExportsOrEraseSuccessfulResults() {
        val first = enqueue(photo("first"))
        val second = enqueue(photo("second"))
        val calls = mutableListOf<String>()
        store().runPending({ false }, {}) {
            calls += it.id
            if(it.id == first.id) error("decoder failed")
            "content://new-output/${it.id}"
        }
        assertEquals(2, calls.size)
        assertEquals(BatchStatus.FAILED, store().read(first.id).status)
        assertEquals("decoder failed", store().read(first.id).error)
        assertEquals(BatchStatus.DONE, store().read(second.id).status)
        assertEquals("content://new-output/${second.id}", store().read(second.id).result)
        assertThrows(IllegalArgumentException::class.java) { store().retry(second.id) }
    }

    @Test fun restartDoesNotAutomaticallyRerunAnUncertainExport() {
        val job = enqueue()
        store().save(job.copy(status = BatchStatus.RUNNING))
        store().recoverInterrupted()
        assertEquals(BatchStatus.INTERRUPTED, store().read(job.id).status)
        var ran = false
        store().runPending({ false }, {}) { ran = true; "content://unexpected" }
        assertFalse(ran)
        store().retry(job.id)
        store().retry(job.id) // Rapid repeated taps do not turn a queued retry into an error.
        store().runPending({ false }, {}) { "content://retried" }
        assertEquals(BatchStatus.DONE, store().read(job.id).status)
    }

    @Test fun stopLeavesUnstartedItemsPendingAndAllowsExplicitResume() {
        enqueue(photo("a")); enqueue(photo("b"))
        var cancelled = false
        store().runPending({ cancelled }, {}) { cancelled = true; error("stopped") }
        assertEquals(1, store().list().count { it.status == BatchStatus.CANCELLED })
        assertEquals(1, store().list().count { it.status == BatchStatus.PENDING })
        store().runPending({ false }, {}) { "content://remaining" }
        assertEquals(1, store().list().count { it.status == BatchStatus.DONE })
    }

    @Test fun aVerifiedCommitRemainsSuccessfulWhenStopArrivesAfterCommit() {
        val job = enqueue()
        var cancelled = false
        store().runPending({ cancelled }, {}) { cancelled = true; "content://verified" }
        assertEquals(BatchStatus.DONE, store().read(job.id).status)
    }

    @Test fun corruptNativeHistoryIsRejectedWithoutLeavingAPartialQueueEntry() {
        val photo = photo()
        photo.sidecar.writeText("<broken")
        assertThrows(Exception::class.java) { enqueue(photo) }
        assertTrue(store().list().isEmpty())
        assertThrows(IllegalArgumentException::class.java) { store().read("../projects") }
    }
}
