/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import java.io.File
import org.junit.Assert.*
import org.junit.Test

class PhotoCatalogTest {
    private fun xml(body: String, attributes: String = "") = """<x:xmpmeta xmlns:x="adobe:ns:meta/">
        <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description
        xmlns:xmp="http://ns.adobe.com/xap/1.0/" xmlns:dt="http://darktable.sf.net/"
        xmlns:lr="http://ns.adobe.com/lightroom/1.0/" xmlns:dc="http://purl.org/dc/elements/1.1/" $attributes>
        $body</rdf:Description></rdf:RDF></x:xmpmeta>""".toByteArray()

    @Test fun readsNativeNamespacesAttributesAndHierarchicalTagsWithoutFlattening() {
        val marks = catalogMarks(xml("""<dt:colorlabels><rdf:Seq><rdf:li>0</rdf:li><rdf:li>4</rdf:li></rdf:Seq></dt:colorlabels>
            <lr:hierarchicalSubject><rdf:Bag><rdf:li>Места|Москва 📷</rdf:li><rdf:li>A &amp; B</rdf:li><rdf:li>darktable|changed</rdf:li></rdf:Bag></lr:hierarchicalSubject>
            <dc:subject><rdf:Bag><rdf:li>Do not flatten</rdf:li></rdf:Bag></dc:subject>""", "xmp:Rating=\"4\""))
        assertEquals(CatalogMarks(4, 17, listOf("Места|Москва 📷", "A & B")), marks)
    }

    @Test fun adobeLabelPrecedesDarktableColorListJustLikeTheNativeImporter() {
        assertEquals(CatalogMarks(-1, 8), catalogMarks(xml("""<xmp:Rating>-1</xmp:Rating>
            <dt:colorlabels><rdf:Seq><rdf:li>0</rdf:li></rdf:Seq></dt:colorlabels>""", "xmp:Label=\"Blue\"")))
    }

    @Test fun missingValuesUseUnratedDefaultsAndInvalidValuesAreNotClamped() {
        assertEquals(CatalogMarks(), catalogMarks(xml("")))
        assertThrows(IllegalArgumentException::class.java) { catalogMarks(xml("<xmp:Rating>9</xmp:Rating>")) }
        assertThrows(IllegalArgumentException::class.java) { catalogMarks(xml("<dt:colorlabels><rdf:Seq><rdf:li>8</rdf:li></rdf:Seq></dt:colorlabels>")) }
        assertThrows(IllegalArgumentException::class.java) { CatalogMarks(tags = listOf("darktable|internal")) }
    }

    @Test fun searchCombinesNameHierarchyRatingColorAndRejection() {
        fun photo(id: String, name: String, rating: Int, colors: Int, tags: List<String>, updated: Long) =
            CatalogPhoto(PhotoProject(id, name, "content://$id", updated, null, File(id), File("$id/source.nef")), CatalogMarks(rating, colors, tags))
        val photos = listOf(photo("a", "Bridge.NEF", 4, 1, listOf("Places|Moscow"), 10),
            photo("b", "Cat.RAF", -1, 8, listOf("Places|Moscow"), 50),
            photo("c", "Bridge.RAF", 5, 2, listOf("Places|London"), 20))
        assertEquals(listOf("a"), CatalogQuery("bridge moscow", 3, color = 0).select(photos).map { it.project.id })
        assertEquals(listOf("b"), CatalogQuery(rejectedOnly = true).select(photos).map { it.project.id })
        assertEquals(listOf("c", "a", "b"), CatalogQuery(sort = CatalogSort.RATING).select(photos).map { it.project.id })
        assertEquals(listOf("b", "c", "a"), CatalogQuery().select(photos).map { it.project.id })
    }

    @Test fun realNativeSidecarIsAcceptedWithoutRewritingItsHistory() {
        val bytes = javaClass.getResourceAsStream("/desktop-native-sidecar.xmp")!!.readBytes()
        catalogMarks(bytes)
        assertArrayEquals(bytes, validatedDarktableXmp(bytes))
    }

    @Test fun checkpointInvalidationRefreshesMarksEvenWhenFilesystemStampAndLengthMatch() {
        val dir = java.nio.file.Files.createTempDirectory("catalog-index").toFile()
        try {
            val project = PhotoProject("photo", "Photo", "content://photo", 1, null, dir, dir.resolve("source.nef"))
            project.sidecar.writeBytes(xml("<xmp:Rating>2</xmp:Rating>"))
            val index = CatalogIndex()
            assertEquals(2, index.refresh(listOf(project)).single().marks!!.rating)
            val timestamp = project.sidecar.lastModified()
            project.sidecar.writeBytes(xml("<xmp:Rating>5</xmp:Rating>"))
            project.sidecar.setLastModified(timestamp)
            assertEquals(5, index.refresh(listOf(project), project.id).single().marks!!.rating)
            assertTrue(index.refresh(emptyList()).isEmpty())
        } finally { dir.deleteRecursively() }
    }

    @Test fun existingDesktopCatalogIsNotLimitedToTwoHundredTagsOrCharacters() {
        val tags = List(250) { "Category|$it" } + ("Long|" + "x".repeat(300))
        val entries = tags.joinToString("") { "<rdf:li>$it</rdf:li>" }
        val marks = catalogMarks(xml("<lr:hierarchicalSubject><rdf:Bag>$entries</rdf:Bag></lr:hierarchicalSubject>"))
        assertEquals(tags, marks.tags)
    }
}
