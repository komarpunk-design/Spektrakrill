/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import java.io.File
import java.nio.file.Files
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class PhotoProjectsTest {
    @get:Rule val temporary = TemporaryFolder()
    private val xmp = """<x:xmpmeta xmlns:x="adobe:ns:meta/"><rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description xmlns:darktable="http://darktable.sf.net/"><darktable:history><rdf:Seq/></darktable:history></rdf:Description></rdf:RDF></x:xmpmeta>""".toByteArray()
    private fun store() = PhotoProjects(temporary.root.resolve("projects"))
    private fun create() = store().create(temporary.newFile("camera.NEF").apply { writeBytes(byteArrayOf(1, 2, 3, 4)) },
        "content://camera/photo", "My camera photograph.NEF")

    @Test fun projectRetainsOriginalAfterCacheDisappearsAndStoreReopens() {
        val project = create()
        assertNull(project.catalogPhoto().marks) // Embedded ratings are unknown until native import, not zero.
        File(temporary.root, "camera.NEF").delete()
        val reopened = store().read(project.id)
        assertArrayEquals(byteArrayOf(1, 2, 3, 4), reopened.source.readBytes())
        assertEquals("source.nef", reopened.source.name)
        assertEquals("content://camera/photo", reopened.sourceUri)
        assertEquals("My camera photograph.NEF", store().list().single().name)
        store().update(reopened, "exposure@2")
        assertEquals("exposure@2", store().read(project.id).selectedModule)
    }

    @Test fun snapshotsAreIndependentOfLaterProcessingAndSurviveStoreRecreation() {
        val project = create()
        atomicWrite(project.sidecar, xmp)
        val snapshot = store().snapshot(project, "Original edit")
        val changed = xmp.toString(Charsets.UTF_8).replace("<rdf:Seq/>", "<rdf:Seq><rdf:li>next</rdf:li></rdf:Seq>").toByteArray()
        atomicWrite(project.sidecar, changed)
        val reopened = store().snapshots(store().read(project.id)).single()
        assertEquals(snapshot.id, reopened.id)
        assertEquals("Original edit", reopened.name)
        assertArrayEquals(xmp, reopened.sidecar.readBytes())
        assertArrayEquals(changed, project.sidecar.readBytes())
    }

    @Test fun twoProjectsOfOneOriginalKeepIndependentSettingsAndAssets() {
        val first = create()
        val second = store().create(first.source, first.sourceUri, "Second version")
        atomicWrite(first.sidecar, xmp)
        first.assets.mkdirs();first.assets.resolve("sample.cube").writeText("first")
        assertNotEquals(first.source, second.source)
        assertFalse(second.sidecar.exists())
        assertFalse(second.assets.resolve("sample.cube").exists())
        assertEquals(2, store().list().size)
    }

    @Test fun untrustedIdsAndSourceTraversalCannotEscapeTheProjectDirectory() {
        val project = create()
        assertThrows(IllegalArgumentException::class.java) { store().read("../outside") }
        val meta = project.directory.resolve("project.json")
        meta.writeText(meta.readText().replace("source.nef", "../../outside.nef"))
        assertTrue(store().list().isEmpty())
        assertTrue(project.source.exists())
    }

    @Test fun rejectedAtomicCommitDoesNotRemoveExistingDirectoryOrOriginal() {
        val existing = temporary.newFolder("existing")
        val retained = existing.resolve("original").apply { writeText("keep") }
        assertThrows(IllegalStateException::class.java) { atomicWrite(existing, byteArrayOf(5)) }
        assertEquals("keep", retained.readText())
        assertFalse(temporary.root.listFiles()!!.any { it.name.startsWith(".saving-") })
    }

    @Test fun onlyWellFormedDarktableHistoryIsAccepted() {
        assertArrayEquals(xmp, validatedDarktableXmp(xmp))
        for(value in listOf("<broken", "<other/>", "", "<!DOCTYPE x [<!ENTITY secret SYSTEM 'file:///etc/passwd'>]><x>&secret;</x>"))
            assertThrows(Exception::class.java) { validatedDarktableXmp(value.toByteArray()) }
        assertThrows(Exception::class.java) { validatedDarktableXmp(xmp.toString(Charsets.UTF_8).toByteArray(Charsets.UTF_16)) }
        assertThrows(IllegalArgumentException::class.java) { validatedDarktableXmp(ByteArray(16 * 1024 * 1024 + 1)) }
    }

    @Test fun actualNativeSidecarWithADrawnMaskPassesTheAndroidImportValidator() {
        val bytes = javaClass.getResourceAsStream("/desktop-native-sidecar.xmp")!!.use { it.readBytes() }
        assertArrayEquals(bytes, validatedDarktableXmp(bytes))
        assertTrue(bytes.toString(Charsets.UTF_8).contains("darktable:history"))
    }
}
