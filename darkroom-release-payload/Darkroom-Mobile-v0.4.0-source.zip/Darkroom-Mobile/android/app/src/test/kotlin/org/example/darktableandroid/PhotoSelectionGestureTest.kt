/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.click
import androidx.compose.ui.test.swipe
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.unit.dp
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExternalResource
import org.junit.rules.RuleChain
import org.junit.rules.TestRule
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "en-w400dp-h800dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class PhotoSelectionGestureTest {
    private val compose = createComposeRule()
    @get:Rule val rules: TestRule = RuleChain.outerRule(object : ExternalResource() {
        override fun before() {
            val app = RuntimeEnvironment.getApplication()
            shadowOf(app.packageManager).addOrUpdateActivity(ActivityInfo().apply {
                name = ComponentActivity::class.java.name
                packageName = app.packageName
                applicationInfo = app.applicationInfo
                theme = android.R.style.Theme_Material_Light_NoActionBar
                enabled = true; exported = true
            })
        }
    }).around(compose)
    private val selections = mutableListOf<ToneEqualizerPoint>()
    private fun fixture(mask: Boolean) {
        val bitmap = Bitmap.createBitmap(100, 200, Bitmap.Config.ARGB_8888)
        compose.setContent { MaterialTheme {
            Box(Modifier.size(300.dp, 200.dp)) {
                if(mask) MaskPhotoTargetOverlay(100, 200, true,
                    MaskPhotoTarget(11L, "exposure@3", bitmap, 7, false), null) { _, x, y ->
                    selections += ToneEqualizerPoint(x, y)
                } else ToneEqualizerPhotoTarget(100, 200, true, null) { selections += it }
            }
        } }
    }
    private fun node(mask: Boolean) = compose.onNodeWithTag(if(mask) "mask_photo_target" else "tone_equalizer_photo_target")
    private fun assertDragRejected(mask: Boolean) {
        fixture(mask)
        node(mask).performTouchInput { swipe(center, center + Offset(0f, 40f)) }
        compose.runOnIdle { assertTrue("A drag must not select: $selections", selections.isEmpty()) }
    }
    private fun assertTapAndLetterbox(mask: Boolean) {
        fixture(mask)
        node(mask).performTouchInput { click(Offset(0f, center.y)) }
        compose.runOnIdle { assertTrue(selections.isEmpty()) }
        node(mask).performTouchInput { click(center) }
        compose.runOnIdle {
            assertEquals(1, selections.size)
            assertEquals(.5f, selections.single().x, .01f)
            assertEquals(.5f, selections.single().y, .01f)
        }
    }
    @Test fun maskDragNeverRepositionsAMask() = assertDragRejected(true)
    @Test fun toneDragNeverSamplesATone() = assertDragRejected(false)
    @Test fun maskTapMapsThePhotoAndRejectsLetterbox() = assertTapAndLetterbox(true)
    @Test fun toneTapMapsThePhotoAndRejectsLetterbox() = assertTapAndLetterbox(false)
    @Test fun twoFingersCannotRepositionAMask() {
        fixture(true)
        node(true).performTouchInput { down(0, center); down(1, center + Offset(12f, 0f)); up(1); up(0) }
        compose.runOnIdle { assertTrue("Multitouch must not select: $selections", selections.isEmpty()) }
    }
    @Test fun fingerJitterInsideTouchSlopStillSelects() {
        fixture(true)
        node(true).performTouchInput { down(center); moveBy(Offset(2f, 0f)); up() }
        compose.runOnIdle { assertEquals(1, selections.size) }
    }
}
