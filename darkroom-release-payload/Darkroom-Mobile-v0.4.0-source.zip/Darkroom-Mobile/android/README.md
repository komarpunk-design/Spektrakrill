<!-- SPDX-License-Identifier: GPL-3.0-or-later -->
# Android build

Start with [the fork build and validation guide](FORK.md). Ordinary builds
require `-PdarktableRuntimeStage=/absolute/path/to/stage`; they no longer silently
produce an editor without processing. `devDebug` and `devRelease` retain the
original JNI and native runtime; install the signed development APK separately
from the original author's app.

Version 0.4.0 adds a native-XMP photo catalog (ratings, rejection, color labels,
hierarchical tags, filtering/sorting/multiple selection) and a durable sequential
export queue. Open **⋮ → My photographs** to import multiple files and select a
batch, **⋮ → Rating, labels and tags** for the current photo, and **⋮ → Export
queue** to stop/resume/retry jobs. Each item captures its own processing and
encoder settings; unopened photos use native camera defaults. New SAF files are
read back and SHA-256 verified before completion. Keep the app open: this is not
a background service, and process interruption requires explicit resume/retry.
See [desktop comparison](DESKTOP_PARITY.md) for the remaining desktop features.

The native engine uses the separate [mobile integration layer](../mobile/UPSTREAM_INTEGRATION.md).
Its Android configuration assembles upstream sources in the build tree and
keeps the official darktable checkout unchanged.

The Android UI has a persistent action toolbar, a resizable photo/inspector
workspace and functional bottom categories. Landscape places the inspector
beside the photo. The tool catalog and global search preserve exact native
instances, explicit enable switches and per-tool drafts/scroll positions.
Settings occupies the content area. See [editor UX](EDITOR_UX.md).

Settings includes a saved language button menu: System default, Russian, English,
Traditional Chinese, Simplified Chinese and Latin American Spanish. Tool labels
reuse desktop translations without changing native parameter identities or the
processing locale. See [app languages](LOCALIZATION.md).

Settings → App theme switches between Graphite, Light and OLED black.
The saved choice applies immediately, including system-bar icon contrast,
without restarting the editor or changing the preview, controls or edit history.

An engine-enabled build also opens a single photo shared from Android's file
manager. Share a GPR file and choose this editor; image MIME types and generic
`application/octet-stream` shares are registered, including GoPro application
MIME aliases. The incoming document can use `EXTRA_STREAM`, a single-item
`ClipData`, or the sender's data URI. Original read-grant flags reach the existing
content-URI cache/import flow, which copies the source privately before native
processing. The share URI does not need a visible `.gpr` suffix. Multi-file shares
are not advertised by this single-image editor.

The tools panel provides native sliders and precise input, enum
menus, switches, text fields, document import and action buttons. Tool search
matches module names and parameter labels across all editing tabs. Tap a search
result to open that tool and its category without changing its power state.
Editing a value commits the original
module/history and requests an original-engine preview. A completed slider drag
creates one edit. Image-specific parameter resets and tool settings resets use
native defaults. Progress and cancellation remain visible beside the preview.

The source policies cover 511 reviewed scalar fields and up to 440 fixed-array
components across 81 modules. Actual controls depend on sensor type, active
patches, selected mode and installed plugins. These counts exclude curve nodes,
zone controls, blending, native mask/retouch/liquify operations and text/file
fields; action buttons are not numeric parameters. See
[control coverage](../mobile/CONTROL_PARITY.md) for exact scope and remaining
advanced desktop interactions.

Dedicated editors include base/RGB/Lab tone/color-zone curves, atomic crop and
white balance, levels and fixed frequency bands, and the original zone system.
Crop aspect presets and portrait/free drafts use the native input ROI for each
crop instance, including preceding geometry changes, and apply complete bounds
atomically. Parametric masking groups original input/output channels with four
ordered threshold sliders, inversion, boost/reset and native mask refinement.
The native bridge also supports blending and preceding raster-mask selection,
native circle/ellipse/gradient/path/brush forms, clone/retouch shape controls and
standalone liquify warps. Stable form and node selectors expose precise path
coordinates, Bézier handles and brush feather/hardness/density controls, up to
64 nodes per form. Subsequent group members support the original five
combination operations. Spots supports clone paths; retouch supports paths and
brushes. Applied coordinate diagrams remain separate from the processed photo.
Lens correction has a dedicated mode-aware editor with camera/lens profile
selection, shooting settings, actual source/profile capability reporting and
manual vignette controls. It resolves original image defaults before edits and
retains a valid crop factor when a camera body has no database match. HERO12
Black has no bundled profile; embedded TCA/shading data does not establish
fisheye correction. See [lens correction](LENS_CORRECTION.md) for usage and exact
limits. Watermark text/font/template uses bounded native text fields.
System document selection imports external raster
PFM/PNG masks, Cube/3DL/Hald-PNG LUTs and PNG/JPEG/TIFF overlay images into retained
session assets. The original readers and processing code handle those files;
overlay selection also updates its original image ID and dependency state. The
UI supplies no replacement image formulas.

The tools panel hides internal pipeline/diagnostic modules. RAW-only settings
and methods follow the input's original capabilities, including Bayer/X-Trans/
four-Bayer/monochrome demosaicing. The removed desktop `colortransfer` editor
retains its legacy explanation/enable state. Freehand stroke capture, direct
photo-canvas manipulation, live channel histograms, linked liquify strokes,
automatic pickers, full preset browsers and other advanced interactions remain
outside this coverage.

The explicit `-PdarktableDependencyProbe=true` route sets
`DT_MOBILE_WITH_DARKTABLE_ENGINE=OFF`, reports processing unavailable and disables
image opening. Normal builds require a complete runtime stage. The explicit [prebuilt route](PREBUILT_ENGINE.md) packages an installed,
verified engine/runtime stage. Earlier ARM64/API 28 preview/edit/export runs and
current checks are recorded separately in [native verification](NATIVE_ENGINE_TESTS.md)
and [port status](../mobile/dependencies/PORTING_STATUS.md). Their exact fixtures,
execution settings and limitations matter; compilation does not establish full
desktop parity, physical-device behavior or performance.

Module instances use image-specific original defaults and keep independent
settings. Session undo/redo retains up to 64 successful edit steps; editing after
undo discards redo. Imported files remain available while their session history
can reference them, and now remain in the persistent photo project after closing.
Native XMP, named snapshots, .dtstyle import/create/apply/export, session-history
navigation and comparison/histogram tools are described in
[the desktop comparison](DESKTOP_PARITY.md). Copying current settings/masks and deleting or reordering
instances remain pending.

The export destination uses Android's system document picker. Settings come from
the installed native formats, including dimensions without upscaling, supported
precision/compression, JPEG quality/subsampling, DPI, built-in output profiles,
rendering intent and source-metadata copying. Export renders at native image
resolution; the preview bitmap is not its input. Further optional format and
custom ICC-file parity is documented separately.

## Native runtime data

`RuntimeAssets.initializeNative` prepares and configures an explicit engine-enabled
build. It requires the complete matching runtime tree under APK assets
`darktable-runtime/`, recursively extracts it into a private, installation
version-specific directory beneath `filesDir/darktable-runtime/`, and commits
the tree only after a successful copy. It never merges a new installation over
an old tree. A failed extraction is not reused; previously committed versions
are retained so an active native session cannot lose its files. The native data
directory is the committed tree's `data/` child; sibling resources such as
`lensfun/version_1/` retain their layout relative to that data directory.

The minimum checks require nonempty `darktablerc`, `rawspeed/cameras.xml`,
`noiseprofiles.json` and `wb_presets.json`. The first is generated by the desktop
build, and the others are read directly by the RAW decoder, denoise profiles and
white-balance initialization. These checks are necessary startup conditions;
they do not establish a complete runtime. Package the matching installation's
data, including styles and watermarks, any supplied `color/in` and `color/out`
profiles, and the data required by enabled optional features such as OpenCL
kernels or AI models. Lensfun calibration data uses the separate sibling
`lensfun/version_1/` directory, retained and verified by the complete runtime
staging route. The lens editor reports a missing database separately from a
missing camera/lens calibration; neither condition implies complete lens parity.

The existing Gradle asset task only supplies three flat camera/noise/white-balance
database files. It does not produce this runtime tree, so an engine-enabled build
with only those files fails preparation with an explicit missing-runtime error.
`tempRoot` uses the application's cache directory. `moduleDir` is always
`applicationInfo.nativeLibraryDir`: processing and export libraries must be
packaged as Android native libraries and extracted by the installer. The helper
rejects `.so` files and ELF content in data assets; it never copies executable
code to `filesDir` or changes process environment variables. A successful native
configuration is retained for the process. A recreated editor reuses identical
paths while its previous ViewModel finishes closing a session; a changed runtime
still goes through native validation and cannot replace an active session's data.

The experimental [runtime staging tool](../mobile/dependencies/STAGING.md)
prepares this tree and its native-library closure from a complete installed
Android engine. The explicit [prebuilt engine route](PREBUILT_ENGINE.md)
consumes the verified stage when selected by a project property. Native
build/link, staging and final APK runtime-content validation have passed for the
configured bootstrap. A preserved APK pair also passed the separate ARM64/API 28
Fusion JNI edit/export test with the recorded host execution settings. Disabled
optional codecs, unported controls and broader device/format checks remain separate work.

## Gradle Wrapper

The official Gradle 8.14.4 wrapper JAR is included in this fork. It was generated
from the SHA-256-verified official distribution in an isolated empty project.
The distribution SHA-256 is pinned in `gradle-wrapper.properties`. The wrapper
is the necessary binary source file; APKs, AABs, native libraries, build output
and signing material remain untracked. CI may regenerate the same official JAR
before validation.
