#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Extend a verified runtime with a source-built API-26 JNI sidecar bridge."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
repo = Path(__file__).resolve().parents[2]
verifier = repo / 'mobile/dependencies/verify-android-runtime-stage.py'
spec = importlib.util.spec_from_file_location('runtime_verifier', verifier)
verify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verify)
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--stage', required=True, type=Path)
parser.add_argument('--ndk', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
original = args.stage.resolve(strict=True)
output = args.output.resolve()
if output.exists() or output.is_relative_to(original):
    parser.error('Output must be a new directory outside the original stage')
verify.verify(original, original / 'android-runtime-libraries.txt')
output.parent.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory(prefix='desktop-bridge-', dir=output.parent) as temporary:
    stage = Path(temporary) / 'stage'
    shutil.copytree(original, stage)
    library = stage / 'jniLibs/arm64-v8a/libdarkroom_desktop.so'
    if library.exists():
        parser.error('Runtime already contains the desktop bridge')
    toolchain = args.ndk / 'toolchains/llvm/prebuilt/linux-x86_64/bin'
    source = repo / 'android/desktop-bridge/desktop_bridge.c'
    subprocess.run([str(toolchain / 'aarch64-linux-android26-clang'), '-std=c11',
                    '-shared', '-fPIC', '-O2', '-Wall', '-Wextra', '-Werror',
                    '-Wl,--no-undefined', '-Wl,-z,max-page-size=16384',
                    '-Wl,-soname,libdarkroom_desktop.so', str(source),
                    '-L' + str(library.parent), '-ldarktable', '-o', str(library)], check=True)
    elf = verify.stage.read_elf(library)
    manifest = json.loads((stage / 'manifest.json').read_text())
    manifest['libraries'][library.name] = dict(source=str(output / 'jniLibs/arm64-v8a' / library.name),
        sourceCode=str(source), sourceCodeSha256=verify.stage.sha256(source),
        sha256=verify.stage.sha256(library), soname=elf.soname,
        needed=list(elf.needed), searchPaths=elf.search_paths)
    manifest['configuredLibraries'] = sorted(manifest['configuredLibraries'] + [library.name])
    (stage / 'android-runtime-libraries.txt').write_text('\n'.join(manifest['configuredLibraries']) + '\n')
    (stage / 'manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    verify.verify(stage, stage / 'android-runtime-libraries.txt')
    stage.rename(output)
print(json.dumps({'stage': str(output), 'bridgeSha256': verify.stage.sha256(output / 'jniLibs/arm64-v8a/libdarkroom_desktop.so'),
                  'originalRuntimeUnchanged': True}))
