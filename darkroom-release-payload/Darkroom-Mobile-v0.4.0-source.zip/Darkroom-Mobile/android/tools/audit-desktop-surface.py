#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Inventory actual desktop source surfaces and installed Android plugins.

Presence of a processing plugin is deliberately not classified as GUI parity.
Run with --stage pointing to the runtime used for the APK; output is JSON.
"""
import argparse
import json
import re
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--stage', type=Path, required=True)
args = parser.parse_args()
repo = Path(__file__).resolve().parents[2]
libraries = args.stage / 'jniLibs/arm64-v8a'
if not libraries.is_dir():
    parser.error('Expected the APK runtime stage with jniLibs/arm64-v8a')

def targets(directory):
    cmake = (repo / directory / 'CMakeLists.txt').read_text()
    aliases = dict(re.findall(r'set_target_properties\(\s*(\w+)\s+PROPERTIES\s+OUTPUT_NAME\s+(\w+)\s*\)', cmake))
    return list(dict.fromkeys((aliases.get(name, name), repo / directory / source) for name, source in
                re.findall(r'^[ \t]*add_(?:iop|library)\(\s*(\w+)\s+(?:MODULE\s+)?"([^"\n]+\.(?:c|cc))"', cmake, re.M)))

def surface(directory, prefix):
    result = []
    for name, path in targets(directory):
        result.append({'name': name, 'source': str(path.relative_to(repo)),
                       'android_plugin_installed': (libraries / (prefix + name + '.so')).is_file(),
                       'complete_mobile_interaction_verified': False})
    return result

views = [{'name': name, 'source': str(path.relative_to(repo)),
          'complete_mobile_view_ported': False} for name, path in targets('src/views')]
document = {'reference': 'pinned desktop source, not a count of every desktop action',
            'warning': 'Plugin presence only proves packaging. Widgets, pickers, gestures, dependencies and pixel output need separate checks.',
            'views': views, 'panels': surface('src/libs', 'libdt_lib_'),
            'processing': surface('src/iop', 'libdt_iop_'),
            'formats': surface('src/imageio/format', 'libdt_format_')}
document['counts'] = {key: len(document[key]) for key in ('views', 'panels', 'processing', 'formats')}
document['installed_processing_plugins'] = sum(row['android_plugin_installed'] for row in document['processing'])
print(json.dumps(document, indent=2) + '\n', end='')
