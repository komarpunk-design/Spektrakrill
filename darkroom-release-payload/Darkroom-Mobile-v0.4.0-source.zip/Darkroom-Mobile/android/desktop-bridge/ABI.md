# Desktop interop ABI

This bridge uses public C symbols from the pinned darktable source, not a
private `dt_mobile_session` or `dt_develop_t` memory layout:

- `dt_imgid_t` is `int32_t`: `src/common/darktable.h`.
- `dt_image_get_id_full_path`: `src/common/image.h`.
- `dt_exif_xmp_write`: `src/common/exif.h` (`TRUE` means failure).
- Style creation/import/export/apply/delete: `src/common/styles.h`.
- Ratings, color labels and tag assignment: `src/common/ratings.h`,
  `src/common/colorlabels.h`, `src/common/tags.h`.

The declarations retain the exact C ABI of the source revision. Tag assignment
uses opaque public `GList` pointers, allocated/freed by the runtime's own
`g_list_append` / `g_list_free`. No list or image-cache struct is dereferenced. All symbols
are resolved against the verified engine during linking (`--no-undefined`).
The existing JNI UTF-8 conversion is reused, including rejection of NUL and
unpaired surrogates. Kotlin executes interop on its single native dispatcher.

Style application writes a native XMP before retiring the old develop context.
Even on error, the app loads the saved XMP into a replacement context and
retires the old context before publishing the result. Keeping the runtime alive
through this handoff avoids reinitializing the desktop global type registry.
It must never continue rendering an old context against a database altered by
the public style API. A recovery snapshot retains the
previous processing. Applying a style starts a fresh mobile Undo session.

Catalog updates use the public cache-aware rating/tag APIs, with internal
`darktable|` tags preserved and grouping/session Undo disabled. Values and every
tag are validated before changing image assignments. Native XMP remains the
durable authority. `NativeCatalog.restore` repairs the pinned importer's comma
splitting of RDF tags (`src/common/exif.cc:_exif_import_tags`) after opening,
before checkpoint/export, through the same public tag API. Pixel math is unchanged.

Batch items own a captured XMP and immutable encoder settings. The worker copies
the retained original to a new scratch path and opens that copy, so importing its
history cannot mutate the active editor's image ID. Only one item is processed
at a time, on the existing native dispatcher, while the editor retains a runtime
user. SHA-256 readback checks the new SAF output before the item is marked done.
The queue persists; it is not a foreground service and does not promise execution
after Android kills the process. Interrupted items need explicit retry.

Build a new stage with `android/tools/build-desktop-bridge.py`. The original
stage is read-only; all original library/data hashes remain identical. The
new ARM64 library is recorded explicitly in the derived stage manifest and
the complete stage/APK verifier is run. No binary is patched or renamed.
