import org.example.darktableandroid.nativecore.NativeCore;
import org.example.darktableandroid.nativecore.NativeDesktop;
import org.example.darktableandroid.nativecore.NativeCatalog;
import java.nio.file.*;
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.json.*;
public class CatalogBatchProbe {
 static final NativeCore c=NativeCore.INSTANCE;
 static final NativeDesktop d=NativeDesktop.INSTANCE;
 static Set<String> expectedTags(){var tags=new HashSet<String>(Set.of("Places|Москва 📷","A, B & C","Long|"+"x".repeat(300),"Line\nBreak"));for(int i=0;i<250;i++)tags.add("Category|"+i);return tags;}
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 static Document xml(Path file)throws Exception {var f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);return f.newDocumentBuilder().parse(file.toFile());}
 static Set<String> items(Document doc,String namespace,String name){var result=new HashSet<String>();var n=doc.getElementsByTagNameNS(namespace,name);if(n.getLength()>0){var values=((Element)n.item(0)).getElementsByTagNameNS("http://www.w3.org/1999/02/22-rdf-syntax-ns#","li");for(int i=0;i<values.getLength();i++)result.add(values.item(i).getTextContent());}return result;}
 static int rating(Document doc){var n=doc.getElementsByTagNameNS("http://www.w3.org/1999/02/22-rdf-syntax-ns#","Description");for(int i=0;i<n.getLength();i++){var e=(Element)n.item(i);if(e.hasAttributeNS("http://ns.adobe.com/xap/1.0/","Rating"))return Integer.parseInt(e.getAttributeNS("http://ns.adobe.com/xap/1.0/","Rating"));}throw new AssertionError("No rating");}
 public static void main(String[] args)throws Exception {
  var root=Path.of(args[1]);Files.createDirectories(root);var source=root.resolve("source."+Path.of(args[0]).getFileName().toString().replaceAll("^.*\\.",""));
  var rt=root.resolve("runtime");Files.createDirectories(rt);c.configureRuntime("/work/engine/share/darktable","/work/engine/lib/darktable",rt.toString());
  long active=0,batch=0,next=0;
  try {
   if(args[2].equals("reopen")){
    active=c.open(source.toString());NativeCatalog.INSTANCE.restore(source.toString(),Path.of(source+".xmp").toFile());var sidecar=root.resolve("reopened.xmp");d.writeSidecar(source.toString(),sidecar.toString());var doc=xml(sidecar);
    check(rating(doc)==4,"Rating lost on process restart");
    check(items(doc,"http://darktable.sf.net/","colorlabels").equals(Set.of("0","2","4")),"Colors lost on restart");
    check(items(doc,"http://ns.adobe.com/lightroom/1.0/","hierarchicalSubject").containsAll(expectedTags()),"Tags lost on restart");
    check(Arrays.equals(Files.readAllBytes(root.resolve("expected.rgba")),c.renderPreview(active,512,512,new int[2])),"Metadata restart altered processing");
    Files.writeString(root.resolve("reopen-result.json"),new JSONObject().put("rating_colors_tags_persist",true).put("processing_pixel_exact",true).toString(2));
    return;
   }
   Files.copy(Path.of(args[0]),source,StandardCopyOption.REPLACE_EXISTING);Files.deleteIfExists(Path.of(source+".xmp"));active=c.open(source.toString());
   c.setParameter(active,"exposure","exposure",0.75);c.setParameter(active,"exposure","mask.add.circle",1);
   byte[] before=c.renderPreview(active,512,512,new int[2]);
   d.setCatalogMarks(source.toString(),-1,31,new String[]{"old|tag"});var sidecar=Path.of(source+".xmp");d.writeSidecar(source.toString(),sidecar.toString());
   check(rating(xml(sidecar))==-1,"Rejection not written");
   d.setCatalogMarks(source.toString(),4,21,expectedTags().toArray(String[]::new));d.writeSidecar(source.toString(),sidecar.toString());
   var doc=xml(sidecar);check(rating(doc)==4,"Rating did not clear rejection");
   check(items(doc,"http://darktable.sf.net/","colorlabels").equals(Set.of("0","2","4")),"Multiple color labels differ");
   var tags=items(doc,"http://ns.adobe.com/lightroom/1.0/","hierarchicalSubject");
   check(tags.containsAll(expectedTags())&&!tags.contains("old|tag"),"Tag replacement or Unicode/comma escaping failed");
   try{d.setCatalogMarks(source.toString(),0,0,new String[]{"valid","darktable|private"});throw new AssertionError("Reserved tag accepted");}catch(Throwable expected){check(expected instanceof java.io.IOException,"unexpected error: "+expected);}
   var rejected=root.resolve("after-invalid.xmp");d.writeSidecar(source.toString(),rejected.toString());check(rating(xml(rejected))==4,"Rejected request changed rating");
   check(Arrays.equals(before,c.renderPreview(active,512,512,new int[2])),"Catalog editing altered pixels");
   Files.write(root.resolve("expected.rgba"),before);
   // Reproduce the app's frozen-XMP, separate-original batch route while an editor is alive.
   var queue=root.resolve("batch");Files.createDirectories(queue);var copy=queue.resolve(source.getFileName());Files.copy(source,copy,StandardCopyOption.REPLACE_EXISTING);Files.copy(sidecar,Path.of(copy+".xmp"),StandardCopyOption.REPLACE_EXISTING);
   // Later editor changes must not leak into the queued image.
   c.setParameter(active,"exposure","exposure",1.25);byte[] later=c.renderPreview(active,512,512,new int[2]);
   batch=c.open(copy.toString());NativeCatalog.INSTANCE.restore(copy.toString(),Path.of(copy+".xmp").toFile());check(Arrays.equals(before,c.renderPreview(batch,512,512,new int[2])),"Batch did not restore captured processing");
   int[] settings={512,512,95,0,-1,-1,-1,-1,0,1,0,0};
   c.exportWithSettings(batch,queue.resolve("output.png").toString(),"png",settings);check(Files.size(queue.resolve("output.png"))>100,"Batch output missing");
   c.cancel(batch);c.close(batch);batch=0;
   check(Arrays.equals(later,c.renderPreview(active,512,512,new int[2])),"Batch changed the active editor");
   c.setParameter(active,"exposure","exposure",0.75);d.writeSidecar(source.toString(),sidecar.toString());
   Files.writeString(root.resolve("save-result.json"),new JSONObject().put("native_catalog_saved",true).put("invalid_tag_rejected_before_mutation",true).put("metadata_pixel_exact",true).put("batch_captured_processing",true).put("active_editor_unchanged_after_batch",true).put("native_png_export",true).toString(2));
  }finally{if(next!=0)c.close(next);if(batch!=0)c.close(batch);if(active!=0)c.close(active);}
 }
}
