set -eu
mkdir -p /work/catalog-jni
cc -std=c11 -shared -fPIC -Wall -Wextra -Werror -I/jdk/include -I/jdk/include/linux /workspace/darktable-android/android/desktop-bridge/desktop_bridge.c -L/work/engine/bin -ldarktable $(pkg-config --libs glib-2.0) -Wl,-rpath,/work/engine/bin -Wl,--no-undefined -o /work/catalog-jni/libdarkroom_desktop.so
/jdk/bin/javac -encoding UTF-8 -cp /audit/classes:/stdlib.jar:/json.jar -d /work/catalog-jni /audit/CatalogBatchProbe.java
export OMP_NUM_THREADS=2 LANG=C.UTF-8 LC_ALL=C.UTF-8
for entry in 'rgb:/workspace/darktable-android/data/style/image-1.jpg' 'nef:/raws/2249.NEF' 'raf:/raws/2783.RAF'; do
 label=${entry%%:*}; source=${entry#*:}
 for mode in save reopen; do
  /jdk/bin/java -Xint -Djava.library.path=/work/catalog-jni:/work/jni -cp /work/catalog-jni:/audit/classes:/stdlib.jar:/json.jar CatalogBatchProbe "$source" "/audit/native-$label" "$mode" > "/audit/$label-$mode.log" 2>&1
  printf 'PASS %s %s\n' "$label" "$mode"
 done
done
