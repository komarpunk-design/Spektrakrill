import os,subprocess
from pathlib import Path
root='/workspace/artifacts/darkroom-desktop-050-20261128'
env=dict(os.environ)
for k in ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:env.pop(k,None)
cmd=['docker','--host=unix:///var/run/docker.sock','run','--rm','--name','darkroom-native-presets-050','--network=none','--cpus=4','--memory=6g','--memory-swap=6g','--pids-limit=512','--user',f'{os.getuid()}:{os.getgid()}','-e','HOME=/work/home','-e','OMP_NUM_THREADS=2','--mount','type=bind,src=/workspace/darktable-android,dst=/workspace/darktable-android,readonly','--mount','type=bind,src=/workspace/darktable-audit-build,dst=/work','--mount',f'type=bind,src={root},dst=/audit','--mount','type=bind,src=/workspace/scratch/darktable-gpr-source/gpr-446c736a38fb14f51343605c0780d347dc602f89,dst=/gpr,readonly','--mount','type=bind,src=/workspace/android-toolchain/jdk,dst=/jdk,readonly','--mount','type=bind,src=/workspace/android-toolchain/darktable-gradle-home/caches/modules-2/files-2.1/org.jetbrains.kotlin/kotlin-stdlib/2.1.20/aa8ca79cd50578314f6d1180c47cbe14c0fee567/kotlin-stdlib-2.1.20.jar,dst=/stdlib.jar,readonly','--mount','type=bind,src=/workspace/android-toolchain/darktable-gradle-home/caches/modules-2/files-2.1/org.json/json/20240303/ebb88e8fb5122b7506d5cf1d69f1ccdb790d22a/json-20240303.jar,dst=/json.jar,readonly','--mount','type=bind,src=/workspace/scratch/raw960-fixtures,dst=/raws,readonly','darkroom-audit-native:20261126','sh','/audit/run-native-presets.sh']
with open(root+'/native-presets-container.log','w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
print('Native audit container exit:',r.returncode)
raise SystemExit(r.returncode)
