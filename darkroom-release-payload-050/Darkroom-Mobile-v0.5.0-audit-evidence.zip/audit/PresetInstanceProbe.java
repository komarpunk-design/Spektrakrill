import org.example.darktableandroid.nativecore.*;
import org.example.darktableandroid.storage.*;
import java.nio.file.*;
import java.util.*;
import org.json.*;
public class PresetInstanceProbe {
 static final NativeCore c=NativeCore.INSTANCE;
 static final NativeDesktop d=NativeDesktop.INSTANCE;
 static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);}
 static byte[] preview(long h){c.renderPreview(h,512,512,new int[2]);return c.renderPreview(h,512,512,new int[2]);}
 static byte[] sidecar(Path source,Path output)throws Exception{d.writeSidecar(source.toString(),output.toString());return Files.readAllBytes(output);}
 static ProcessingHistory history(byte[] bytes){return ProcessingHistoryKt.processingHistory(bytes);}
 static ProcessingRow row(byte[] bytes,String id){return history(bytes).getLatest().stream().filter(r->r.getIdentifier().equals(id)).findFirst().orElseThrow();}
 static long reopen(long old,Path source,byte[] bytes)throws Exception {
  Files.write(Path.of(source+".xmp"),bytes);c.cancel(old);long next=c.open(source.toString());c.close(old);return next;
 }
 public static void main(String[] args)throws Exception {
  Path root=Path.of(args[1]);Files.createDirectories(root);Path input=Path.of(args[0]);
  Path source=root.resolve("source."+input.getFileName().toString().replaceAll("^.*\\.",""));Files.copy(input,source,StandardCopyOption.REPLACE_EXISTING);Files.deleteIfExists(Path.of(source+".xmp"));
  Path rt=root.resolve("runtime");Files.createDirectories(rt);c.configureRuntime("/work/engine/share/darktable","/work/engine/lib/darktable",rt.toString());
  long h=c.open(source.toString());
  try {
   byte[] original=preview(h);
   Path bank=root.resolve("factory");Files.createDirectories(bank);d.exportModulePresets("monochrome",bank.toString());
   List<Path> exported;try(var paths=Files.walk(bank)){exported=paths.filter(p->p.toString().endsWith(".dtpreset")).toList();}
   check(!exported.isEmpty(),"No original monochrome presets exported");
   ModulePreset preset=ModulePresetsKt.readModulePreset(Files.readAllBytes(exported.get(0)),exported.get(0).toFile(),true);
   byte[] before=sidecar(source,root.resolve("before-preset.xmp"));
   var converted=ModulePresetsKt.modulePresetStyle(preset,null,"monochrome");Path style=root.resolve("preset.dtstyle");Files.write(style,converted.getSecond());
   Path output=root.resolve("preset.xmp");d.writeStyledSidecar(source.toString(),style.toString(),converted.getFirst(),output.toString(),false);
   byte[] next=Files.readAllBytes(output);ProcessingHistoryKt.assertOnlyInstanceChanged(before,next,"monochrome");
   check(Arrays.equals(ProcessingHistoryKt.decodedParameters(preset.getParams()),ProcessingHistoryKt.decodedParameters(row(next,"monochrome").getParams())),"Factory parameters differ");
   h=reopen(h,source,next);check(!Arrays.equals(original,preview(h)),"Factory preset did not affect pixels");
   c.setParameter(h,"exposure","exposure",.75);c.setParameter(h,"exposure","mask.add.circle",1);
   byte[] withMask=sidecar(source,root.resolve("before-copy.xmp"));ProcessingRow sourceRow=row(withMask,"exposure");
   Path selection=root.resolve("selected");Files.createDirectories(selection);
   byte[] selected=NativeStyleSelection.INSTANCE.exportCurrent(source.toFile(),withMask,selection.toFile(),"Selected exposure",List.of(sourceRow.getIdentifier()),false);
   var selectedDoc=javax.xml.parsers.DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new java.io.ByteArrayInputStream(selected));
   check(selectedDoc.getElementsByTagName("plugin").getLength()==1,"Selective style exported other tools");
   byte[] ownPreset=ModulePresetsKt.presetFromStyle(selected,"My masked exposure");Path ownFile=root.resolve("own.dtpreset");Files.write(ownFile,ownPreset);
   ModulePreset own=ModulePresetsKt.readModulePreset(ownPreset,ownFile.toFile(),false);
   check(Arrays.equals(ProcessingHistoryKt.decodedParameters(sourceRow.getParams()),ProcessingHistoryKt.decodedParameters(own.getParams())),"Own preset changed native parameters");
   check(ProcessingHistoryKt.decodedParameters(own.getBlend()).length>ProcessingHistoryKt.decodedParameters(sourceRow.getBlend()).length,"Saved preset did not embed mask forms");
   String copiedId=c.newInstance(h,"exposure");byte[] intermediate=sidecar(source,root.resolve("intermediate.xmp"));
   byte[] copied=ProcessingHistoryKt.copiedInstance(intermediate,"exposure",copiedId);
   Files.write(root.resolve("copied.xmp"),copied);ProcessingHistoryKt.assertOnlyInstanceChanged(withMask,copied,copiedId);
   check(Arrays.equals(ProcessingHistoryKt.decodedParameters(sourceRow.getParams()),ProcessingHistoryKt.decodedParameters(row(copied,copiedId).getParams())),"Copy lost parameters");
   check(!row(copied,copiedId).getBlend().isEmpty(),"Copy lost blending");
   h=reopen(h,source,copied);byte[] pixels=preview(h);
   byte[] canonical=sidecar(source,root.resolve("pre-rename.xmp"));byte[] renamed=ProcessingHistoryKt.renamedInstance(canonical,copiedId,"Свет 📷");
   h=reopen(h,source,renamed);check(Arrays.equals(pixels,preview(h)),"Rename altered pixels");
   check(c.listModules(h).contains("Свет 📷"),"Native module did not retain the new name");
   c.setParameter(h,copiedId,"exposure",1.25);byte[] afterEdit=sidecar(source,root.resolve("after-edit.xmp"));
   check(Arrays.equals(ProcessingHistoryKt.decodedParameters(sourceRow.getParams()),ProcessingHistoryKt.decodedParameters(row(afterEdit,"exposure").getParams())),"Editing clone changed source");
   byte[] full=sidecar(source,root.resolve("full.xmp"));String text=new String(ProcessingHistoryKt.historyAtPosition(full,0),java.nio.charset.StandardCharsets.UTF_8);
   h=reopen(h,source,text.getBytes(java.nio.charset.StandardCharsets.UTF_8));check(Arrays.equals(original,preview(h)),"Native history position zero differs from original processing");
   byte[] earlier=sidecar(source,root.resolve("earlier.xmp"));check(history(text.getBytes(java.nio.charset.StandardCharsets.UTF_8)).getEnd()==0,"Stored navigation position not retained");
   check(history(text.getBytes(java.nio.charset.StandardCharsets.UTF_8)).getRows().size()==history(full).getRows().size(),"Stored future history rows were discarded");
   h=reopen(h,source,ProcessingHistoryKt.historyAtPosition(text.getBytes(java.nio.charset.StandardCharsets.UTF_8),history(full).getEnd()));preview(h);
   byte[] fullPixels=preview(h);
   Path reapply=root.resolve("reapply");Files.createDirectories(reapply);
   byte[] normalized=NativeStyleSelection.INSTANCE.normalize(source.toString(),reapply.toFile());
   var ownStyle=ModulePresetsKt.modulePresetStyle(own,row(normalized,"exposure"),"exposure");
   Path ownStyleFile=reapply.resolve("own.dtstyle");Files.write(ownStyleFile,ownStyle.getSecond());
   Path reappliedFile=reapply.resolve("reapplied.xmp");d.writeStyledSidecar(source.toString(),ownStyleFile.toString(),ownStyle.getFirst(),reappliedFile.toString(),false);
   byte[] reapplied=Files.readAllBytes(reappliedFile);ProcessingHistoryKt.assertOnlyInstanceChanged(normalized,reapplied,"exposure");
   h=reopen(h,source,reapplied);check(Arrays.equals(fullPixels,preview(h)),"Portable masked preset did not reproduce its processing");
   int[] settings={512,512,95,0,-1,-1,-1,-1,0,1,0,0};c.exportWithSettings(h,root.resolve("result.png").toString(),"png",settings);
   Files.writeString(root.resolve("result.json"),new JSONObject().put("original_factory_presets",exported.size()).put("factory_parameters_exact",true).put("factory_changes_pixels",true)
    .put("selected_style_one_tool",true).put("custom_dtpreset_parameters_exact",true).put("copy_keeps_source",true).put("rename_pixel_exact",true).put("history_zero_pixel_exact",true).put("future_history_retained",true).put("native_export",true).put("portable_masked_preset_reapplied_pixel_exact",true).toString(2));
  }finally{c.close(h);}
 }
}
