/* SPDX-License-Identifier: GPL-3.0-or-later */
#include <jni.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
/* Public upstream ABI from common/image.h and common/exif.h, at the pinned
 * revision. No private session layout or processing implementation is copied.
 * Calls must run on the same serialized owner as NativeCore edits/exports. */
extern int32_t dt_image_get_id_full_path(const char *filename);
extern int dt_exif_xmp_write(int32_t image_id, const char *filename, int force_write);
extern int dt_styles_exists(const char *name);
extern void dt_styles_delete_by_name(const char *name);
extern int dt_styles_create_from_image(const char *name, const char *description,
                                       int32_t image_id, void *items, int copy_order);
extern void dt_styles_save_to_file(const char *name, const char *directory, int overwrite);
extern void dt_styles_import_from_file(const char *path);
extern void dt_styles_apply_to_image(const char *name, int duplicate, int overwrite, int32_t image_id);
extern char *dt_styles_history_pixel_mask_modules(int32_t image_id, void *items);
extern void g_free(void *data);
/* GList is a stable public GLib ABI, not a private darktable session. */
typedef struct _GList GList;
extern GList *g_list_append(GList *list, void *data);
extern void g_list_free(GList *list);
extern void dt_ratings_apply_on_image(int32_t id, int rating, int toggle, int undo, int group);
extern void dt_colorlabels_remove_all_labels(int32_t id);
extern void dt_colorlabels_set_label(int32_t id, int color);
extern int dt_tag_new(const char *name, unsigned int *id);
extern int dt_tag_set_tags(const GList *tags, const GList *images, int ignore_internal, int clear, int undo);
extern void g_list_foreach(GList *list, void (*callback)(void *, void *), void *data);
extern void g_list_free_full(GList *list, void (*destroy)(void *));
extern int g_mkdir_with_parents(const char *path, int mode);
/* public value record from common/presets.h, not a session or module layout */
typedef struct {
  int rowid; char *name; int op_version; void *op_params; int op_params_size;
  int enabled; void *blendop_params; int blendop_params_size; int blendop_version;
  int writeprotect; char *multi_name; int multi_name_hand_edited; int autoapply;
} desktop_preset_params;
extern GList *dt_presets_list_stored(const char *operation);
extern void dt_presets_params_free(void *data);
extern void dt_presets_save_to_file(int rowid, const char *name, const char *directory);

static void throw_io(JNIEnv *env, const char *message)
{
  jclass type = (*env)->FindClass(env, "java/io/IOException");
  if(type) (*env)->ThrowNew(env, type, message);
}
static char *editor_text_utf8(JNIEnv *env, jstring text)
{
  const jsize count = (*env)->GetStringLength(env, text);
  if(count > 4096) { throw_io(env, "editor text exceeds the native buffer"); return NULL; }
  const jchar *characters = (*env)->GetStringChars(env, text, NULL);
  if(!characters) return NULL;
  char *result = malloc((size_t)count * 3 + 1);
  if(!result)
  {
    (*env)->ReleaseStringChars(env, text, characters);
    throw_io(env, "unable to allocate editor text"); return NULL;
  }
  size_t used = 0;
  for(jsize k = 0; k < count; k++)
  {
    uint32_t code = characters[k];
    if(!code || (code >= 0xDC00 && code <= 0xDFFF)) goto invalid;
    if(code >= 0xD800 && code <= 0xDBFF)
    {
      if(k + 1 >= count || characters[k + 1] < 0xDC00 || characters[k + 1] > 0xDFFF) goto invalid;
      code = 0x10000 + ((code - 0xD800) << 10) + (characters[++k] - 0xDC00);
    }
    if(code < 0x80) result[used++] = (char)code;
    else if(code < 0x800)
    {
      result[used++] = (char)(0xC0 | (code >> 6));
      result[used++] = (char)(0x80 | (code & 0x3F));
    }
    else if(code < 0x10000)
    {
      result[used++] = (char)(0xE0 | (code >> 12));
      result[used++] = (char)(0x80 | ((code >> 6) & 0x3F));
      result[used++] = (char)(0x80 | (code & 0x3F));
    }
    else
    {
      result[used++] = (char)(0xF0 | (code >> 18));
      result[used++] = (char)(0x80 | ((code >> 12) & 0x3F));
      result[used++] = (char)(0x80 | ((code >> 6) & 0x3F));
      result[used++] = (char)(0x80 | (code & 0x3F));
    }
  }
  result[used] = 0;
  (*env)->ReleaseStringChars(env, text, characters);
  return result;
invalid:
  free(result);
  (*env)->ReleaseStringChars(env, text, characters);
  throw_io(env, "editor text must be valid Unicode without NUL characters");
  return NULL;
}

JNIEXPORT void JNICALL Java_org_example_darktableandroid_nativecore_NativeDesktop_setCatalogMarks(
    JNIEnv *env, jobject self, jstring source, jint rating, jint colors, jobjectArray tags)
{
  (void)self;
  if(!source || !tags || rating < -1 || rating > 5 || colors < 0 || colors > 31)
  { throw_io(env, "invalid catalog values"); return; }
  const jsize count = (*env)->GetArrayLength(env, tags);
  if(count > 1024 * 1024) { throw_io(env, "catalog tag list exceeds the XMP safety budget"); return; }
  char *input = editor_text_utf8(env, source);
  if(!input) return;
  const int32_t id = dt_image_get_id_full_path(input);
  free(input);
  if(id <= 0) { throw_io(env, "catalog source is not open"); return; }
  char **names = calloc(count ? (size_t)count : 1, sizeof(*names));
  if(!names) { throw_io(env, "unable to allocate catalog tag list"); return; }
  GList *ids = NULL;
  for(jsize i = 0; i < count; i++)
  {
    jstring tag = (*env)->GetObjectArrayElement(env, tags, i);
    if(!tag) { throw_io(env, "null catalog tag"); goto done; }
    names[i] = editor_text_utf8(env, tag);
    (*env)->DeleteLocalRef(env, tag);
    if(!names[i]) goto done;
    if(!names[i][0] || !strncmp(names[i], "darktable|", 10))
    { throw_io(env, "invalid catalog tag"); goto done; }
  }
  /* Validate every value before changing the image. Tag dictionary additions
   * are harmless if a later allocation fails; image assignments stay untouched. */
  for(jsize i = 0; i < count; i++)
  {
    unsigned int tag_id = 0;
    if(!dt_tag_new(names[i], &tag_id) || !tag_id)
    { throw_io(env, "could not create catalog tag"); goto done; }
    ids = g_list_append(ids, (void *)(uintptr_t)tag_id);
  }
  GList *images = g_list_append(NULL, (void *)(intptr_t)id);
  dt_tag_set_tags(ids, images, 1, 1, 0);
  g_list_free(images);
  dt_ratings_apply_on_image(id, rating == -1 ? 6 : rating, 0, 0, 0);
  dt_colorlabels_remove_all_labels(id);
  for(int i = 0; i < 5; i++) if(colors & (1 << i)) dt_colorlabels_set_label(id, i);
done:
  g_list_free(ids);
  for(jsize i = 0; i < count; i++) free(names[i]);
  free(names);
}

JNIEXPORT void JNICALL Java_org_example_darktableandroid_nativecore_NativeDesktop_writeSidecar(
    JNIEnv *env, jobject self, jstring source, jstring target)
{
  (void)self;
  if(!source || !target) { throw_io(env, "sidecar paths are required"); return; }
  char *input = editor_text_utf8(env, source);
  if(!input) return;
  char *output = editor_text_utf8(env, target);
  if(!output) { free(input); return; }
  if(input[0] != '/' || output[0] != '/' || !strcmp(input, output))
    throw_io(env, "sidecar requires separate absolute source and output paths");
  else
  {
    const int32_t id = dt_image_get_id_full_path(input);
    if(id <= 0) throw_io(env, "the sidecar source is not open in darktable");
    /* Upstream returns TRUE on error, FALSE on success. */
    else if(dt_exif_xmp_write(id, output, 1)) throw_io(env, "darktable could not write its XMP sidecar");
  }
  free(output);
  free(input);
}

JNIEXPORT void JNICALL Java_org_example_darktableandroid_nativecore_NativeDesktop_exportStyle(
    JNIEnv *env, jobject self, jstring source, jstring directory, jstring style_name)
{
  (void)self;
  if(!source || !directory || !style_name) { throw_io(env, "style arguments are required"); return; }
  char *input = editor_text_utf8(env, source);
  char *output = input ? editor_text_utf8(env, directory) : NULL;
  char *name = output ? editor_text_utf8(env, style_name) : NULL;
  if(name)
  {
    const int32_t id = dt_image_get_id_full_path(input);
    if(id <= 0 || output[0] != '/' || !name[0] || strlen(name) > 160)
      throw_io(env, "invalid style source, directory or name");
    else
    {
      /* This is the mobile engine's private ephemeral style database. Files in
       * the app library are immutable; replacing a DB cache entry cannot erase them. */
      if(dt_styles_exists(name)) dt_styles_delete_by_name(name);
      if(!dt_styles_create_from_image(name, "Darkroom Mobile", id, NULL, 1))
        throw_io(env, "darktable could not create the style");
      else dt_styles_save_to_file(name, output, 0);
    }
  }
  free(name); free(output); free(input);
}

JNIEXPORT void JNICALL Java_org_example_darktableandroid_nativecore_NativeDesktop_writeStyledSidecar(
    JNIEnv *env, jobject self, jstring source, jstring style_file, jstring style_name, jstring target, jboolean overwrite)
{
  (void)self;
  if(!source || !style_file || !style_name || !target) { throw_io(env, "style arguments are required"); return; }
  char *input = editor_text_utf8(env, source);
  char *file = input ? editor_text_utf8(env, style_file) : NULL;
  char *name = file ? editor_text_utf8(env, style_name) : NULL;
  char *output = name ? editor_text_utf8(env, target) : NULL;
  if(output)
  {
    const int32_t id = dt_image_get_id_full_path(input);
    if(id <= 0 || file[0] != '/' || output[0] != '/' || !strcmp(input, output) || !name[0])
      throw_io(env, "invalid style or sidecar path");
    else
    {
      if(dt_styles_exists(name)) dt_styles_delete_by_name(name);
      dt_styles_import_from_file(file);
      if(!dt_styles_exists(name)) throw_io(env, "darktable rejected the selected style");
      else
      {
        dt_styles_apply_to_image(name, 0, overwrite ? 1 : 0, id);
        if(dt_exif_xmp_write(id, output, 1)) throw_io(env, "darktable could not save the styled history");
      }
    }
  }
  free(output); free(name); free(file); free(input);
}

typedef struct { const char *directory; int failed; } preset_export;
static void _export_preset(void *value, void *user)
{
  const desktop_preset_params *preset = value;
  preset_export *export = user;
  char folder[8192];
  const int size = snprintf(folder, sizeof(folder), "%s/%d", export->directory, preset->rowid);
  if(size < 0 || (size_t)size >= sizeof(folder) || g_mkdir_with_parents(folder, 0700))
  { export->failed = 1; return; }
  dt_presets_save_to_file(preset->rowid, preset->name, folder);
}

JNIEXPORT void JNICALL Java_org_example_darktableandroid_nativecore_NativeDesktop_exportModulePresets(
    JNIEnv *env, jobject self, jstring operation, jstring directory)
{
  (void)self;
  if(!operation || !directory) { throw_io(env, "preset arguments are required"); return; }
  char *op = editor_text_utf8(env, operation);
  char *folder = op ? editor_text_utf8(env, directory) : NULL;
  if(folder)
  {
    if(!op[0] || strspn(op, "abcdefghijklmnopqrstuvwxyz0123456789_") != strlen(op) || folder[0] != '/')
      throw_io(env, "invalid preset operation or directory");
    else
    {
      GList *presets = dt_presets_list_stored(op);
      preset_export export = { folder, 0 };
      g_list_foreach(presets, _export_preset, &export);
      g_list_free_full(presets, dt_presets_params_free);
      if(export.failed) throw_io(env, "could not create preset output directories");
    }
  }
  free(folder); free(op);
}

JNIEXPORT void JNICALL Java_org_example_darktableandroid_nativecore_NativeDesktop_exportSelectedStyle(
    JNIEnv *env, jobject self, jstring source, jstring directory, jstring style_name,
    jintArray selected, jboolean copy_order)
{
  (void)self;
  if(!source || !directory || !style_name || !selected)
  { throw_io(env, "style selection is required"); return; }
  const jsize count = (*env)->GetArrayLength(env, selected);
  if(count < 1 || count > 1024) { throw_io(env, "invalid native style selection chunk"); return; }
  jint *numbers = (*env)->GetIntArrayElements(env, selected, NULL);
  if(!numbers) return;
  size_t length = 0;
  GList *items = NULL;
  for(jsize i = 0; i < count; i++)
  {
    char text[32];
    if(numbers[i] < 0) { throw_io(env, "invalid history row"); goto done; }
    length += (size_t)snprintf(text, sizeof(text), "%d,", numbers[i]);
    /* upstream styles.c builds a fixed-size SQL selection; never let it truncate */
    if(length >= 1900) { throw_io(env, "style selection must be split into smaller chunks"); goto done; }
    items = g_list_append(items, (void *)(intptr_t)numbers[i]);
  }
  char *input = editor_text_utf8(env, source);
  char *folder = input ? editor_text_utf8(env, directory) : NULL;
  char *name = folder ? editor_text_utf8(env, style_name) : NULL;
  if(name)
  {
    const int32_t id = dt_image_get_id_full_path(input);
    if(id <= 0 || folder[0] != '/' || !name[0] || strlen(name) > 160)
      throw_io(env, "invalid selected style source or name");
    else
    {
      char *pixels = dt_styles_history_pixel_mask_modules(id, items);
      if(pixels)
      {
        throw_io(env, "image-specific pixel masks cannot be saved in a portable style");
        g_free(pixels);
      }
      else
      {
        if(dt_styles_exists(name)) dt_styles_delete_by_name(name);
        if(!dt_styles_create_from_image(name, "Darkroom Mobile", id, items, copy_order ? 1 : 0))
          throw_io(env, "could not create the selected native style");
        else dt_styles_save_to_file(name, folder, 0);
      }
    }
  }
  free(name); free(folder); free(input);
done:
  g_list_free(items);
  (*env)->ReleaseIntArrayElements(env, selected, numbers, JNI_ABORT);
}
