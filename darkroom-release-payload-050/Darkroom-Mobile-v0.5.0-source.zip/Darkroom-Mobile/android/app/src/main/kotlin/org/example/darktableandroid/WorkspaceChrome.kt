/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.example.darktableandroid.nativecore.EditorModule

internal fun inspectorPreviewFraction(value: Float): Float =
    if(value.isFinite()) value.coerceIn(.30f, .72f) else .55f

internal fun boundedPreviewPan(pan: Offset, scale: Float, width: Float, height: Float,
                               imageWidth: Int, imageHeight: Int): Offset {
    val fit = fittedPreviewBounds(width, height, imageWidth, imageHeight) ?: return Offset.Zero
    val limitX = ((fit.width * scale - width) / 2f).coerceAtLeast(0f)
    val limitY = ((fit.height * scale - height) / 2f).coerceAtLeast(0f)
    return Offset(pan.x.coerceIn(-limitX, limitX), pan.y.coerceIn(-limitY, limitY))
}

@Composable
internal fun WorkspaceToolbar(ready: EditorState.Ready?, runtime: RuntimeAvailability, busy: Boolean,
                              onOpen: () -> Unit, onUndo: () -> Unit, onRedo: () -> Unit, onExport: () -> Unit,
                              extraActions: @Composable () -> Unit = {}) {
    Surface(modifier = Modifier.statusBarsPadding(), color = LocalEditorChromeColors.current.toolbar) {
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val showBrand = maxWidth >= 480.dp
            Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                IconButton(onOpen, enabled = runtime.available && !busy, modifier = Modifier.testTag("editor_open")) {
                    Icon(painterResource(R.drawable.workspace_ic_open), stringResource(R.string.open_photo))
                }
                if(showBrand)
                    Text(stringResource(R.string.desktop_brand), Modifier.weight(1f).padding(start = 4.dp),
                        style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                else Spacer(Modifier.weight(1f))
                IconButton(onUndo, enabled = !busy && ready?.history?.canUndo == true,
                    modifier = Modifier.testTag("editor_undo")) {
                    Icon(painterResource(R.drawable.workspace_ic_undo), stringResource(R.string.undo))
                }
                IconButton(onRedo, enabled = !busy && ready?.history?.canRedo == true,
                    modifier = Modifier.testTag("editor_redo")) {
                    Icon(painterResource(R.drawable.workspace_ic_redo), stringResource(R.string.redo))
                }
                FilledTonalButton(onExport, enabled = !busy && ready?.exportFormats?.isNotEmpty() == true,
                    contentPadding = PaddingValues(horizontal = 12.dp), modifier = Modifier.testTag("editor_export")) {
                    Icon(painterResource(R.drawable.workspace_ic_export), null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.export))
                }
                extraActions()
            }
        }
    }
}

@Composable
internal fun InspectorResizeHandle(wide: Boolean, fraction: Float, extent: Float, range: ClosedFloatingPointRange<Float> = .30f.. .72f,
                                  onFraction: (Float) -> Unit) {
    val description = stringResource(R.string.studio_resize)
    val drag = rememberDraggableState { delta ->
        if(extent > 0f) onFraction(inspectorPreviewFraction(fraction + delta / extent).coerceIn(range))
    }
    Box((if(wide) Modifier.width(24.dp).fillMaxHeight() else Modifier.height(24.dp).fillMaxWidth())
        .background(LocalEditorChromeColors.current.panel)
        .testTag("editor_resize_handle")
        .semantics {
            contentDescription = description
            progressBarRangeInfo = ProgressBarRangeInfo(fraction, range.start..range.endInclusive)
            setProgress { requested -> onFraction(inspectorPreviewFraction(requested).coerceIn(range)); true }
            onClick { onFraction(.55f.coerceIn(range)); true }
        }
        .draggable(drag, if(wide) Orientation.Horizontal else Orientation.Vertical),
        contentAlignment = Alignment.Center) {
        Box((if(wide) Modifier.width(4.dp).height(36.dp) else Modifier.width(36.dp).height(4.dp))
            .clip(CircleShape).background(MaterialTheme.colorScheme.outlineVariant))
    }
}

/** Zoom changes presentation only. Coordinate-sensitive native tools always see the untransformed photo. */
@Composable
internal fun WorkspacePhotoViewport(sessionId: Long, imageWidth: Int, imageHeight: Int, gesturesEnabled: Boolean,
                                    content: @Composable () -> Unit) {
    var scale by rememberSaveable(sessionId) { mutableFloatStateOf(1f) }
    var panX by rememberSaveable(sessionId) { mutableFloatStateOf(0f) }
    var panY by rememberSaveable(sessionId) { mutableFloatStateOf(0f) }
    LaunchedEffect(gesturesEnabled, imageWidth, imageHeight) {
        scale = 1f; panX = 0f; panY = 0f
    }
    BoxWithConstraints(Modifier.fillMaxSize().clipToBounds().testTag("editor_photo_viewport")) {
        val density = LocalDensity.current
        val width = with(density) { maxWidth.toPx() }
        val height = with(density) { maxHeight.toPx() }
        val pan = boundedPreviewPan(Offset(panX, panY), scale, width, height, imageWidth, imageHeight)
        val gestureModifier = if(gesturesEnabled) Modifier
            .pointerInput(sessionId, width, height, imageWidth, imageHeight) {
                detectTransformGestures { centroid, movement, zoom, _ ->
                    val nextScale = (scale * zoom).coerceIn(1f, 8f)
                    val centre = Offset(width / 2f, height / 2f)
                    val proposed = (Offset(panX, panY) - (centroid - centre)) * (nextScale / scale) +
                        (centroid - centre) + movement
                    val bounded = boundedPreviewPan(proposed, nextScale, width, height, imageWidth, imageHeight)
                    scale = nextScale; panX = bounded.x; panY = bounded.y
                }
            }.pointerInput(sessionId, width, height) {
                detectTapGestures(onDoubleTap = {
                    scale = if(scale > 1f) 1f else 2f
                    panX = 0f; panY = 0f
                })
            } else Modifier
        Box(Modifier.fillMaxSize().then(gestureModifier)) {
            Box(Modifier.fillMaxSize().graphicsLayer {
                scaleX = scale; scaleY = scale; translationX = pan.x; translationY = pan.y
            }) { content() }
        }
        if(scale > 1f) FilledTonalButton(onClick = { scale = 1f; panX = 0f; panY = 0f },
            modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).testTag("editor_zoom_reset")) {
            Text(stringResource(R.string.studio_fit_photo))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun WorkspaceToolCatalog(modules: List<EditorModule>, selected: String?, busy: Boolean,
                                  onDismiss: () -> Unit, onSelect: (String) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var enabledOnly by rememberSaveable { mutableStateOf(false) }
    val results = filterEditingTools(modules, query, enabledOnly)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).testTag("editor_tool_catalog")) {
            Text(stringResource(R.string.studio_tool_catalog), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.studio_tool_catalog_hint), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(query, { query = it }, singleLine = true,
                    label = { Text(stringResource(R.string.tools_search)) },
                    modifier = Modifier.weight(1f).testTag("editor_catalog_search"))
                FilterChip(enabledOnly, { enabledOnly = !enabledOnly }, label = { Text(stringResource(R.string.tools_enabled)) })
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 440.dp)) {
                if(results.isEmpty()) item { Text(stringResource(R.string.tools_no_matches), Modifier.padding(16.dp)) }
                items(results, key = { it.operation }) { module ->
                    Surface(onClick = { onSelect(module.operation) }, enabled = !busy,
                        shape = MaterialTheme.shapes.medium,
                        color = if(module.operation == selected) MaterialTheme.colorScheme.secondaryContainer
                            else MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxWidth().testTag("editor_catalog_${module.operation}")) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 12.dp).heightIn(min = 36.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(if(module.enabled)
                                MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant))
                            Column(Modifier.weight(1f)) {
                                Text(module.name, fontWeight = if(module.operation == selected) FontWeight.SemiBold else FontWeight.Normal)
                                Text(module.operation, style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(stringResource(if(module.enabled) R.string.workspace_enabled else R.string.workspace_disabled),
                                style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
internal fun WorkspaceControlSection(title: Int, count: Int, content: @Composable () -> Unit) {
    var expanded by rememberSaveable { mutableStateOf(false) }
    val expandedState = stringResource(if(expanded) R.string.studio_expanded else R.string.studio_collapsed)
    HorizontalDivider(Modifier.padding(vertical = 4.dp))
    TextButton(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()
        .testTag("editor_section_$title").semantics { stateDescription = expandedState }) {
        Text(stringResource(title), Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
        Text("$count", style = MaterialTheme.typography.labelMedium)
        Icon(painterResource(R.drawable.workspace_ic_expand), null,
            Modifier.padding(start = 8.dp).graphicsLayer { rotationZ = if(expanded) 180f else 0f })
    }
    if(expanded) content()
}

@Composable
internal fun WorkspaceConfirmDialog(title: Int, message: Int, confirm: Int,
                                     onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(stringResource(title)) }, text = { Text(stringResource(message)) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(stringResource(confirm)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.studio_keep_working)) } })
}

@Composable
internal fun WorkspaceWelcome(state: EditorState, runtime: RuntimeAvailability, onOpen: () -> Unit,
                               onRetry: (android.net.Uri) -> Unit, onCancel: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp).testTag("editor_welcome")
        .verticalScroll(androidx.compose.foundation.rememberScrollState()),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.Start) {
        Icon(painterResource(R.drawable.workspace_ic_open), null, Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.workspace_choose_photo), style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.studio_welcome_hint), style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        when {
            runtime.checking || state is EditorState.Working -> {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(stringResource(R.string.studio_preparing))
                if(state is EditorState.Working) TextButton(onClick = onCancel,
                    enabled = state.stage != EditorState.Stage.CANCELLING) { Text(stringResource(R.string.cancel)) }
            }
            state is EditorState.Failed -> {
                Text(state.message, color = MaterialTheme.colorScheme.error)
                state.source?.let { source -> TextButton(onClick = { onRetry(source) }) { Text(stringResource(R.string.retry)) } }
            }
            !runtime.available -> Text(runtime.message ?: stringResource(R.string.engine_unavailable),
                color = MaterialTheme.colorScheme.error)
        }
        Button(onOpen, enabled = runtime.available && state !is EditorState.Working,
            modifier = Modifier.heightIn(min = 52.dp).testTag("editor_welcome_open")) {
            Icon(painterResource(R.drawable.workspace_ic_open), null, Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(stringResource(R.string.open_photo))
        }
        Spacer(Modifier.height(24.dp))
        HorizontalDivider()
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.studio_welcome_process), style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(8.dp))
        Text(stringResource(R.string.studio_original_safe), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
    }
}
