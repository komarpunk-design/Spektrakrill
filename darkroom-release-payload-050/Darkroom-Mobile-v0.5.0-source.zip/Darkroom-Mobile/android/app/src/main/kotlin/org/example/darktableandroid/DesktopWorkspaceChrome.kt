/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.example.darktableandroid.storage.*
import org.example.darktableandroid.nativecore.EditorModule
import java.io.File

@Composable
internal fun DesktopModeBar(lighttable: Boolean, ready: Boolean, history: Boolean, tools: Boolean,
    onMode: (Boolean) -> Unit, onHistory: () -> Unit, onTools: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(LocalEditorChromeColors.current.toolbar), verticalAlignment = Alignment.CenterVertically) {
        TextButton({ onMode(true) }, modifier = Modifier.weight(1f).testTag("desktop_lighttable")) {
            Text(stringResource(R.string.desktop_lighttable), color = if(lighttable) MaterialTheme.colorScheme.onSurface else
                MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
        TextButton({ onMode(false) }, enabled = ready, modifier = Modifier.weight(1f).testTag("desktop_darkroom")) {
            Text(stringResource(R.string.desktop_darkroom), color = if(!lighttable) MaterialTheme.colorScheme.onSurface else
                MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
        IconButton(onHistory, enabled = ready && !lighttable, modifier = Modifier.testTag("desktop_history_toggle")) {
            Icon(painterResource(R.drawable.workspace_ic_undo), stringResource(if(history) R.string.desktop_hide_history else R.string.desktop_show_history))
        }
        if(!ready) TextButton(onTools, modifier = Modifier.testTag("desktop_tools_toggle")) {
            Text(stringResource(R.string.workspace_tab_settings))
        } else IconButton(onTools, modifier = Modifier.testTag("desktop_tools_toggle")) {
            Icon(painterResource(R.drawable.workspace_ic_adjust), stringResource(if(tools) R.string.desktop_hide_tools else R.string.desktop_show_tools))
        }
    }
    HorizontalDivider()
}

@Composable
private fun PhotoThumbnail(project: PhotoProject, modifier: Modifier) {
    val context = LocalContext.current
    val thumbnail by produceState<Pair<android.graphics.Bitmap?, Boolean>>(null to false, project.id, project.updated) {
        value = withContext(Dispatchers.IO) {
            val cached = android.graphics.BitmapFactory.decodeFile(project.thumbnail.path)
            if(cached != null) cached to true else {
                val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                android.graphics.BitmapFactory.decodeFile(project.source.path, bounds)
                val direct = if(bounds.outWidth > 0 && bounds.outHeight > 0) {
                    val options = android.graphics.BitmapFactory.Options().apply {
                        inSampleSize = (maxOf(bounds.outWidth, bounds.outHeight) / 320).coerceAtLeast(1)
                    }
                    android.graphics.BitmapFactory.decodeFile(project.source.path, options)
                } else null
                val provided = direct ?: runCatching {
                    val uri = android.net.Uri.parse(project.sourceUri)
                    if(android.os.Build.VERSION.SDK_INT >= 29)
                        context.contentResolver.loadThumbnail(uri, android.util.Size(320, 240), null)
                    else {
                        @Suppress("DEPRECATION")
                        android.provider.DocumentsContract.getDocumentThumbnail(context.contentResolver, uri, android.graphics.Point(320, 240), null)
                    }
                }.getOrNull()
                provided to false
            }
        }
    }
    Box(modifier.background(LocalEditorChromeColors.current.preview), contentAlignment = Alignment.Center) {
        thumbnail.first?.let {
            Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            if(!thumbnail.second) Text(stringResource(R.string.desktop_source_preview),
                Modifier.align(Alignment.BottomStart).background(MaterialTheme.colorScheme.surface.copy(alpha = .85f)).padding(3.dp),
                style = MaterialTheme.typography.labelSmall)
        } ?: Icon(painterResource(R.drawable.workspace_ic_open), null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun DesktopFilmstrip(photos: List<CatalogPhoto>, active: String?, enabled: Boolean, onOpen: (String) -> Unit) {
    if(photos.isEmpty()) return
    LazyRow(Modifier.fillMaxWidth().height(84.dp).background(LocalEditorChromeColors.current.toolbar)
        .testTag("desktop_filmstrip"), contentPadding = PaddingValues(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items(photos, key = { it.project.id }) { photo ->
            Surface(onClick = { onOpen(photo.project.id) }, enabled = enabled,
                shape = MaterialTheme.shapes.extraSmall,
                modifier = Modifier.width(92.dp).fillMaxHeight().border(if(active == photo.project.id) 2.dp else 0.dp,
                    if(active == photo.project.id) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant)
                    .testTag("filmstrip_${photo.project.id}")) {
                Column(Modifier.padding(3.dp)) {
                    PhotoThumbnail(photo.project, Modifier.fillMaxWidth().weight(1f))
                    Text(photo.project.name, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun DesktopLighttable(photos: List<CatalogPhoto>, enabled: Boolean, canExport: Boolean,
    onImport: () -> Unit, onOpen: (String) -> Unit, onExport: (List<String>) -> Unit, notice: String? = null) {
    var query by rememberSaveable { mutableStateOf("") }
    var stars by rememberSaveable { mutableIntStateOf(0) }
    var rejected by rememberSaveable { mutableStateOf(false) }
    var sort by rememberSaveable { mutableStateOf(CatalogSort.RECENT.name) }
    var color by rememberSaveable { mutableIntStateOf(-1) }
    var colorsOpen by remember { mutableStateOf(false) }
    var selected by rememberSaveable { mutableStateOf(listOf<String>()) }
    val filtered = remember(photos, query, stars, rejected, sort, color) {
        CatalogQuery(query, stars, rejected, color.takeIf { it >= 0 }, CatalogSort.valueOf(sort)).select(photos)
    }
    val selection = selected.filter { id -> photos.any { it.project.id == id } }
    Column(Modifier.fillMaxSize().padding(8.dp).testTag("desktop_contact_sheet")) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(query, { query = it }, singleLine = true, modifier = Modifier.weight(1f).testTag("lighttable_search"),
                label = { Text(stringResource(R.string.catalog_search)) })
            OutlinedButton(onImport, enabled = enabled) { Text(stringResource(R.string.catalog_import)) }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(stars == 0 && !rejected, { stars = 0; rejected = false }, label = { Text(stringResource(R.string.module_presets_all)) })
            for(value in 1..5) FilterChip(stars == value && !rejected, { stars = value; rejected = false }, label = { Text("$value★+") })
            FilterChip(rejected, { rejected = !rejected }, label = { Text(stringResource(R.string.catalog_rejected)) })
            Box {
                val labels = listOf(R.string.catalog_red, R.string.catalog_yellow, R.string.catalog_green, R.string.catalog_blue, R.string.catalog_purple)
                AssistChip({ colorsOpen = true }, label = { Text(stringResource(if(color < 0) R.string.catalog_marks else labels[color])) })
                DropdownMenu(colorsOpen, { colorsOpen = false }) {
                    DropdownMenuItem({ Text(stringResource(R.string.module_presets_all)) }, { color = -1; colorsOpen = false })
                    labels.forEachIndexed { index, label -> DropdownMenuItem({ Text(stringResource(label)) }, { color = index; colorsOpen = false }) }
                }
            }
            AssistChip({ sort = CatalogSort.entries[(CatalogSort.valueOf(sort).ordinal + 1) % CatalogSort.entries.size].name }, label = {
                Text(stringResource(when(CatalogSort.valueOf(sort)) {
                    CatalogSort.RECENT -> R.string.catalog_recent
                    CatalogSort.NAME -> R.string.catalog_name
                    CatalogSort.RATING -> R.string.catalog_rating
                }))
            })
        }
        notice?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        Text(stringResource(R.string.desktop_contact_hint), style = MaterialTheme.typography.bodySmall)
        if(filtered.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
            Text(stringResource(if(photos.isEmpty()) R.string.studio_welcome_hint else R.string.catalog_empty),
                Modifier.widthIn(max = 320.dp).padding(16.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        } else LazyVerticalGrid(GridCells.Adaptive(136.dp), Modifier.fillMaxWidth().weight(1f),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filtered, key = { it.project.id }) { photo ->
                val project = photo.project
                val chosen = project.id in selected
                Column(Modifier.background(if(project.id in selected) LocalEditorChromeColors.current.selection else LocalEditorChromeColors.current.panel)
                    .border(1.dp, if(project.id in selected) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant)
                    .combinedClickable(enabled = enabled, onClick = {
                        selected = if(project.id in selected) selected - project.id else selected + project.id
                    }, onDoubleClick = { onOpen(project.id) }).semantics { this.selected = chosen }
                    .padding(6.dp).testTag("contact_${project.id}")) {
                    PhotoThumbnail(project, Modifier.fillMaxWidth().aspectRatio(1.3f))
                    Text(project.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(photo.marks?.let { if(it.rating < 0) "×" else "${it.rating} ★" }.orEmpty(), Modifier.weight(1f),
                            style = MaterialTheme.typography.labelSmall)
                        TextButton({ onOpen(project.id) }, enabled = enabled) { Text(stringResource(R.string.desktop_edit_photo)) }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.catalog_count, filtered.size, selection.size), Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            TextButton({ selected = if(selection.isEmpty()) filtered.map { it.project.id } else emptyList() }) {
                Text(stringResource(if(selection.isEmpty()) R.string.catalog_select_visible else R.string.catalog_clear))
            }
        }
        Button({ onExport(selection) }, enabled = enabled && canExport && selection.isNotEmpty(), modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.catalog_export_selected))
        }
    }
}

@Composable
internal fun DesktopHistoryPanel(rows: List<ProcessingRow>, end: Int, modules: List<EditorModule>, enabled: Boolean,
    onSelect: (Int) -> Unit, onSnapshots: () -> Unit, onSaveSnapshot: () -> Unit) {
    Column(Modifier.fillMaxSize().background(LocalEditorChromeColors.current.panel).padding(8.dp).testTag("desktop_history_panel")) {
        Text(stringResource(R.string.desktop_history_title), style = MaterialTheme.typography.titleSmall)
        TextButton(onSnapshots, enabled = enabled) { Text(stringResource(R.string.desktop_snapshots)) }
        TextButton(onSaveSnapshot, enabled = enabled) { Text(stringResource(R.string.desktop_save_snapshot)) }
        HorizontalDivider()
        LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
            item {
                Surface(onClick = { onSelect(0) }, enabled = enabled, modifier = Modifier.fillMaxWidth(),
                    color = if(end == 0) LocalEditorChromeColors.current.selection else MaterialTheme.colorScheme.surface) {
                    Text(stringResource(R.string.desktop_history_original), Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            items(rows.sortedByDescending { it.number }, key = { it.number }) { row ->
                val name = modules.firstOrNull { it.operation == row.identifier }?.name
                    ?: modules.firstOrNull { it.operation.substringBefore('@') == row.operation }?.name ?: row.operation
                Surface(onClick = { onSelect(row.number + 1) }, enabled = enabled,
                    color = if(end == row.number + 1) LocalEditorChromeColors.current.selection else MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth().testTag("native_history_${row.number}")) {
                    Text("${row.number + 1}  $name", Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                        color = if(row.number < end) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
