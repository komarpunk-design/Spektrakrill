/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import java.io.ByteArrayOutputStream
import java.util.Base64
import java.util.zip.InflaterInputStream
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import org.w3c.dom.Document
import org.w3c.dom.Element

internal const val DARKTABLE_NS = "http://darktable.sf.net/"
internal const val RDF_NS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"

internal data class ProcessingRow(val number: Int, val operation: String, val priority: Int,
    val name: String, val enabled: Boolean, val version: Int, val params: String,
    val blend: String, val blendVersion: Int, val named: Boolean) {
    val identifier get() = if(priority == 0) operation else "$operation@$priority"
    fun sameProcessing(other: ProcessingRow) = enabled == other.enabled && version == other.version &&
        decodedParameters(params).contentEquals(decodedParameters(other.params)) &&
        blendVersion == other.blendVersion && decodedParameters(blend).contentEquals(decodedParameters(other.blend))
}

internal data class ProcessingHistory(val rows: List<ProcessingRow>, val end: Int) {
    val active get() = rows.filter { it.number < end }
    val latest get() = active.groupBy { it.identifier }.map { (_, steps) -> steps.maxBy { it.number } }.sortedBy { it.number }
}

internal fun processingHistory(bytes: ByteArray): ProcessingHistory {
    val doc = checkedProcessingXml(bytes)
    val description = doc.getElementsByTagNameNS(RDF_NS, "Description")
    var end: Int? = null
    for(i in 0 until description.length) (description.item(i) as Element).let {
        if(it.hasAttributeNS(DARKTABLE_NS, "history_end")) end = it.getAttributeNS(DARKTABLE_NS, "history_end").toInt()
    }
    val history = doc.getElementsByTagNameNS(DARKTABLE_NS, "history")
    require(history.length == 1) { "The XMP must contain one native history" }
    val nodes = (history.item(0) as Element).getElementsByTagNameNS(RDF_NS, "li")
    val rows = List(nodes.length) { index ->
        val node = nodes.item(index) as Element
        fun value(name: String) = node.getAttributeNS(DARKTABLE_NS, name)
        val operation = value("operation").also { require(it.matches(Regex("[a-z0-9_]{1,64}"))) }
        ProcessingRow(value("num").toInt(), operation, value("multi_priority").toInt(), value("multi_name"),
            value("enabled") == "1", value("modversion").toInt(), value("params"), value("blendop_params"),
            value("blendop_version").toInt(), value("multi_name_hand_edited") == "1").also {
            require(it.number >= 0 && it.priority >= 0 && it.version > 0)
        }
    }
    require(rows.map { it.number }.distinct().size == rows.size)
    val activeEnd = checkNotNull(end) { "Missing native history position" }
    require(activeEnd >= 0 && activeEnd <= (rows.maxOfOrNull { it.number } ?: -1) + 1)
    return ProcessingHistory(rows, activeEnd)
}

/** XML encoding only: processing bytes and their migration remain native. */
internal fun documentBytes(document: Document): ByteArray {
    val output = ByteArrayOutputStream()
    TransformerFactory.newInstance().newTransformer().apply {
        setOutputProperty("encoding", "UTF-8")
    }.transform(DOMSource(document), StreamResult(output))
    return output.toByteArray()
}

internal fun decodedParameters(value: String): ByteArray {
    if(value.isEmpty()) return byteArrayOf()
    if(value.startsWith("gz")) {
        require(value.length >= 4 && value.substring(2, 4).toIntOrNull() in 1..99)
        val compressed = Base64.getDecoder().decode(value.substring(4))
        return InflaterInputStream(compressed.inputStream()).use { input ->
            val output = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            while(true) {
                val count = input.read(buffer); if(count < 0) break
                require(output.size().toLong() + count <= 16L * 1024 * 1024) { "Encoded parameters exceed the XMP safety budget" }
                output.write(buffer, 0, count)
            }
            output.toByteArray()
        }
    }
    require(value.length % 2 == 0 && value.length <= 32 * 1024 * 1024)
    return ByteArray(value.length / 2) { i -> value.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
}

internal fun assertOnlyInstanceChanged(before: ByteArray, after: ByteArray, identifier: String) {
    val old = processingHistory(before).latest.associateBy { it.identifier }
    val next = processingHistory(after).latest.associateBy { it.identifier }
    check(identifier in next) { "The native engine did not create the selected processing state" }
    for(key in (old.keys + next.keys) - identifier) {
        check(old[key] != null && next[key] != null && old.getValue(key).sameProcessing(next.getValue(key))) {
            "The native operation affected another module instance; processing was not committed"
        }
    }
}

internal fun historyAtPosition(bytes: ByteArray, end: Int): ByteArray {
    val history = processingHistory(bytes)
    require(end >= 0 && end <= (history.rows.maxOfOrNull { it.number } ?: -1) + 1)
    val doc = checkedProcessingXml(bytes)
    val entries = doc.getElementsByTagNameNS(RDF_NS, "Description")
    for(i in 0 until entries.length) (entries.item(i) as Element).let {
        if(it.hasAttributeNS(DARKTABLE_NS, "history_end")) it.setAttributeNS(DARKTABLE_NS, "darktable:history_end", end.toString())
    }
    return documentBytes(doc)
}

internal fun renamedInstance(bytes: ByteArray, identifier: String, name: String): ByteArray {
    require(name.isNotBlank() && name.toByteArray(Charsets.UTF_8).size <= 127 && '\u0000' !in name)
    val history = processingHistory(bytes)
    require(history.latest.any { it.identifier == identifier }) { "Adjust this instance before renaming it" }
    val doc = checkedProcessingXml(bytes)
    val entries = (doc.getElementsByTagNameNS(DARKTABLE_NS, "history").item(0) as Element).getElementsByTagNameNS(RDF_NS, "li")
    for(i in 0 until entries.length) {
        val row = entries.item(i) as Element
        val op = row.getAttributeNS(DARKTABLE_NS, "operation")
        val priority = row.getAttributeNS(DARKTABLE_NS, "multi_priority").toInt()
        val id = if(priority == 0) op else "$op@$priority"
        if(id == identifier) {
            row.setAttributeNS(DARKTABLE_NS, "darktable:multi_name", name)
            row.setAttributeNS(DARKTABLE_NS, "darktable:multi_name_hand_edited", "1")
        }
    }
    return documentBytes(doc)
}

/** The native engine allocates the instance and its order; XMP carries opaque settings. */
internal fun copiedInstance(bytes: ByteArray, sourceId: String, targetId: String): ByteArray {
    val history = processingHistory(bytes)
    val source = history.latest.single { it.identifier == sourceId }
    val target = history.latest.single { it.identifier == targetId }
    require(source.operation == target.operation && sourceId != targetId)
    val doc = checkedProcessingXml(bytes)
    val entries = (doc.getElementsByTagNameNS(DARKTABLE_NS, "history").item(0) as Element).getElementsByTagNameNS(RDF_NS, "li")
    val row = (0 until entries.length).map { entries.item(it) as Element }
        .single { it.getAttributeNS(DARKTABLE_NS, "num").toInt() == target.number }
    for((key, value) in listOf("modversion" to source.version.toString(), "params" to source.params,
        "enabled" to if(source.enabled) "1" else "0", "blendop_params" to source.blend,
        "blendop_version" to source.blendVersion.toString(), "multi_name" to target.priority.toString(),
        "multi_name_hand_edited" to "0")) row.setAttributeNS(DARKTABLE_NS, "darktable:$key", value)
    return documentBytes(doc)
}
