/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.nativecore

import java.io.File
import java.util.UUID
import org.example.darktableandroid.storage.*
import org.w3c.dom.Element

internal object NativeStyleSelection {
    /** Let desktop's reader migrate masks before comparing or exporting a style. */
    fun normalize(source: String, folder: File): ByteArray {
        val name = "mobile-normalize-${UUID.randomUUID()}"
        val file = folder.resolve("normalize.dtstyle").apply {
            writeText("<darktable_style version=\"1.0\"><info><name>$name</name><description/></info><style/></darktable_style>")
        }
        val output = folder.resolve("normalized.xmp")
        NativeDesktop.writeStyledSidecar(source, file.path, name, output.path, false)
        return validatedDarktableXmp(output.readBytes())
    }

    /** Export current forms without modifying the open image or its native Undo. */
    fun exportCurrent(source: File, history: ByteArray, folder: File, title: String,
        identifiers: List<String>, copyOrder: Boolean): ByteArray {
        val scratch = folder.resolve("source").apply { check(mkdirs()) }
        val input = scratch.resolve(source.name)
        try { java.nio.file.Files.createLink(input.toPath(), source.toPath()) }
        catch(_: Exception) { source.copyTo(input, overwrite = true) }
        File(input.path + ".xmp").writeBytes(history)
        val handle = NativeCore.open(input.path)
        try {
            val rows = processingHistory(history).latest.associateBy { it.identifier }
            // Re-save each selected tool at the current mask state, rather than
            // the older row where a shared mask may last have been edited.
            for(id in identifiers) NativeCore.setModuleEnabled(handle, id, rows.getValue(id).enabled)
            val normalized = normalize(input.path, folder)
            val current = processingHistory(normalized).latest.associateBy { it.identifier }
            return export(input.path, folder, title, identifiers.map { current.getValue(it).number }, copyOrder)
        } finally { NativeCore.close(handle) }
    }

    fun export(source: String, folder: File, title: String, numbers: List<Int>, copyOrder: Boolean): ByteArray {
        require(numbers.isNotEmpty() && numbers.size == numbers.distinct().size && numbers.all { it >= 0 })
        val chunks = mutableListOf<MutableList<Int>>()
        var size = 0
        for(number in numbers) {
            val bytes = number.toString().length + 1
            if(chunks.isEmpty() || size + bytes > 1700) { chunks.add(mutableListOf()); size = 0 }
            chunks.last() += number; size += bytes
        }
        var merged: org.w3c.dom.Document? = null
        for((index, chunk) in chunks.withIndex()) {
            val part = folder.resolve("part-$index").apply { check(mkdirs()) }
            NativeDesktop.exportSelectedStyle(source, part.path, "mobile-selection-${UUID.randomUUID()}", chunk.toIntArray(), copyOrder)
            val bytes = part.listFiles().orEmpty().single { it.extension == "dtstyle" }.readBytes()
            val doc = checkedProcessingXml(bytes)
            if(merged == null) merged = doc else {
                val target = merged.getElementsByTagName("style").item(0) as Element
                val plugins = doc.getElementsByTagName("plugin")
                for(i in 0 until plugins.length) target.appendChild(merged.importNode(plugins.item(i), true))
            }
        }
        val document = checkNotNull(merged)
        val actual = document.getElementsByTagName("plugin")
        val exported = (0 until actual.length).map {
            ((actual.item(it) as Element).getElementsByTagName("num").item(0).textContent).toInt()
        }
        check(exported.toSet() == numbers.toSet() && exported.size == numbers.size) { "The native style did not contain the full selection" }
        document.getElementsByTagName("name").item(0).textContent = title
        return documentBytes(document)
    }
}
