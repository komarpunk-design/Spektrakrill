/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import java.io.File
import java.security.MessageDigest
import java.util.UUID
import org.w3c.dom.Element

internal data class ModulePreset(val id: String, val name: String, val description: String,
    val operation: String, val version: Int, val enabled: Boolean, val params: String, val blend: String,
    val blendVersion: Int, val camera: String, val file: File, val factory: Boolean)

internal class ModulePresets(private val root: File) {
    fun list(operation: String): List<ModulePreset> {
        require(operation.matches(Regex("[a-z0-9_]{1,64}")))
        return root.walkTopDown().filter { it.isFile && it.extension == "dtpreset" }.mapNotNull {
            runCatching { readModulePreset(it.readBytes(), it, it.startsWith(root.resolve("factory"))) }.getOrNull()
        }.filter { it.operation == operation }.distinctBy { it.id }.sortedWith(compareBy({ !it.factory }, { it.name.lowercase(java.util.Locale.ROOT) }, { it.version })).toList()
    }

    fun retain(bytes: ByteArray): ModulePreset {
        val file = root.resolve("personal/${presetDigest(bytes)}.dtpreset")
        val preset = readModulePreset(bytes, file, false)
        if(!file.exists()) atomicWrite(file, bytes)
        return preset
    }

    fun factoryDirectory(operation: String): File {
        require(operation.matches(Regex("[a-z0-9_]{1,64}")))
        return root.resolve("factory/engine-1c4eaea9/$operation")
    }
}

internal fun readModulePreset(bytes: ByteArray, file: File, factory: Boolean = false): ModulePreset {
    val doc = checkedProcessingXml(bytes)
    require(doc.documentElement.tagName == "darktable_preset" && doc.documentElement.getAttribute("version") == "1.0") {
        "Choose an original darktable .dtpreset file"
    }
    val presets = doc.documentElement.getElementsByTagName("preset")
    require(presets.length == 1)
    val node = presets.item(0) as Element
    fun text(name: String): String {
        val values = node.getElementsByTagName(name)
        require(values.length <= 1) { "Duplicate preset field" }
        return values.item(0)?.textContent.orEmpty()
    }
    val operation = text("operation").also { require(it.matches(Regex("[a-z0-9_]{1,64}"))) }
    val version = text("op_version").toInt().also { require(it > 0) }
    val name = text("name").also { require(it.isNotBlank() && it.length <= 4096) }
    val enabled = text("enabled").also { require(it in listOf("0", "1")) } == "1"
    val params = text("op_params").also { decodedParameters(it) }
    val blend = text("blendop_params").also { decodedParameters(it) }
    val blendVersion = text("blendop_version").toInt().also { require(it >= 0) }
    return ModulePreset((if(factory) "factory-" else "personal-") + presetDigest(bytes), name, text("description"), operation, version, enabled, params,
        blend, blendVersion, listOf(text("maker"), text("model"), text("lens")).filter { it.isNotBlank() && it != "%" }
            .joinToString(" · "), file, factory)
}

private fun presetDigest(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }

internal fun presetFromStyle(bytes: ByteArray, title: String): ByteArray {
    val style = checkedProcessingXml(bytes)
    val plugins = style.getElementsByTagName("plugin")
    require(plugins.length == 1)
    val plugin = plugins.item(0) as Element
    fun value(name: String) = plugin.getElementsByTagName(name).item(0)?.textContent.orEmpty()
    val doc = checkedProcessingXml("<darktable_preset version=\"1.0\"><preset/></darktable_preset>".toByteArray())
    val target = doc.getElementsByTagName("preset").item(0) as Element
    // Unfiltered manual preset metadata follows the desktop editor defaults;
    // all processing and mask payloads come from the native selected style.
    val fields = listOf("name" to title, "description" to "", "operation" to value("operation"),
        "op_params" to value("op_params"), "op_version" to value("module"), "enabled" to value("enabled"),
        "blendop_params" to value("blendop_params"), "blendop_version" to value("blendop_version"),
        "multi_priority" to "0", "multi_name" to "", "multi_name_hand_edited" to "0",
        "autoapply" to "0", "filter" to "0", "def" to "0", "format" to "0",
        "model" to "%", "maker" to "%", "lens" to "%", "iso_min" to "0", "iso_max" to "3.402823466e38",
        "exposure_min" to "0", "exposure_max" to "1000000", "aperture_min" to "0", "aperture_max" to "1000000",
        "focal_length_min" to "0", "focal_length_max" to "100000")
    for((name, text) in fields) target.appendChild(doc.createElement(name).apply { textContent = text })
    return documentBytes(doc)
}

/** Original preset payloads are transported in the native style protocol. */
internal fun modulePresetStyle(preset: ModulePreset, target: ProcessingRow?, identifier: String): Pair<String, ByteArray> {
    require(identifier.substringBefore('@') == preset.operation)
    val priority = identifier.substringAfter('@', "0").toInt().also { require(it >= 0) }
    require(target == null && priority == 0 || target?.identifier == identifier)
    val name = "mobile-preset-${UUID.randomUUID()}"
    val doc = checkedProcessingXml("<darktable_style version=\"1.0\"/>".toByteArray())
    fun Element.element(key: String, value: String? = null): Element = doc.createElement(key).also {
        if(value != null) it.textContent = value
        appendChild(it)
    }
    val info = doc.documentElement.element("info")
    info.element("name", name); info.element("description", preset.name)
    val plugin = doc.documentElement.element("style").element("plugin")
    for((key, value) in listOf("num" to "0", "operation" to preset.operation, "module" to preset.version.toString(),
        "op_params" to (if(preset.params.startsWith("gz")) preset.params else preset.params.lowercase(java.util.Locale.ROOT)),
        "enabled" to if(preset.enabled) "1" else "0", "blendop_params" to (if(preset.blend.startsWith("gz")) preset.blend else preset.blend.lowercase(java.util.Locale.ROOT)),
        "blendop_version" to preset.blendVersion.toString(), "multi_priority" to priority.toString(),
        "multi_name" to target?.name.orEmpty(), "multi_name_hand_edited" to if(target?.named == true) "1" else "0")) plugin.element(key, value)
    return name to documentBytes(doc)
}
