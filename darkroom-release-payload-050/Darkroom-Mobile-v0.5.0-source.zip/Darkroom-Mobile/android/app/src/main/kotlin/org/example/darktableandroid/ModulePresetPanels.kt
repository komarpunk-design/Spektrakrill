/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import org.example.darktableandroid.storage.ModulePreset
import org.example.darktableandroid.storage.ProcessingRow
import org.example.darktableandroid.nativecore.GettextCatalog
import org.example.darktableandroid.nativecore.styleName

@Composable
internal fun ModuleInstanceMenu(enabled: Boolean, recorded: Boolean, canCopy: Boolean,
    onPresets: () -> Unit, onCopy: () -> Unit, onRename: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }, enabled = enabled, modifier = Modifier.testTag("module_actions")) {
            Icon(painterResource(R.drawable.studio_ic_more), stringResource(R.string.module_presets))
        }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem({ Text(stringResource(R.string.module_presets)) }, { open = false; onPresets() })
            DropdownMenuItem({ Text(stringResource(R.string.module_instance_copy)) }, { open = false; onCopy() }, enabled = recorded && canCopy)
            DropdownMenuItem({ Text(stringResource(R.string.module_instance_name)) }, { open = false; onRename() }, enabled = recorded)
            if(!recorded) Text(stringResource(R.string.module_instance_adjust_first), Modifier.widthIn(max = 240.dp).padding(12.dp),
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun ModulePresetPanel(title: String, presets: List<ModulePreset>, busy: Boolean, canSave: Boolean,
    onDismiss: () -> Unit, onImport: () -> Unit, onSave: () -> Unit, onApply: (String) -> Unit,
    onExport: (String) -> Unit, catalog: GettextCatalog = GettextCatalog.empty()) {
    var query by rememberSaveable { mutableStateOf("") }
    var personal by rememberSaveable { mutableStateOf(false) }
    val filtered = remember(presets, query, personal, catalog) { presets.filter {
        (!personal || !it.factory) && (catalog.styleName(it.name) + " " + it.description + " " + it.camera).contains(query.trim(), true)
    } }
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.94f).padding(horizontal = 16.dp).testTag("module_presets")) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.module_presets_hint), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(query, { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("module_preset_search"),
                label = { Text(stringResource(R.string.desktop_style_search)) })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!personal, { personal = false }, label = { Text(stringResource(R.string.module_presets_all)) })
                FilterChip(personal, { personal = true }, label = { Text(stringResource(R.string.module_presets_personal)) })
            }
            if(busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                if(filtered.isEmpty() && !busy) item { Text(stringResource(R.string.module_presets_empty), Modifier.padding(vertical = 16.dp)) }
                items(filtered, key = { (if(it.factory) "factory-" else "personal-") + it.id }) { preset ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).testTag("module_preset_${preset.id}")) {
                        Text(catalog.styleName(preset.name), style = MaterialTheme.typography.titleMedium)
                        if(preset.description.isNotBlank()) Text(preset.description, style = MaterialTheme.typography.bodySmall)
                        Text(stringResource(if(preset.factory) R.string.module_preset_factory else R.string.module_preset_personal,
                            preset.version), style = MaterialTheme.typography.bodySmall)
                        if(preset.camera.isNotBlank()) Text(preset.camera, style = MaterialTheme.typography.bodySmall)
                        if(!preset.enabled) Text(stringResource(R.string.module_preset_disabled), style = MaterialTheme.typography.bodySmall)
                        Row {
                            TextButton({ onApply(preset.id) }, enabled = !busy) { Text(stringResource(R.string.apply)) }
                            TextButton({ onExport(preset.id) }, enabled = !busy) { Text(stringResource(R.string.export)) }
                        }
                    }
                    HorizontalDivider()
                }
            }
            if(!canSave) Text(stringResource(R.string.module_instance_adjust_first), style = MaterialTheme.typography.bodySmall)
            Row {
                TextButton(onImport, enabled = !busy) { Text(stringResource(R.string.module_preset_import)) }
                TextButton(onSave, enabled = !busy && canSave) { Text(stringResource(R.string.module_preset_save)) }
                Spacer(Modifier.weight(1f))
                TextButton(onDismiss) { Text(stringResource(R.string.done)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SelectedStylePanel(rows: List<ProcessingRow>, onDismiss: () -> Unit,
    onSave: (String, List<Int>, Boolean) -> Unit, catalog: GettextCatalog = GettextCatalog.empty(),
    moduleNames: Map<String, String> = emptyMap()) {
    var title by rememberSaveable { mutableStateOf("") }
    var selected by rememberSaveable { mutableStateOf(rows.map { it.number }) }
    var copyOrder by rememberSaveable { mutableStateOf(false) }
    ModalBottomSheet(onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(0.94f).padding(horizontal = 16.dp).testTag("selected_style")) {
            Text(stringResource(R.string.desktop_style_save), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.selected_style_hint), style = MaterialTheme.typography.bodySmall)
            OutlinedTextField(title, { title = it.take(40) }, singleLine = true,
                modifier = Modifier.fillMaxWidth().testTag("selected_style_name"), label = { Text(stringResource(R.string.desktop_style_name)) })
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(copyOrder, { copyOrder = it })
                Text(stringResource(R.string.selected_style_order))
            }
            LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                items(rows, key = { it.number }) { row ->
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Checkbox(row.number in selected, { enabled -> selected = if(enabled) selected + row.number else selected - row.number },
                            Modifier.testTag("style_row_${row.number}"))
                        Column(Modifier.weight(1f)) {
                            Text(moduleNames[row.identifier] ?: (catalog.translate(row.operation) + if(row.name.isBlank()) "" else " · ${row.name}"))
                            Text("${row.identifier} · ${row.number}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            Row {
                Button({ onSave(title, selected, copyOrder) }, enabled = selected.isNotEmpty(),
                    modifier = Modifier.testTag("save_selected_style")) { Text(stringResource(R.string.apply)) }
                Spacer(Modifier.weight(1f))
                TextButton(onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        }
    }
}
