/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid

import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import org.example.darktableandroid.nativecore.*
import org.example.darktableandroid.storage.*
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.ExternalResource
import org.junit.rules.RuleChain
import org.junit.rules.TestRule
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

@android.annotation.TargetApi(35)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "ru-w1280dp-h800dp-mdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class DesktopLayoutTest {
    private val compose = createComposeRule()
    private val context get() = RuntimeEnvironment.getApplication()
    @get:Rule val rules: TestRule = RuleChain.outerRule(object : ExternalResource() {
        override fun before() {
            shadowOf(context.packageManager).addOrUpdateActivity(ActivityInfo().apply {
                name = ComponentActivity::class.java.name; packageName = context.packageName
                applicationInfo = context.applicationInfo; theme = android.R.style.Theme_Material_Light_NoActionBar
                enabled = true; exported = true
            })
        }
    }).around(compose)

    private fun source() = File("../../data/style/image-1.jpg").canonicalFile
    private fun photos() = listOf("one", "two").map { id ->
        CatalogPhoto(PhotoProject(id, "$id.jpg", "content://photos/$id", 1, null, File("/missing/$id"), source()), CatalogMarks(4))
    }
    private fun ready(): EditorState.Ready {
        val preview = checkNotNull(BitmapFactory.decodeFile(source().path))
        val exposure = EditorModule("exposure", "Экспозиция", true, true,
            listOf(ModuleParameter("exposure", "Экспозиция · EV", "float", .75, -3.0, 3.0, emptyList())), canCreateInstance = true)
        return EditorState.Ready(Uri.parse("content://photos/one"), 1, preview, listOf(exposure),
            listOf(ExportFormat("png", "PNG", "png", "image/png", 8)), history = EditHistory(true, false, 1, 1),
            selectedModule = "exposure", projectId = "one")
    }

    @Composable private fun Fixture(onOpen: (String) -> Unit = {}) {
        val ready = remember { ready() }
        var selected by remember { mutableStateOf(ready.selectedModule) }
        DarktableTheme {
            EditorWorkspace(ready.copy(selectedModule = selected), RuntimeAvailability(false, true), {}, {}, {}, {}, {}, {},
                { selected = it }, { _, _ -> },
                contactSheet = { DesktopLighttable(photos(), true, true, {}, onOpen, {}) },
                filmstrip = { DesktopFilmstrip(photos(), ready.projectId, true, onOpen) },
                historyPanel = { DesktopHistoryPanel(processingHistory(javaClass.getResourceAsStream("/desktop-native-sidecar.xmp")!!.readBytes()).rows,
                    5, ready.modules, true, {}, {}, {}) }) { module, _ ->
                ModuleControls(module, true, true, {}, {}, { _, _ -> }, { _, _, _ -> }, { _, _, _, _ -> },
                    { _, _ -> }, { _, _, _ -> }, { _, _ -> }, { _, _ -> }, { _, _, _ -> }, showHeader = false)
            }
        }
    }

    private fun capture(name: String) {
        compose.waitForIdle()
        compose.runOnIdle {
            val activity = androidx.test.runner.lifecycle.ActivityLifecycleMonitorRegistry.getInstance()
                .getActivitiesInStage(androidx.test.runner.lifecycle.Stage.RESUMED).single()
            val view = activity.findViewById<android.view.View>(android.R.id.content)
            val image = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(image)
            android.view.inspector.WindowInspector.getGlobalWindowViews().filter { it.isShown }.forEach { window ->
                val position = IntArray(2); window.getLocationOnScreen(position)
                canvas.save(); canvas.translate(position[0].toFloat(), position[1].toFloat()); window.draw(canvas); canvas.restore()
            }
            val file = File("build/reports/desktop-layout/$name.png").apply { parentFile!!.mkdirs() }
            file.outputStream().use { check(image.compress(Bitmap.CompressFormat.PNG, 100, it)) }
        }
    }

    @Test fun wideDesktopHasSeparateHistoryPreviewInspectorAndFilmstrip() {
        compose.setContent { Fixture() }
        val history = compose.onNodeWithTag("desktop_history_panel").assertIsDisplayed().fetchSemanticsNode().boundsInRoot
        val preview = compose.onNodeWithTag("editor_preview_pane").assertIsDisplayed().fetchSemanticsNode().boundsInRoot
        val tools = compose.onNodeWithTag("editor_tools_pane").assertIsDisplayed().fetchSemanticsNode().boundsInRoot
        val strip = compose.onNodeWithTag("desktop_filmstrip").assertIsDisplayed().fetchSemanticsNode().boundsInRoot
        assertTrue(history.right <= preview.left)
        assertTrue(preview.right <= tools.left)
        assertTrue(strip.top >= preview.bottom)
        capture("darkroom-1280x800")
    }

    @Test fun lighttableShowsRealFramesAndEditAndFilmstripOpenExactProjects() {
        var opened = ""
        compose.setContent { Fixture { opened = it } }
        compose.onNodeWithTag("desktop_lighttable").performClick()
        compose.onNodeWithTag("desktop_contact_sheet").assertIsDisplayed()
        compose.onNodeWithTag("contact_two").performClick()
        // A real single tap waits out combinedClickable's double-tap window.
        compose.mainClock.advanceTimeBy(400)
        compose.onNodeWithTag("contact_two").assertIsSelected()
        capture("lighttable-1280x800")
        compose.onAllNodesWithText(context.getString(R.string.desktop_edit_photo))[1].performClick()
        compose.runOnIdle { assertEquals("two", opened) }
        compose.onNodeWithTag("lighttable_search").performTextInput("two")
        compose.onNodeWithTag("desktop_darkroom").performClick()
        compose.onNodeWithTag("filmstrip_one").performClick()
        compose.runOnIdle { assertEquals("one", opened) }
        compose.onNodeWithTag("desktop_lighttable").performClick()
        compose.onNodeWithTag("lighttable_search").assertTextContains("two")
        compose.onNodeWithTag("contact_two").assertIsSelected()
        compose.onNodeWithTag("contact_one").assertDoesNotExist()
    }

    @Test @Config(sdk = [35], qualifiers = "ru-w360dp-h800dp-mdpi")
    fun phonePanelsFoldWithoutCoveringOrRemovingThePhotograph() {
        compose.setContent { Fixture() }
        compose.onNodeWithTag("desktop_tools_toggle").performClick()
        compose.onNodeWithTag("editor_preview_pane").assertIsDisplayed()
        compose.onNodeWithTag("editor_tools_pane").assertDoesNotExist()
        compose.onNodeWithTag("desktop_history_toggle").performClick()
        compose.onNodeWithTag("desktop_history_panel").assertIsDisplayed()
        compose.onNodeWithTag("desktop_tools_toggle").performClick()
        compose.onNodeWithTag("desktop_history_panel").assertDoesNotExist()
        compose.onNodeWithTag("editor_tools_pane").assertIsDisplayed()
        capture("darkroom-360x800")
    }

    @Test fun openingProgressDecodeFailureAndRuntimeFailureStayVisibleWithRecoveryActions() {
        val uri = Uri.parse("content://photos/broken.raw")
        var state: EditorState by mutableStateOf(EditorState.Working(EditorState.Stage.COPYING))
        var runtime by mutableStateOf(RuntimeAvailability(false, true))
        var retried: Uri? = null
        compose.setContent { DarktableTheme {
            EditorWorkspace(state, runtime, {}, {}, {}, {}, { state = EditorState.Empty }, { retried = it }, {}, { _, _ -> },
                contactSheet = { androidx.compose.material3.Text("Grid fixture") }) { _, _ -> }
        } }
        compose.onNodeWithText(context.getString(R.string.studio_preparing)).assertIsDisplayed()
        compose.onNodeWithText(context.getString(R.string.cancel)).performClick()
        compose.onNodeWithText("Grid fixture").assertIsDisplayed()
        compose.runOnIdle { state = EditorState.Failed(uri, "Decode failure fixture") }
        compose.onNodeWithText("Decode failure fixture").assertIsDisplayed()
        compose.onNodeWithText(context.getString(R.string.retry)).performClick()
        compose.runOnIdle { assertEquals(uri, retried) }
        compose.onNodeWithTag("desktop_lighttable").performClick()
        compose.onNodeWithText("Grid fixture").assertIsDisplayed()
        compose.runOnIdle { runtime = RuntimeAvailability(false, false, "Runtime failure fixture") }
        compose.onNodeWithText("Runtime failure fixture").assertIsDisplayed()
    }
}
