/* SPDX-License-Identifier: GPL-3.0-or-later */
package org.example.darktableandroid.storage

import java.io.File
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class ModulePresetHistoryTest {
    @get:Rule val temporary = TemporaryFolder()
    private fun xmp() = javaClass.getResourceAsStream("/desktop-native-sidecar.xmp")!!.readBytes()
    private fun style() = javaClass.getResourceAsStream("/desktop-native-style.dtstyle")!!.readBytes()

    @Test fun nativeHistoryHasExactIdentitiesAndLatestActiveRows() {
        val history = processingHistory(xmp())
        assertTrue(history.end > 0)
        assertEquals(history.latest.map { it.identifier }.distinct().size, history.latest.size)
        assertTrue(history.latest.any { it.operation == "exposure" })
        assertTrue(history.active.all { it.number < history.end })
    }

    @Test fun movingTheNativeHistoryCursorRetainsFutureRowsAndTheirOpaqueProcessing() {
        val original = xmp()
        val before = processingHistory(original)
        val earlier = historyAtPosition(original, 0)
        assertEquals(0, processingHistory(earlier).end)
        assertEquals(before.rows, processingHistory(earlier).rows)
        assertEquals(before, processingHistory(historyAtPosition(earlier, before.end)))
        assertThrows(IllegalArgumentException::class.java) { historyAtPosition(original, -1) }
    }

    @Test fun renamingChangesOnlyTheNativeNameAndKeepsEveryProcessingByte() {
        val original = xmp()
        val result = renamedInstance(original, "exposure", "Свет 📷")
        val before = processingHistory(original)
        val after = processingHistory(result)
        assertEquals(before.rows.size, after.rows.size)
        before.rows.zip(after.rows).forEach { (a, b) -> assertTrue(a.sameProcessing(b)) }
        assertEquals("Свет 📷", after.latest.single { it.operation == "exposure" }.name)
        assertThrows(IllegalArgumentException::class.java) { renamedInstance(original, "exposure", "я".repeat(64)) }
    }

    @Test fun savedSingleToolPresetRetainsNativeParametersAndMaskPayload() {
        val doc = checkedProcessingXml(style())
        val plugins = doc.getElementsByTagName("plugin")
        for(i in plugins.length - 1 downTo 0) {
            val p = plugins.item(i) as org.w3c.dom.Element
            if(p.getElementsByTagName("operation").item(0).textContent != "exposure") p.parentNode.removeChild(p)
        }
        val bytes = presetFromStyle(documentBytes(doc), "My exposure")
        val preset = readModulePreset(bytes, File("test.dtpreset"))
        assertEquals("exposure", preset.operation)
        assertEquals("My exposure", preset.name)
        val (name, converted) = modulePresetStyle(preset, null, "exposure")
        val copy = checkedProcessingXml(converted)
        assertEquals(name, copy.getElementsByTagName("name").item(0).textContent)
        assertArrayEquals(decodedParameters(preset.params), decodedParameters(copy.getElementsByTagName("op_params").item(0).textContent))
        assertArrayEquals(decodedParameters(preset.blend), decodedParameters(copy.getElementsByTagName("blendop_params").item(0).textContent))
    }

    @Test fun factoryAndImportedCopiesHaveDistinctIdentitiesAndKeepOriginalBytes() {
        val doc = checkedProcessingXml(style())
        val plugins = doc.getElementsByTagName("plugin")
        for(i in plugins.length - 1 downTo 1) plugins.item(i).parentNode.removeChild(plugins.item(i))
        val bytes = presetFromStyle(documentBytes(doc), "Preset")
        val store = ModulePresets(temporary.root)
        val original = store.retain(bytes)
        val factory = readModulePreset(bytes, File("factory.dtpreset"), true)
        assertNotEquals(original.id, factory.id)
        assertArrayEquals(bytes, original.file.readBytes())
        assertEquals(original.id, store.retain(bytes).id)
    }

    @Test fun malformedPresetsAndDecompressionBombsAreRejectedBeforeNativeLoading() {
        assertThrows(Exception::class.java) { readModulePreset("<other/>".toByteArray(), File("a")) }
        assertThrows(Exception::class.java) { decodedParameters("gz00eJwDAAAAAAE=") }
        assertThrows(Exception::class.java) { decodedParameters("000x") }
        assertArrayEquals(byteArrayOf(0, 127, -1), decodedParameters("007fff"))
    }
}
