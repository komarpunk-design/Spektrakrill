<!-- SPDX-License-Identifier: GPL-3.0-or-later -->
# Resizable Android editing workspace

```text
Lighttable: thumbnail grid, search/filters, selection and batch export
Darkroom (wide):
┌───────────────────────────────────────────────────────────────┐
│ open / undo / redo / export / ⋮     Lighttable | Darkroom      │
├──────────────┬──────────────────────────┬─────────────────────┤
│ history      │ photograph / zoom        │ groups / tool / ⋮   │
│ snapshots    │                          ↔ native controls     │
├──────────────┴──────────────────────────┴─────────────────────┤
│ filmstrip                                                     │
└───────────────────────────────────────────────────────────────┘
On phones the history and inspector fold into a lower pane; the photo stays
above them. Panel toggles and full-photo mode give the photograph more room.
```

The photograph is central; the inspector shows one selected tool at a time.
Drag the separator to resize the workspace. Accessibility progress actions
resize it, and accessibility activation resets its ratio. Landscape protects
minimum useful pane widths. The keyboard temporarily gives portrait controls
more space. Full-photo view temporarily hides the inspector; returning restores
its drafts and scroll positions. Pinch/pan and double-tap operate on the preview
only. Coordinate-sensitive photo tools use the untransformed native geometry.

The three editing categories inside the inspector retain every original tool and instance. The
category catalog has search and an Enabled filter; global search also matches
native parameter labels across categories. Search is navigation, not an edit.
Selecting an off tool leaves it off. The adjacent power switch controls its
processing state. Mandatory native modules retain their original restrictions.

Numerical controls retain their original ranges, exact input and reset. Curve,
white-balance, crop, lens, file and mask editors retain their original callbacks.
Blending/parametric and drawn/repair masks sit behind labeled disclosures inside
the same tool; they are not moved into application settings. Settings contains
languages, themes, runtime status and licenses, and uses the entire content area.

Workspace, selection, section expansion, ordinary numeric drafts and scroll
positions are UI state. Opening another photo creates a distinct native session.
Undo/Redo and preview staleness remain owned by the native bridge. Rendering and
export keep the previous preview when available and expose progress/cancellation.
The original terminal cancellation closes the session: the app asks before
stopping work with a previously open photo. Committed edits now persist in the
photo project's native XMP; reopening starts a new session Undo ring. See
[desktop workflow](DESKTOP_PARITY.md) for snapshots, styles, comparison and
the limits of actual process-death/device verification. The right-hand toolbar
menu contains these photo-workspace actions, rather than application settings.

All three themes share layout/typography/touch actions. Graphite uses neutral
surrounds; Light and OLED remain available. Russian resources and the original
Russian desktop catalog translate presentation without changing native IDs.

See [FORK.md](FORK.md) for a complete original-to-new location table, build steps
and verification limits. Host UI screenshots are rendered with a fixture image;
they do not establish native RAW/device behavior.
