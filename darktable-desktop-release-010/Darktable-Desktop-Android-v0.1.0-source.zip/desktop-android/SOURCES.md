# Pinned sources and redistribution notices

The Android launcher and packaging code use GPL-3.0-or-later, like this project.
Original desktop darktable and PRoot are used unchanged. Their corresponding
source archives accompany the experimental APK; licenses remain inside the
runtime (`/opt/darktable/usr/share/doc`, `/usr/share/doc`, host/licenses).
The darktable icon is copied unchanged from the official AppImage.

| Component | Source | SHA-256 |
| --- | --- | --- |
| Desktop ARM64 5.6.2 AppImage | https://github.com/darktable-org/darktable/releases/tag/release-5.6.2 | `5b8015f8534453cb3bbd6e5a03e362cb7d9d9573f20d3928aadad354df18ad10` |
| darktable 5.6.2 source tar.xz | Same official release | `d2da92c670401d350b576431f21e58bee40348e1f5078201a8a1b8c270585834` |
| Termux PRoot 5.1.107.102 ARM64 deb | https://packages.termux.dev/apt/termux-main/ | `10a394b585c2fc2b2c8502544f4e5f1be581dc8bfff79e8ba62f16207423e030` |
| PRoot source archive v5.1.107.102 | https://github.com/termux/proot/archive/v5.1.107.102.zip | `30d12a6e2cc4147123756ff58edea262d3083bbc238c12d0ab9b39e3d1c40852` |
| Termux libtalloc ARM64 deb | Termux main package index | `556591f43bb773ad8777e1a29522640866a55f95dab71914418b94a8c58ad5a7` |
| Termux libandroid-shmem ARM64 deb | Termux main package index | `0da3a24d558b93c92bcf8d611e0826a99ff96e396b148e6cdf33b47c47c57ff6` |

Debian root image: `arm64v8/debian:trixie-slim`, repository digest
`sha256:7cba939ce1f5881c0ac9fb395d8e0e125a395bb722f623c017513b998d9d50e2`.
Debian packages retain `/var/lib/dpkg/status` and `/usr/share/doc/*/copyright`,
including exact source package names, versions and upstream references.
Corresponding Debian sources are available through https://deb.debian.org/debian/
and https://snapshot.debian.org/ using those versions.

Termux package build recipes and patches:
https://github.com/termux/termux-packages/tree/master/packages/proot,
https://github.com/termux/termux-packages/tree/master/packages/libtalloc and
https://github.com/termux/termux-packages/tree/master/packages/libandroid-shmem.
The small Termux loader libraries retain their respective LGPL/BSD notices.
The original AppImage retains the bundled library notices and original build
recipe is in the official darktable source's packaging directory.

QEMU and x86-64 host PRoot are test tools only and are not included in the APK.
