#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Package an installed ARM64 Linux runtime and the unmodified official AppImage.

No image processing or GTK widgets are reimplemented. Run the ARM64 GUI probe
against the assembled directories before publishing the Android APK.
"""
import argparse, gzip, hashlib, io, json, os, shutil, stat, struct, tarfile
from pathlib import Path

OFFICIAL_SHA = '5b8015f8534453cb3bbd6e5a03e362cb7d9d9573f20d3928aadad354df18ad10'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while b := f.read(1024 * 1024): h.update(b)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('rootfs','appimage','appdir','termux-prefix','output'): p.add_argument('--'+name,type=Path,required=True)
    a = p.parse_args()
    if a.output.exists(): p.error('output exists; choose a fresh stage')
    if digest(a.appimage) != OFFICIAL_SHA: p.error('official ARM64 AppImage SHA-256 mismatch')
    views = a.appdir/'usr/lib/aarch64-linux-gnu/darktable/views'
    expected = {'libdarkroom.so','liblighttable.so','libmap.so','libprint.so','libslideshow.so','libtethering.so'}
    if {f.name for f in views.glob('*.so')} != expected: p.error('incomplete original desktop view inventory')
    (a.output/'assets').mkdir(parents=True)
    native = a.output/'jniLibs/arm64-v8a';native.mkdir(parents=True)
    shutil.copy2(a.termux_prefix/'bin/proot', native/'libdesktop_proot.so')
    entries = {}
    skipped = ('dev/','proc/','sys/','tmp/','home/','root/','photos/','exports/','host-rootfs','var/cache/apt/','var/lib/apt/lists/')
    def scan(source, target, filter_root=False):
        for base, dirs, files in os.walk(source, followlinks=False):
            relbase = Path(base).relative_to(source)
            if filter_root:
                dirs[:] = [d for d in dirs if not any((relbase/d).as_posix().startswith(s.rstrip('/')) for s in skipped)]
            for name in sorted(dirs+files):
                f = Path(base)/name; rel = f.relative_to(source)
                if filter_root and any(rel.as_posix().startswith(s.rstrip('/')) for s in skipped): continue
                if stat.S_ISSOCK(f.lstat().st_mode): continue
                if f.is_symlink() or f.is_file() or f.is_dir(): entries[target+'/'+rel.as_posix()] = f
    scan(a.rootfs,'rootfs',True)
    scan(a.appdir,'rootfs/opt/darktable')
    for name in ('libtalloc.so','libtalloc.so.2','libtalloc.so.2.5.0','libandroid-shmem.so'):
        entries['host/lib/'+name] = a.termux_prefix/'lib'/name
    for name in ('loader','loader32'): entries['host/libexec/proot/'+name] = a.termux_prefix/'libexec/proot'/name
    for package in ('proot','libtalloc','libandroid-shmem'):scan(a.termux_prefix/'share/doc'/package,'host/licenses/'+package)
    entries['rootfs/opt/start-desktop.sh'] = Path(__file__).with_name('start-desktop.sh')
    entries['rootfs/etc/hostname'] = b'darktable-android\n'
    entries['rootfs/etc/hosts'] = b'127.0.0.1 localhost darktable-android\n::1 localhost ip6-localhost\n'
    entries['rootfs/etc/resolv.conf'] = b''
    entries['rootfs/etc/machine-id'] = b''
    # PRoot's QEMU test runner creates an unreadable empty bind placeholder.
    # Native ARM64 needs no preload or emulator-specific filesystem content.
    entries['rootfs/etc/ld.so.preload'] = b''
    passwd=(a.rootfs/'etc/passwd').read_bytes()
    group=(a.rootfs/'etc/group').read_bytes()
    if b'\ndarktable:' not in b'\n'+passwd: passwd+=b'darktable:x:1000:1000:darktable:/home/darktable:/bin/sh\n'
    if b'\ndarktable:' not in b'\n'+group: group+=b'darktable:x:1000:\n'
    entries['rootfs/etc/passwd']=passwd
    entries['rootfs/etc/group']=group
    entries.pop('rootfs/var/lib/dbus/machine-id',None)
    # Runtime-only directories, recreated without host /dev, /proc or build IPC.
    for name in ('rootfs/tmp','rootfs/dev','rootfs/proc','rootfs/sys','rootfs/photos','rootfs/exports','rootfs/home/darktable'):
        entries.setdefault(name,None)
    # AAPT transparently gunzips .gz assets. Keep this verified GZIP stream as-is.
    archive = a.output/'assets/desktop-runtime.payload'
    total = 0; inventory = []
    with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,compresslevel=6) as gz, tarfile.open(fileobj=gz,mode='w|',format=tarfile.USTAR_FORMAT) as tar:
        for name, source in sorted(entries.items()):
            info = tarfile.TarInfo(name);info.uid=info.gid=0;info.mtime=0
            if isinstance(source,bytes):
                info.size=len(source);info.mode=0o644;total+=info.size;tar.addfile(info,io.BytesIO(source))
            elif source is None or (not source.is_symlink() and source.is_dir()):
                info.type=tarfile.DIRTYPE;info.mode=0o755;tar.addfile(info)
            elif source.is_symlink():
                info.type=tarfile.SYMTYPE;info.linkname=os.readlink(source);info.mode=0o777;tar.addfile(info)
            else:
                info.size=source.stat().st_size;info.mode=source.stat().st_mode&0o777
                total += info.size
                with source.open('rb') as content:tar.addfile(info,content)
                if name.startswith('rootfs/opt/darktable/') and (name.endswith('.so') or name.endswith('/darktable')):
                    inventory.append({'path':name,'sha256':digest(source),'bytes':info.size})
    manifest = {'version':'5.6.2','architecture':'aarch64','transport':'original GTK3 Broadway over private Unix HTTP socket',
        'runtime':'Linux/glibc in PRoot; not a native Android GTK backend','sha256':digest(archive),'compressedBytes':archive.stat().st_size,
        'uncompressedBytes':total,'originalAppImageSha256':OFFICIAL_SHA,'originalViews':sorted(expected),
        'androidRuntimeExecuted':False,'hardwareParityVerified':False}
    (a.output/'assets/desktop-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (a.output/'original-desktop-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
    print(json.dumps(manifest,indent=2))

if __name__ == '__main__': main()
