#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later
set -eu
mkdir -p "$XDG_RUNTIME_DIR" "$HOME/.config/darktable" "$HOME/.cache/darktable"
chmod 700 "$XDG_RUNTIME_DIR"
/usr/bin/dbus-uuidgen --ensure=/etc/machine-id
# The HTTP display is a private filesystem socket. The separate native GTK
# display uses an unpredictable XDG_RUNTIME_DIR supplied by the Android host.
/usr/bin/broadwayd --unixsocket /tmp/h.sock :0 &
display_pid=$!
trap 'kill "$display_pid" 2>/dev/null || true' EXIT
export APPDIR=/opt/darktable
export GDK_BACKEND=broadway BROADWAY_DISPLAY=:0
export GTK_DATA_PREFIX="$APPDIR" GTK_EXE_PREFIX="$APPDIR/usr"
export GSETTINGS_SCHEMA_DIR="$APPDIR/usr/share/glib-2.0/schemas"
export XDG_DATA_DIRS="$APPDIR/usr/share:/usr/share"
export GTK_PATH="$APPDIR/usr/lib/gtk-3.0"
export GTK_IM_MODULE_FILE="$APPDIR/usr/lib/gtk-3.0/3.0.0/immodules.cache"
export GDK_PIXBUF_MODULE_FILE="$APPDIR/usr/lib/gdk-pixbuf-2.0/2.10.0/loaders.cache"
export GIO_EXTRA_MODULES="$APPDIR/usr/lib/gio/modules"
export LD_LIBRARY_PATH="$APPDIR/usr/lib:$APPDIR/usr/lib/aarch64-linux-gnu:$APPDIR/usr/lib/gdk-pixbuf-2.0/2.10.0/loaders"
for directory in "$APPDIR"/usr/lib/libgphoto2/*; do if [ -d "$directory" ]; then export CAMLIBS="$directory"; break; fi; done
for directory in "$APPDIR"/usr/lib/libgphoto2_port/*; do if [ -d "$directory" ]; then export IOLIBS="$directory"; break; fi; done
# Network/camera configuration remains in the original desktop preferences.
# This is an output-directory adaptation, not a processing preset.
/usr/bin/env -u LD_LIBRARY_PATH /usr/bin/dbus-run-session -- /usr/bin/env "LD_LIBRARY_PATH=$LD_LIBRARY_PATH" "$APPDIR/usr/bin/darktable" \
    --datadir "$APPDIR/usr/share/darktable" \
    --moduledir "$APPDIR/usr/lib/aarch64-linux-gnu/darktable" \
    --configdir "$HOME/.config/darktable" --cachedir "$HOME/.cache/darktable" \
    --library "$HOME/.config/darktable/library.db" \
    --conf 'plugins/imageio/storage/disk/file_directory=/exports/$(FILE_NAME)' "$@"
