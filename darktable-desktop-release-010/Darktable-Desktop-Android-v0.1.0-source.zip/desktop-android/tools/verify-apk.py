#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Check the actual packaged runtime contract, including AAPT transformations."""
import argparse, hashlib, json, struct, zipfile
from pathlib import Path

def digest(stream):
    return hashlib.file_digest(stream, 'sha256').hexdigest()

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('apk',type=Path)
    parser.add_argument('--stage',type=Path,required=True)
    parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args()
    with zipfile.ZipFile(args.apk) as archive:
        names=archive.namelist()
        if len(names)!=len(set(names)):raise ValueError('Duplicate APK entries')
        if archive.testzip() is not None:raise ValueError('APK CRC failure')
        manifest=json.loads(archive.read('assets/desktop-manifest.json'))
        if manifest!=json.loads((args.stage/'assets/desktop-manifest.json').read_text()):
            raise ValueError('Packaged manifest differs from the verified stage')
        payload=archive.getinfo('assets/desktop-runtime.payload')
        if payload.compress_type!=zipfile.ZIP_STORED or payload.file_size!=manifest['compressedBytes']:
            raise ValueError('AAPT transformed the original runtime stream')
        with archive.open(payload) as stream:
            if digest(stream)!=manifest['sha256']:raise ValueError('Runtime SHA-256 mismatch')
        with archive.open(payload) as stream:
            if stream.read(2)!=b'\x1f\x8b':raise ValueError('Runtime is not a GZIP stream')
        executable=archive.read('lib/arm64-v8a/libdesktop_proot.so')
        if executable!=(args.stage/'jniLibs/arm64-v8a/libdesktop_proot.so').read_bytes():
            raise ValueError('Android PRoot executable was transformed')
        if executable[:5]!=b'\x7fELF\x02' or struct.unpack_from('<H',executable,18)[0]!=183:
            raise ValueError('Expected the original ARM64 Android executable')
    with args.apk.open('rb') as stream:sha=digest(stream)
    result={'apk':args.apk.name,'bytes':args.apk.stat().st_size,'sha256':sha,
        'zip_crc_verified':True,'payload_sha256_verified':True,'payload_stored_without_aapt_transformation':True,
        'original_android_proot_bytes_preserved':True,'runtime':manifest}
    args.report.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='runtime'},indent=2))

if __name__=='__main__':main()
