# Original desktop darktable on Android (experimental)

This separate APK packages the official **ARM64 darktable 5.6.2 desktop build**,
including its original GTK widgets, data and modules. It does not reconstruct
the editor in Compose, translate controls into HTML, or replace the pixelpipe.

It is a **Linux/glibc compatibility runtime using PRoot**, with GTK3 Broadway
rendering locally into WebView. It is **not a native Android/Bionic GTK port**.
No remote desktop server, Termux installation, root access or CPU emulator is
required on an ARM64 phone. QEMU is used only for Linux build-machine probes.

## Scope and limits

- All six original views are packaged: lighttable, darkroom, map, print,
  slideshow and tethering. The official build enables OpenMP, OpenCL, Lua,
  G'MIC, gPhoto2, OSMGpsMap, Colord and the original supported file formats.
- Compiled support is not proof of Android integration. OpenCL drivers,
  USB tethering, CUPS printing, MIDI, display ICC profiles and external editors
  require platform support or additional bridges. Hardware parity is unverified.
- The Android runtime has **not been executed on a physical device or Android
  emulator** in the available environment. Linux/QEMU probes are not substitutes.
- Android 8+ ARM64 is required. The launcher intentionally targets API 28:
  PRoot must execute Linux ELF files from its private extracted filesystem.
  Android's API 29+ writable-data execution restriction prevents simply raising
  this target. This is a sideload experiment, not a Play Store release.
- Allow at least 2 GB free storage for installation, runtime and initial data,
  plus space for imported RAW copies, cache and exports.
- This package has a separate application ID and separate catalog. The existing
  mobile app is preserved. Do not migrate its development-5.8 databases or
  version-7 masks into desktop 5.6.2; backwards compatibility is not established.

## Working with photos

1. Start the app and wait for verified runtime extraction and original GTK startup.
2. Android **Import** copies selected files into private `/photos`. Open that
   folder with darktable's original import dialog. Provider originals are intact.
3. Work in the original desktop panels. Landscape orientation, pinch zoom and
   a physical keyboard/mouse are useful; the Android keyboard button is available.
4. Export with darktable's original panel into `/exports` (the default adaptation).
   Android **Export** then saves a selected result through the system file picker.
5. Use **Session** to stop/restart the runtime. Runtime files and photo/catalog
   state are stored separately. Stopping the service forcibly ends the session;
   close darktable normally before stopping when practical.

## Build

Use JDK 17, Gradle 8.14.4, Android SDK 35/build-tools 35.0.0. Build the runtime
outside the repository; do not commit extracted files or APKs to source Git.

Prepare a Debian trixie ARM64 root filesystem (official `arm64v8/debian:trixie-slim`)
with configured APT packages `libgtk-3-bin fonts-dejavu-core libgomp1 libasound2t64
libgpg-error0 libgcrypt20 tzdata dbus-daemon dbus-bin libglx0 libgl1 libegl1
iso-codes libx11-xcb1 libdrm2 libxcb-dri3-0 libgbm1 libusb-1.0-0`. Retain package copyright
files and dpkg metadata. Unpack the verified official ARM64 AppImage with
`unsquashfs -o 936456 -d APPDIR Darktable-5.6.2-aarch64.AppImage`.

Extract the verified Termux `proot`, `libtalloc` and `libandroid-shmem` ARM64
packages into a separate prefix. See [SOURCES.md](SOURCES.md) for versions and hashes.

```sh
python3 tools/assemble-runtime.py \
  --rootfs /absolute/rootfs --appimage /absolute/Darktable-5.6.2-aarch64.AppImage \
  --appdir /absolute/APPDIR --termux-prefix /absolute/termux/usr \
  --output /absolute/new-stage
gradle -PdesktopRuntimeStage=/absolute/new-stage \
  :app:testDebugUnitTest :app:testReleaseUnitTest :app:assembleRelease :app:lintRelease
python3 tools/verify-apk.py app/build/outputs/apk/release/app-release.apk \
  --stage /absolute/new-stage --report /absolute/apk-verification.json
```

The packager requires a fresh output path, checks the official AppImage digest,
retains original file bytes, creates an inventory, and excludes build-machine
IPC, caches, test photos and user homes. The installer checks the complete payload
SHA-256 and safely extracts USTAR entries without following directory symlinks.
The release build currently uses Gradle's development signing key.

For Java-only checks, without packaging a falsely empty APK:

```sh
gradle -PdesktopSourceChecksOnly=true :app:testDebugUnitTest :app:testReleaseUnitTest
```

The display HTTP endpoint requires a random session cookie. GTK's upstream HTTP
socket stays in the private filesystem; its native socket uses a random runtime
directory. No JavaScript-to-Java bridge or WebView file access is exposed.
PRoot is a compatibility tool, **not a security sandbox**.
