/* SPDX-License-Identifier: GPL-3.0-or-later */
package design.komarpunk.darktable.desktop;
import org.junit.*;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class RuntimeTest {
    @Rule public TemporaryFolder temporary=new TemporaryFolder();
    private byte[] entry(String name,byte kind,String link,byte[] content)throws Exception {
        byte[] h=new byte[512];text(h,0,100,name);text(h,100,8,"0000755");text(h,124,12,String.format(Locale.ROOT,"%011o",content.length));
        Arrays.fill(h,148,156,(byte)' ');h[156]=kind;text(h,157,100,link);text(h,257,6,"ustar");
        long checksum=0;for(byte b:h)checksum+=b&255;text(h,148,8,String.format(Locale.ROOT,"%06o",checksum));
        ByteArrayOutputStream out=new ByteArrayOutputStream();out.write(h);out.write(content);out.write(new byte[(512-content.length%512)%512]);return out.toByteArray();
    }
    private void text(byte[] b,int offset,int count,String value){byte[] bytes=value.getBytes(StandardCharsets.UTF_8);System.arraycopy(bytes,0,b,offset,Math.min(bytes.length,count-1));}
    private byte[] tar(byte[]... entries)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();for(byte[] e:entries)out.write(e);out.write(new byte[1024]);return out.toByteArray();}
    @Test public void originalFileBytesNamesModesAndRelativeLinksSurvive()throws Exception {
        Path root=temporary.newFolder().toPath();byte[] data=new byte[70000];new Random(42).nextBytes(data);
        byte[] archive=tar(entry("rootfs/opt/профиль",(byte)'0',"",data),entry("rootfs/opt/current",(byte)'2',"профиль",new byte[0]));
        TarExtractor.extract(new ByteArrayInputStream(archive),root,data.length,n->{});
        assertArrayEquals(data,Files.readAllBytes(root.resolve("rootfs/opt/current")));assertTrue(Files.isExecutable(root.resolve("rootfs/opt/профиль")));
    }
    @Test public void parentTraversalCannotWriteOutsideTheInstallation()throws Exception {
        Path root=temporary.newFolder().toPath();
        assertThrows(IOException.class,()->TarExtractor.extract(new ByteArrayInputStream(tar(entry("../escaped",(byte)'0',"",new byte[]{1}))),root,100,n->{}));
        assertFalse(Files.exists(root.getParent().resolve("escaped")));
    }
    @Test public void canceledInstallationStopsBeforeCreatingPayloadFiles()throws Exception {
        Path root=temporary.newFolder().toPath();byte[] archive=tar(entry("file",(byte)'0',"",new byte[]{1}));
        Thread.currentThread().interrupt();
        try {
            assertThrows(InterruptedIOException.class,()->TarExtractor.extract(new ByteArrayInputStream(archive),root,100,n->{}));
            assertFalse(Files.exists(root.resolve("file")));
        } finally {Thread.interrupted();}
    }
    @Test public void absoluteGuestLinksAreRetainedButCannotRedirectExtraction()throws Exception {
        Path root=temporary.newFolder().toPath(),outside=temporary.newFolder().toPath();
        byte[] archive=tar(entry("link",(byte)'2',outside.toString(),new byte[0]),entry("link/escaped",(byte)'0',"",new byte[]{1}));
        assertThrows(IOException.class,()->TarExtractor.extract(new ByteArrayInputStream(archive),root,100,n->{}));
        assertFalse(Files.exists(outside.resolve("escaped")));
    }
    @Test public void corruptedOrTruncatedPayloadsAndExcessBudgetsFail()throws Exception {
        byte[] archive=tar(entry("file",(byte)'0',"",new byte[1024]));
        assertThrows(IOException.class,()->TarExtractor.extract(new ByteArrayInputStream(archive),temporary.newFolder().toPath(),20,n->{}));
        assertThrows(EOFException.class,()->TarExtractor.extract(new ByteArrayInputStream(Arrays.copyOf(archive,600)),temporary.newFolder().toPath(),2000,n->{}));
        archive[10]^=1;
        assertThrows(IOException.class,()->TarExtractor.extract(new ByteArrayInputStream(archive),temporary.newFolder().toPath(),2000,n->{}));
    }
    @Test public void sessionCookiesUseAnExactNameAndExactSecret(){
        assertTrue(LocalDisplayProxy.authorized("GET / HTTP/1.1\r\nCookie: other=1; desktop-session=secret\r\n\r\n","secret"));
        assertFalse(LocalDisplayProxy.authorized("GET /?desktop-session=secret HTTP/1.1\r\n\r\n","secret"));
        assertFalse(LocalDisplayProxy.authorized("Cookie: fake-desktop-session=secret\r\n","secret"));
        assertFalse(LocalDisplayProxy.authorized("Cookie: desktop-session=secret2\r\n","secret"));
    }
    @Test public void nativeProgramAndSharedFoldersAreArgumentsRatherThanShellCode(){
        ProcessBuilder process=NativeLaunch.process(new File("/private/runtime"),new File("/private/photos ; quoted"),new File("/private/exports"),
            new File("/private/home"),new File("/private/tmp"),new File("/apk/lib/libdesktop_proot.so"));
        assertEquals("/apk/lib/libdesktop_proot.so",process.command().get(0));assertTrue(process.command().contains("/private/photos ; quoted:/photos"));
        assertFalse(process.command().contains("-c"));assertTrue(process.command().contains("HOME=/home/darktable"));
        assertEquals("/private/runtime/host/libexec/proot/loader",process.environment().get("PROOT_LOADER"));
    }
}
