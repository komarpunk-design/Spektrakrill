/* SPDX-License-Identifier: GPL-3.0-or-later */
package design.komarpunk.darktable.desktop;

import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.concurrent.*;

/** GTK's HTTP socket stays private; only this app's token can reach the display. */
final class LocalDisplayProxy implements Closeable {
    final String token;
    private final String upstream;
    private final ServerSocket listener;
    private final Set<Closeable> connections=ConcurrentHashMap.newKeySet();
    private final ExecutorService workers=new ThreadPoolExecutor(16,16,30,TimeUnit.SECONDS,new ArrayBlockingQueue<>(32));
    LocalDisplayProxy(File socket) throws IOException {
        byte[] random=new byte[32];new SecureRandom().nextBytes(random);
        StringBuilder key=new StringBuilder();for(byte b:random)key.append(String.format(Locale.ROOT,"%02x",b&255));token=key.toString();
        upstream=socket.getPath();listener=new ServerSocket(0,16,InetAddress.getByName("127.0.0.1"));
        workers.execute(()->{while(!listener.isClosed())try{
            Socket client=listener.accept();connections.add(client);
            try{workers.execute(()->serve(client));}catch(RejectedExecutionException full){connections.remove(client);closeQuietly(client);}
        }catch(IOException ignored){break;}});
    }
    String url() {return "http://127.0.0.1:"+listener.getLocalPort()+"/__session/"+token;}
    private void serve(Socket client) {
        LocalSocket server=null;
        try {
            client.setSoTimeout(15000);
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();int match=0,value;
            InputStream in=client.getInputStream();byte[] end={13,10,13,10};
            while(match<4 && (value=in.read())!=-1) {
                bytes.write(value);if(bytes.size()>65536)throw new IOException("Display headers too large");
                match=value==end[match]?match+1:value==13?1:0;
            }
            if(match<4)return;
            String headers=bytes.toString("ISO-8859-1");
            if(headers.startsWith("GET /__session/"+token+" HTTP/1.")) {
                client.getOutputStream().write(("HTTP/1.1 303 See Other\r\nLocation: /\r\nSet-Cookie: desktop-session="+token+"; Path=/; HttpOnly; SameSite=Strict\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.ISO_8859_1));return;
            }
            if(!authorized(headers,token)) {
                client.getOutputStream().write("HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".getBytes(StandardCharsets.ISO_8859_1));return;
            }
            server=new LocalSocket();connections.add(server);
            server.connect(new LocalSocketAddress(upstream,LocalSocketAddress.Namespace.FILESYSTEM));
            server.getOutputStream().write(bytes.toByteArray());server.getOutputStream().flush();client.setSoTimeout(0);
            LocalSocket connected=server;
            workers.execute(()->{try{copy(client.getInputStream(),connected.getOutputStream());}catch(IOException ignored){}finally{closeQuietly(client);closeQuietly(connected);}});
            copy(server.getInputStream(),client.getOutputStream());
        } catch(IOException|RejectedExecutionException ignored) { }
        finally {closeQuietly(client);if(server!=null){closeQuietly(server);connections.remove(server);}connections.remove(client);}
    }
    static boolean authorized(String headers,String token) {
        for(String line:headers.split("\r\n")) if(line.regionMatches(true,0,"Cookie:",0,7))
            for(String cookie:line.substring(7).split(";")) {
                String[] pair=cookie.trim().split("=",2);
                if(pair.length==2 && pair[0].equals("desktop-session") && MessageDigest.isEqual(pair[1].getBytes(StandardCharsets.UTF_8),token.getBytes(StandardCharsets.UTF_8)))return true;
            }
        return false;
    }
    private static void copy(InputStream input,OutputStream output)throws IOException {byte[] b=new byte[65536];int n;while((n=input.read(b))!=-1){output.write(b,0,n);output.flush();}}
    private static void closeQuietly(Closeable c){try{c.close();}catch(IOException ignored){}}
    @Override public void close(){closeQuietly(listener);for(Closeable c:connections)closeQuietly(c);workers.shutdownNow();}
}
