/* SPDX-License-Identifier: GPL-3.0-or-later */
package design.komarpunk.darktable.desktop;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.Executors;

public final class DesktopActivity extends Activity {
    private DesktopService service;
    private WebView display;
    private TextView message;
    private FrameLayout body;
    private String activeUrl;
    private File exportFile;
    private final java.util.concurrent.ExecutorService io=Executors.newSingleThreadExecutor();
    private final DesktopService.Listener updates=this::update;
    private final ServiceConnection connection=new ServiceConnection(){
        @Override public void onServiceConnected(ComponentName name,IBinder binder){service=((DesktopService.Connection)binder).service();service.listen(updates);}
        @Override public void onServiceDisconnected(ComponentName name){service=null;update("Сеанс остановлен",null);}
    };
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xff252525);
        body=new FrameLayout(this);root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        display=new WebView(this);display.setBackgroundColor(0xff333333);
        WebSettings settings=display.getSettings();settings.setJavaScriptEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);
        settings.setUseWideViewPort(true);settings.setLoadWithOverviewMode(true);settings.setBuiltInZoomControls(true);settings.setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        display.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !allowed(request.getUrl());}
            @Override public void onPageFinished(WebView view,String address){
                view.evaluateJavascript("(function(){var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}m.content='width=1280,user-scalable=yes';})()",null);
            }
        });
        body.addView(display,new FrameLayout.LayoutParams(-1,-1));
        message=new TextView(this);message.setTextColor(0xffeeeeee);message.setPadding(20,20,20,20);message.setTextIsSelectable(true);
        ScrollView status=new ScrollView(this);status.addView(message);status.setTag("status");body.addView(status,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);
        button(tools,"Импорт",this::importPhotos);button(tools,"Экспорт",this::chooseExport);
        button(tools,"Клавиатура",()->{display.requestFocus();display.evaluateJavascript(
            "if(typeof fakeInput!=='undefined' && fakeInput)fakeInput.focus();",
            ignored->((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(display,InputMethodManager.SHOW_IMPLICIT));});
        button(tools,"Сеанс",this::sessionMenu);root.addView(tools);setContentView(root);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},17);
        startForegroundService(new Intent(this,DesktopService.class));bindService(new Intent(this,DesktopService.class),connection,BIND_AUTO_CREATE);
    }
    private boolean allowed(Uri uri){if(activeUrl==null)return false;Uri expected=Uri.parse(activeUrl);return "http".equals(uri.getScheme())&&"127.0.0.1".equals(uri.getHost())&&uri.getPort()==expected.getPort();}
    private void button(LinearLayout parent,String text,Runnable action){Button button=new Button(this);button.setText(text);button.setTextSize(11);button.setPadding(0,0,0,0);button.setOnClickListener(v->action.run());parent.addView(button,new LinearLayout.LayoutParams(0,-2,1));}
    private void update(String text,String url){runOnUiThread(()->{
        message.setText(text);body.findViewWithTag("status").setVisibility(url==null?View.VISIBLE:View.GONE);display.setVisibility(url==null?View.GONE:View.VISIBLE);
        if(url!=null && !url.equals(activeUrl)){activeUrl=url;display.loadUrl(url);}
    });}
    private void sessionMenu(){new AlertDialog.Builder(this).setTitle("Оригинальный desktop darktable")
        .setItems(new String[]{"Запустить / повторить","Завершить сеанс","О среде"},(d,index)->{
            if(index==0)startForegroundService(new Intent(this,DesktopService.class));
            else if(index==1){if(service!=null)service.stopSession();stopService(new Intent(this,DesktopService.class));}
            else new AlertDialog.Builder(this).setMessage("Оригинальная ARM64-сборка darktable 5.6.2 с GTK. Работает локально через PRoot и Broadway. Это Linux-версия в среде совместимости, не нативный Android/Bionic-порт GTK.\n\nИмпорт Android кладёт копии в /photos. Экспортируйте из darktable в /exports, затем сохраните через кнопку «Экспорт». Исходники у файлового провайдера не изменяются.\n\nUSB-камеры, принтеры, GPU, MIDI и цветовое управление дисплеем зависят от возможностей Android; их работа не гарантирована. Сеанс и каталог хранятся отдельно от мобильной версии.").setPositiveButton("ОК",null).show();
        }).show();}
    private void importPhotos(){Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(intent,1);}
    private void chooseExport(){
        File folder=new File(getFilesDir(),"desktop-data/exports");ArrayList<File> files=new ArrayList<>();collect(folder,files);
        files.sort(Comparator.comparing(File::getName));
        if(files.isEmpty()){new AlertDialog.Builder(this).setMessage("Сначала экспортируйте изображение в /exports через штатную панель darktable.").setPositiveButton("ОК",null).show();return;}
        String[] names=new String[files.size()];for(int i=0;i<names.length;i++)names[i]=files.get(i).getPath().substring(folder.getPath().length()+1);
        new AlertDialog.Builder(this).setTitle("Сохранить результат в Android").setItems(names,(d,index)->{
            exportFile=files.get(index);startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,exportFile.getName()),2);
        }).show();
    }
    private static void collect(File dir,List<File> files){for(File file:dir.listFiles()==null?new File[0]:dir.listFiles())if(!java.nio.file.Files.isSymbolicLink(file.toPath())){if(file.isDirectory())collect(file,files);else files.add(file);}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK || data==null)return;
        ArrayList<Uri> uris=new ArrayList<>();if(data.getClipData()!=null)for(int i=0;i<data.getClipData().getItemCount();i++)uris.add(data.getClipData().getItemAt(i).getUri());else if(data.getData()!=null)uris.add(data.getData());
        File selected=exportFile;
        io.execute(()->{try{
            if(request==1){for(Uri uri:uris){String name="photo";try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())name=c.getString(0);}
                if(name==null)name="photo";
                name=name.replaceAll("[\\\\/\\x00]","_");if(name.isEmpty()||name.equals(".")||name.equals(".."))name="photo";
                File dir=new File(getFilesDir(),"desktop-data/photos/"+UUID.randomUUID());if(!dir.mkdirs())throw new IOException("Cannot create import folder");
                File target=new File(dir,name),pending=new File(dir,".importing");try{
                    try(InputStream in=getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(pending)){copy(in,out);}
                    java.nio.file.Files.move(pending.toPath(),target.toPath(),java.nio.file.StandardCopyOption.ATOMIC_MOVE);
                }catch(Exception e){pending.delete();dir.delete();throw e;}
            }toast("Копии доступны в /photos. Откройте их штатным импортом darktable.");}
            else if(request==2 && selected!=null && !uris.isEmpty()){try(InputStream in=new FileInputStream(selected);OutputStream out=getContentResolver().openOutputStream(uris.get(0),"wt")){copy(in,out);}toast("Экспорт сохранён");}
        }catch(Exception error){toast(error.getMessage());}});
    }
    private static void copy(InputStream input,OutputStream output)throws IOException{if(input==null||output==null)throw new IOException("File provider returned no stream");byte[] b=new byte[65536];int n;while((n=input.read(b))!=-1)output.write(b,0,n);}
    private void toast(String text){runOnUiThread(()->Toast.makeText(this,text,Toast.LENGTH_LONG).show());}
    @Override protected void onDestroy(){if(service!=null)service.unlisten(updates);unbindService(connection);display.destroy();io.shutdown();super.onDestroy();}
}
