/* SPDX-License-Identifier: GPL-3.0-or-later */
package design.komarpunk.darktable.desktop;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CopyOnWriteArrayList;

public final class DesktopService extends Service {
    interface Listener { void changed(String status,String url); }
    public final class Connection extends Binder { DesktopService service(){return DesktopService.this;} }
    private final CopyOnWriteArrayList<Listener> listeners=new CopyOnWriteArrayList<>();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Connection binder=new Connection();
    private volatile String status="Подготавливаем оригинальный darktable…",url;
    private volatile boolean stopping;
    private volatile boolean destroyed,restartRequested;
    private Thread worker;
    private java.lang.Process desktop;
    private LocalDisplayProxy proxy;
    void listen(Listener listener){listeners.add(listener);listener.changed(status,url);}
    void unlisten(Listener listener){listeners.remove(listener);}
    private void publish(String text,String address){status=text;url=address;main.post(()->{for(Listener l:listeners)l.changed(text,address);});}
    @Override public IBinder onBind(Intent intent){return binder;}
    @Override public int onStartCommand(Intent intent,int flags,int id) {
        if(intent!=null && "stop".equals(intent.getAction())){stopSession();stopSelf();return START_NOT_STICKY;}
        if(worker!=null && worker.isAlive()){if(stopping){restartRequested=true;publish("Завершаем предыдущий сеанс…",null);}return START_NOT_STICKY;}
        stopping=false;restartRequested=false;
        NotificationManager manager=getSystemService(NotificationManager.class);
        manager.createNotificationChannel(new NotificationChannel("desktop","darktable desktop",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,DesktopActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        startForeground(1,new Notification.Builder(this,"desktop").setSmallIcon(android.R.drawable.ic_menu_gallery)
            .setContentTitle("darktable desktop").setContentText("Локальный сеанс оригинального GTK-приложения").setOngoing(true).setContentIntent(open).build());
        worker=new Thread(this::runDesktop,"original-desktop");worker.start();return START_NOT_STICKY;
    }
    private void runDesktop() {
        try {
            File runtime=RuntimeInstaller.install(this,text->publish(text,null));
            File data=new File(getFilesDir(),"desktop-data"),photos=new File(data,"photos"),exports=new File(data,"exports"),state=new File(data,"home");
            for(File dir:new File[]{photos,exports,state})if(!dir.isDirectory() && !dir.mkdirs())throw new IOException("Cannot create persistent desktop folders");
            if(stopping)return;
            android.net.ConnectivityManager connectivity=getSystemService(android.net.ConnectivityManager.class);
            android.net.Network network=connectivity.getActiveNetwork();
            android.net.LinkProperties link=network==null?null:connectivity.getLinkProperties(network);
            StringBuilder resolvers=new StringBuilder();
            if(link!=null)for(java.net.InetAddress address:link.getDnsServers())resolvers.append("nameserver ").append(address.getHostAddress()).append('\n');
            File resolver=new File(runtime,"rootfs/etc/resolv.conf");
            if(java.nio.file.Files.isSymbolicLink(resolver.toPath()))throw new IOException("Custom resolver symlink was preserved; use a regular resolver file");
            try(FileOutputStream dns=new FileOutputStream(resolver)){dns.write(resolvers.toString().getBytes(StandardCharsets.US_ASCII));}
            publish("Запускаем исходный GTK-интерфейс…",null);
            File log=new File(data,"desktop-session.log");
            File socket=new File(runtime,"rootfs/tmp/h.sock");
            if(socket.exists()) {
                android.system.StructStat stat=android.system.Os.lstat(socket.getPath());
                if((stat.st_mode&0170000)!=0140000)throw new IOException("A non-socket file occupies the GTK display path; it was preserved");
                if(!socket.delete())throw new IOException("Cannot remove the previous GTK socket");
            }
            desktop=NativeLaunch.process(runtime,photos,exports,state,getCacheDir(),new File(getApplicationInfo().nativeLibraryDir,"libdesktop_proot.so"))
                .redirectErrorStream(true).redirectOutput(log).start();
            long deadline=System.nanoTime()+120_000_000_000L;
            while(!socket.exists()) {
                if(stopping)return;
                if(!desktop.isAlive())throw new IOException("desktop exit "+desktop.exitValue()+"\n"+tail(log));
                if(System.nanoTime()>deadline)throw new IOException("GTK display did not start\n"+tail(log));
                Thread.sleep(100);
            }
            proxy=new LocalDisplayProxy(socket);publish("darktable 5.6.2 · оригинальный GTK",proxy.url());
            int result=desktop.waitFor();
            if(!stopping)publish(result==0?"Сеанс darktable завершён. Нажмите «Запустить».":"desktop exit "+result+"\n"+tail(log),null);
        } catch(Exception error) {if(!stopping)publish(error.getMessage()==null?error.toString():error.getMessage(),null);}
        finally {
            LocalDisplayProxy active=proxy;proxy=null;if(active!=null)active.close();
            java.lang.Process process=desktop;desktop=null;if(process!=null && process.isAlive())process.destroy();
            stopForeground(true);
            main.post(()->{worker=null;if(restartRequested&&!destroyed)onStartCommand(null,0,0);});
        }
    }
    private static String tail(File log)throws IOException {
        try(RandomAccessFile file=new RandomAccessFile(log,"r")){long offset=Math.max(0,file.length()-8192);file.seek(offset);byte[] bytes=new byte[(int)(file.length()-offset)];file.readFully(bytes);return new String(bytes,StandardCharsets.UTF_8);}
    }
    void stopSession(){stopping=true;LocalDisplayProxy active=proxy;if(active!=null)active.close();java.lang.Process process=desktop;if(process!=null)process.destroy();if(worker!=null)worker.interrupt();publish("Сеанс остановлен. Нажмите «Запустить».",null);}
    @Override public void onDestroy(){destroyed=true;restartRequested=false;stopSession();super.onDestroy();}
}
