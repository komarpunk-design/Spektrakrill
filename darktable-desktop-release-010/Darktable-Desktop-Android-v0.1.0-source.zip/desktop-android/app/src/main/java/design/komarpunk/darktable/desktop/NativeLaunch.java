/* SPDX-License-Identifier: GPL-3.0-or-later */
package design.komarpunk.darktable.desktop;

import java.io.File;
import java.util.*;

final class NativeLaunch {
    static ProcessBuilder process(File runtime, File photos, File exports, File state, File temporary, File executable) {
        File root=new File(runtime,"rootfs"), host=new File(runtime,"host");
        List<String> command=new ArrayList<>(Arrays.asList(executable.getPath(),"--kill-on-exit","-i","1000:1000","-r",root.getPath(),
            "-b","/dev","-b","/proc","-b","/sys","-b",photos.getPath()+":/photos","-b",exports.getPath()+":/exports",
            "-b",state.getPath()+":/home/darktable","-w","/home/darktable","/usr/bin/env","-i",
            "HOME=/home/darktable","USER=darktable","LOGNAME=darktable","PATH=/opt/darktable/usr/bin:/usr/bin:/bin","LANG=C.UTF-8",
            "TMPDIR=/tmp","TZ="+TimeZone.getDefault().getID(),"LANGUAGE="+Locale.getDefault().getLanguage(),
            "XDG_RUNTIME_DIR=/tmp/d/"+UUID.randomUUID().toString().replace("-",""),"/bin/sh","/opt/start-desktop.sh"));
        ProcessBuilder builder=new ProcessBuilder(command);
        Map<String,String> env=builder.environment();
        env.put("LD_LIBRARY_PATH",new File(host,"lib").getPath());
        env.put("PROOT_LOADER",new File(host,"libexec/proot/loader").getPath());
        env.put("PROOT_TMP_DIR",temporary.getPath());env.put("PROOT_NO_SECCOMP","1");
        return builder;
    }
}
