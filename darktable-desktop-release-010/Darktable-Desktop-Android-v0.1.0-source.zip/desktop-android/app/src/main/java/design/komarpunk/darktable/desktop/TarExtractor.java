/* SPDX-License-Identifier: GPL-3.0-or-later */
package design.komarpunk.darktable.desktop;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.PosixFilePermission;
import java.util.*;

/** A bounded USTAR reader for the pinned runtime, never for photo imports. */
final class TarExtractor {
    interface Progress { void bytes(long amount); }
    static void extract(InputStream input, Path root, long budget, Progress progress) throws IOException {
        Files.createDirectories(root);
        byte[] header = new byte[512], buffer = new byte[65536];
        long total = 0;
        while (true) {
            if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Runtime installation canceled");
            readFully(input, header, 512);
            boolean zero = true;
            for (byte b : header) if (b != 0) { zero = false; break; }
            if (zero) break;
            long checksum = octal(header, 148, 8), sum = 0;
            for (int i=0;i<512;i++) sum += i>=148 && i<156 ? 32 : header[i]&255;
            if (checksum != sum) throw new IOException("Invalid runtime archive checksum");
            String name = text(header,0,100), prefix = text(header,345,155);
            if (!prefix.isEmpty()) name = prefix + "/" + name;
            if (name.startsWith("/") || name.indexOf('\\')>=0) throw new IOException("Invalid runtime path");
            Path path = root.resolve(name).normalize();
            if (!path.startsWith(root) || path.equals(root)) throw new IOException("Runtime path escapes its directory");
            for (Path p=path.getParent(); p!=null && p.startsWith(root); p=p.getParent())
                if (Files.isSymbolicLink(p)) throw new IOException("Runtime entry follows a symlink");
            long size = octal(header,124,12); int kind = header[156];
            if (size < 0 || size > budget-total) throw new IOException("Runtime archive exceeds its budget");
            total += size;
            Files.createDirectories(path.getParent());
            if (kind=='5') {
                if(size!=0) throw new IOException("Invalid runtime directory");
                Files.createDirectories(path);
            } else if (kind=='2') {
                if(size!=0) throw new IOException("Invalid runtime symlink");
                Files.createSymbolicLink(path, Paths.get(text(header,157,100)));
            } else if (kind==0 || kind=='0') {
                try (OutputStream out=Files.newOutputStream(path,StandardOpenOption.CREATE_NEW)) {
                    long remaining=size;
                    while(remaining>0) {
                        if(Thread.currentThread().isInterrupted())throw new InterruptedIOException("Runtime installation canceled");
                        int n=input.read(buffer,0,(int)Math.min(buffer.length,remaining));
                        if(n<0) throw new EOFException("Truncated runtime archive");
                        out.write(buffer,0,n);remaining-=n;
                    }
                }
                int mode=(int)octal(header,100,8)&0777;
                Set<PosixFilePermission> permissions=EnumSet.noneOf(PosixFilePermission.class);
                PosixFilePermission[] bits={PosixFilePermission.OTHERS_EXECUTE,PosixFilePermission.OTHERS_WRITE,PosixFilePermission.OTHERS_READ,
                    PosixFilePermission.GROUP_EXECUTE,PosixFilePermission.GROUP_WRITE,PosixFilePermission.GROUP_READ,
                    PosixFilePermission.OWNER_EXECUTE,PosixFilePermission.OWNER_WRITE,PosixFilePermission.OWNER_READ};
                for(int i=0;i<9;i++) if((mode&(1<<i))!=0) permissions.add(bits[i]);
                Files.setPosixFilePermissions(path,permissions);
            } else throw new IOException("Unsupported runtime archive entry");
            int padding=(int)((512-size%512)%512);
            if(padding>0) readFully(input,buffer,padding);
            progress.bytes(total);
        }
    }
    static String text(byte[] b,int offset,int size) {
        int end=offset;while(end<offset+size && b[end]!=0)end++;
        return new String(b,offset,end-offset,StandardCharsets.UTF_8);
    }
    static long octal(byte[] b,int offset,int size) throws IOException {
        String s=text(b,offset,size).trim();
        try { return s.isEmpty()?0:Long.parseLong(s,8); } catch(NumberFormatException e) { throw new IOException("Invalid runtime archive number",e); }
    }
    static void readFully(InputStream in,byte[] b,int size) throws IOException {
        int read=0;while(read<size) { int n=in.read(b,read,size-read);if(n<0)throw new EOFException("Truncated runtime archive");read+=n; }
    }
}
