/* SPDX-License-Identifier: GPL-3.0-or-later */
package design.komarpunk.darktable.desktop;

import android.content.Context;
import org.json.JSONObject;
import java.io.*;
import java.security.*;
import java.util.zip.GZIPInputStream;

final class RuntimeInstaller {
    interface Status { void show(String message); }
    static File install(Context context, Status status) throws Exception {
        JSONObject manifest;
        try(InputStream in=context.getAssets().open("desktop-manifest.json")) {
            ByteArrayOutputStream data=new ByteArrayOutputStream(); byte[] b=new byte[8192];int n;
            while((n=in.read(b))!=-1) { if(data.size()+n>65536)throw new IOException("Runtime manifest too large");data.write(b,0,n); }
            manifest=new JSONObject(data.toString("UTF-8"));
        }
        String expected=manifest.getString("sha256");
        File installed=new File(context.getFilesDir(),"desktop-runtime"), marker=new File(installed,".verified");
        if(marker.isFile()) {
            try(InputStream in=new FileInputStream(marker)) {
                byte[] b=new byte[128];int n=in.read(b);
                if(n>0 && expected.equals(new String(b,0,n,java.nio.charset.StandardCharsets.UTF_8))) return installed;
            }
        }
        if(installed.exists()) throw new IOException("An incomplete runtime exists; its files were preserved. Clear this app's storage to reinstall, after saving any work.");
        File stage=new File(context.getFilesDir(),".desktop-install");
        if(stage.exists()) delete(stage);
        if(!stage.mkdirs())throw new IOException("Cannot create private runtime");
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        long budget=manifest.getLong("uncompressedBytes"), free=stage.getUsableSpace();
        if(free<budget+128L*1024*1024)throw new IOException("Not enough free space for original desktop libraries: "+(budget/1024/1024)+" MiB required");
        try {
            try(InputStream raw=context.getAssets().open("desktop-runtime.payload");
                DigestInputStream checked=new DigestInputStream(raw,digest);
                GZIPInputStream tar=new GZIPInputStream(checked,65536)) {
                final long[] last={-1};
                TarExtractor.extract(tar,stage.toPath(),budget,bytes->{
                    long percent=bytes*100/Math.max(1,budget);
                    if(percent!=last[0]) {last[0]=percent;status.show("Распаковка оригинального darktable: "+percent+"%");}
                });
                byte[] drain=new byte[65536];while(tar.read(drain)!=-1) { }
            }
            StringBuilder actual=new StringBuilder();for(byte b:digest.digest())actual.append(String.format(java.util.Locale.ROOT,"%02x",b&255));
            if(!expected.contentEquals(actual))throw new IOException("The original runtime failed its SHA-256 check");
            try(FileOutputStream out=new FileOutputStream(new File(stage,".verified"))) {out.write(expected.getBytes(java.nio.charset.StandardCharsets.UTF_8));out.getFD().sync();}
            if(!stage.renameTo(installed))throw new IOException("Unable to commit the verified runtime");
            return installed;
        } catch(Exception error) {delete(stage);throw error;}
    }
    private static void delete(File path) {
        if(!java.nio.file.Files.isSymbolicLink(path.toPath())) for(File child:path.listFiles()==null?new File[0]:path.listFiles())delete(child);
        path.delete();
    }
}
